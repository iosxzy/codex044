use serde_json::{json, Map, Value};
use std::collections::HashSet;

const REASONING_ENCRYPTED_CONTENT_INCLUDE: &str = "reasoning.encrypted_content";
const CODEX_AUTO_REVIEW_MODEL_ID: &str = "codex-auto-review";
const CODEX_MODEL_CATALOG_TEMPLATE_SLUG: &str = "gpt-5.5";
const CODEX_CLIENT_MODEL_TEMPLATES_JSON: &str = include_str!(concat!(
    env!("CARGO_MANIFEST_DIR"),
    "/../../codex-account-manager-lite/sidecars/cockpit-cliproxy/cdk/CLIProxyAPI/internal/registry/models/codex_client_models.json"
));
const DEFAULT_CONTEXT_WINDOW: i64 = 272_000;
const DEFAULT_MAX_CONTEXT_WINDOW: i64 = 1_000_000;
const LOCAL_PROXY_BYPASS_HOSTS: [&str; 5] =
    ["127.0.0.1", "127.0.0.0/8", "localhost", "::1", "::1/128"];

pub fn merge_local_no_proxy(raw: &str) -> String {
    let mut seen = HashSet::new();
    let mut items = Vec::new();

    for item in raw.split(',') {
        let trimmed = item.trim();
        if trimmed.is_empty() {
            continue;
        }
        if seen.insert(trimmed.to_ascii_lowercase()) {
            items.push(trimmed.to_string());
        }
    }

    for host in LOCAL_PROXY_BYPASS_HOSTS {
        if seen.insert(host.to_ascii_lowercase()) {
            items.push(host.to_string());
        }
    }

    items.join(",")
}

pub fn is_codex_client_models_request(target: &str) -> bool {
    let Some(query) = target.split_once('?').map(|(_, query)| query) else {
        return false;
    };

    query.split('&').any(|pair| {
        pair.split_once('=')
            .map(|(key, _)| key)
            .unwrap_or(pair)
            .eq_ignore_ascii_case("client_version")
    })
}

pub fn build_codex_client_models_response(model_ids: &[String]) -> Value {
    let models = model_ids
        .iter()
        .enumerate()
        .map(|(index, model_id)| build_codex_client_model(model_id, index))
        .collect::<Vec<_>>();

    json!({ "models": models })
}

pub fn build_direct_responses_models_catalog(model_ids: &[String]) -> Value {
    let mut catalog = build_codex_client_models_response(model_ids);
    let models = catalog["models"].as_array_mut().expect("models array");
    for (model, model_id) in models.iter_mut().zip(model_ids) {
        let supports_ultra = match model_id.as_str() {
            "gpt-5.6-sol" | "gpt-5.6-terra" | "gpt-6-astra" | "gpt-6-sol" | "gpt-6.1-sol"
            | "gpt-6.1-terra" | "gpt-6.2-astra" | "gpt-6.2-sol" => true,
            "gpt-5.6-luna" | "gpt-6-luna" => false,
            _ => continue,
        };
        let levels = model["supported_reasoning_levels"]
            .as_array_mut()
            .expect("template reasoning levels");
        levels.push(json!({
            "effort": "max",
            "description": "Maximum reasoning depth for the hardest problems",
        }));
        if supports_ultra {
            levels.push(json!({
                "effort": "ultra",
                "description": "Maximum reasoning with automatic task delegation",
            }));
        }
    }
    catalog
}

pub fn normalize_responses_body_for_codex(body: &mut Value) -> bool {
    let Some(obj) = body.as_object_mut() else {
        return false;
    };

    let mut changed = false;
    changed |= ensure_string_field(obj, "instructions", "");
    changed |= ensure_bool_field(obj, "stream", true);
    changed |= ensure_bool_field(obj, "store", false);
    changed |= ensure_bool_field(obj, "parallel_tool_calls", true);
    changed |= ensure_reasoning_include(obj);
    changed |= normalize_responses_input(obj);
    changed |= normalize_codex_builtin_tools(obj);
    changed |= remove_unsupported_responses_fields(obj);

    changed
}

fn build_codex_client_model(model_id: &str, index: usize) -> Value {
    let display_name = display_name_for_model(model_id);
    let visibility = if matches!(
        model_id,
        CODEX_AUTO_REVIEW_MODEL_ID
            | "gpt-image-2"
            | "grok-imagine-image"
            | "grok-imagine-video"
            | "grok-imagine-image-quality"
    ) {
        "hide"
    } else {
        "list"
    };

    let mut model = codex_client_model_template();
    let object = model
        .as_object_mut()
        .expect("Codex client model template should be a JSON object");
    object.insert("slug".to_string(), Value::String(model_id.to_string()));
    object.insert(
        "display_name".to_string(),
        Value::String(display_name.clone()),
    );
    object.insert("description".to_string(), Value::String(display_name));
    object.insert("context_window".to_string(), json!(DEFAULT_CONTEXT_WINDOW));
    object.insert(
        "max_context_window".to_string(),
        json!(DEFAULT_MAX_CONTEXT_WINDOW),
    );
    object.insert(
        "visibility".to_string(),
        Value::String(visibility.to_string()),
    );
    object.insert("supported_in_api".to_string(), Value::Bool(true));
    object.insert("priority".to_string(), json!(1000 + index));
    object.insert(
        "additional_speed_tiers".to_string(),
        Value::Array(Vec::new()),
    );
    object.insert("service_tiers".to_string(), Value::Array(Vec::new()));
    object.insert("availability_nux".to_string(), Value::Null);
    object.insert("upgrade".to_string(), Value::Null);
    model
}

fn codex_client_model_template() -> Value {
    let payload: Value = serde_json::from_str(CODEX_CLIENT_MODEL_TEMPLATES_JSON)
        .expect("Codex client model templates JSON should be valid");
    payload
        .get("models")
        .and_then(Value::as_array)
        .and_then(|models| {
            models.iter().find(|model| {
                model.get("slug").and_then(Value::as_str) == Some(CODEX_MODEL_CATALOG_TEMPLATE_SLUG)
            })
        })
        .cloned()
        .expect("Codex client model templates should include gpt-5.5")
}

fn display_name_for_model(model_id: &str) -> String {
    match model_id {
        "gpt-5.6-sol" => "GPT-5.6 Sol".to_string(),
        "gpt-5.6-terra" => "GPT-5.6 Terra".to_string(),
        "gpt-5.6-luna" => "GPT-5.6 Luna".to_string(),
        "gpt-5-codex" => "GPT-5 Codex".to_string(),
        "gpt-5-codex-mini" => "GPT-5 Codex Mini".to_string(),
        "gpt-5.4" => "GPT-5.4".to_string(),
        "gpt-5.4-mini" => "GPT-5.4 Mini".to_string(),
        "gpt-5.3-codex" => "GPT-5.3 Codex".to_string(),
        "gpt-5.3-codex-spark" => "GPT-5.3 Codex Spark".to_string(),
        "gpt-5.2" => "GPT-5.2".to_string(),
        "gpt-5.2-codex" => "GPT-5.2 Codex".to_string(),
        "gpt-5.1-codex-max" => "GPT-5.1 Codex Max".to_string(),
        "gpt-5.1-codex-mini" => "GPT-5.1 Codex Mini".to_string(),
        "gpt-image-2" => "GPT Image 2".to_string(),
        CODEX_AUTO_REVIEW_MODEL_ID => "Codex Auto Review".to_string(),
        other => other.to_string(),
    }
}

fn ensure_string_field(obj: &mut Map<String, Value>, key: &str, value: &str) -> bool {
    if obj.get(key).and_then(Value::as_str) == Some(value) {
        return false;
    }
    if obj.get(key).is_some_and(Value::is_string) {
        return false;
    }
    obj.insert(key.to_string(), Value::String(value.to_string()));
    true
}

fn ensure_bool_field(obj: &mut Map<String, Value>, key: &str, value: bool) -> bool {
    if obj.get(key).and_then(Value::as_bool) == Some(value) {
        return false;
    }
    obj.insert(key.to_string(), Value::Bool(value));
    true
}

fn ensure_reasoning_include(obj: &mut Map<String, Value>) -> bool {
    match obj.get_mut("include") {
        Some(Value::Array(items)) => {
            if items
                .iter()
                .any(|item| item.as_str() == Some(REASONING_ENCRYPTED_CONTENT_INCLUDE))
            {
                false
            } else {
                items.push(Value::String(
                    REASONING_ENCRYPTED_CONTENT_INCLUDE.to_string(),
                ));
                true
            }
        }
        _ => {
            obj.insert(
                "include".to_string(),
                Value::Array(vec![Value::String(
                    REASONING_ENCRYPTED_CONTENT_INCLUDE.to_string(),
                )]),
            );
            true
        }
    }
}

fn normalize_responses_input(obj: &mut Map<String, Value>) -> bool {
    let Some(input) = obj.get_mut("input") else {
        return false;
    };

    match input {
        Value::String(text) => {
            let text = text.clone();
            *input = Value::Array(vec![message_item("user", &text)]);
            true
        }
        Value::Array(items) => {
            let mut changed = false;
            for item in items {
                changed |= normalize_responses_input_item(item);
            }
            changed
        }
        Value::Object(_) => {
            let mut item = input.clone();
            normalize_responses_input_item(&mut item);
            *input = Value::Array(vec![item]);
            true
        }
        _ => false,
    }
}

fn normalize_responses_input_item(item: &mut Value) -> bool {
    let Some(obj) = item.as_object_mut() else {
        return false;
    };

    let mut changed = false;
    let role = obj
        .get("role")
        .and_then(Value::as_str)
        .unwrap_or("user")
        .to_ascii_lowercase();

    if role == "system" {
        obj.insert("role".to_string(), Value::String("developer".to_string()));
        changed = true;
    }

    if !obj.contains_key("type") && (obj.contains_key("role") || obj.contains_key("content")) {
        obj.insert("type".to_string(), Value::String("message".to_string()));
        changed = true;
    }

    let normalized_role = obj
        .get("role")
        .and_then(Value::as_str)
        .unwrap_or("user")
        .to_ascii_lowercase();
    if let Some(content) = obj.get_mut("content") {
        changed |= normalize_message_content(content, &normalized_role);
    }

    changed
}

fn normalize_message_content(content: &mut Value, role: &str) -> bool {
    match content {
        Value::String(text) => {
            let text = text.clone();
            *content = Value::Array(vec![text_part(role, &text)]);
            true
        }
        Value::Array(parts) => {
            let mut changed = false;
            for part in parts {
                changed |= normalize_content_part(part, role);
            }
            changed
        }
        _ => false,
    }
}

fn normalize_content_part(part: &mut Value, role: &str) -> bool {
    let Some(obj) = part.as_object_mut() else {
        return false;
    };

    let mut changed = false;
    if !obj.contains_key("text") {
        if let Some(text) = obj
            .get("content")
            .and_then(Value::as_str)
            .map(str::to_string)
        {
            obj.insert("text".to_string(), Value::String(text));
            changed = true;
        }
    }

    let desired_type = response_text_type_for_role(role);
    match obj.get("type").and_then(Value::as_str) {
        Some("text") | None => {
            if obj.contains_key("text") {
                obj.insert("type".to_string(), Value::String(desired_type.to_string()));
                changed = true;
            }
        }
        Some("input_text") if role == "assistant" => {
            obj.insert("type".to_string(), Value::String("output_text".to_string()));
            changed = true;
        }
        Some("output_text") if role != "assistant" => {
            obj.insert("type".to_string(), Value::String("input_text".to_string()));
            changed = true;
        }
        _ => {}
    }

    changed
}

fn message_item(role: &str, text: &str) -> Value {
    json!({
        "type": "message",
        "role": role,
        "content": [text_part(role, text)],
    })
}

fn text_part(role: &str, text: &str) -> Value {
    json!({
        "type": response_text_type_for_role(role),
        "text": text,
    })
}

fn response_text_type_for_role(role: &str) -> &'static str {
    if role.eq_ignore_ascii_case("assistant") {
        "output_text"
    } else {
        "input_text"
    }
}

fn normalize_codex_builtin_tools(obj: &mut Map<String, Value>) -> bool {
    let mut changed = false;

    if let Some(Value::Array(tools)) = obj.get_mut("tools") {
        for tool in tools {
            changed |= normalize_builtin_tool_value(tool);
        }
    }

    if let Some(tool_choice) = obj.get_mut("tool_choice") {
        changed |= normalize_builtin_tool_value(tool_choice);
        if let Some(Value::Array(tools)) = tool_choice.get_mut("tools") {
            for tool in tools {
                changed |= normalize_builtin_tool_value(tool);
            }
        }
    }

    changed
}

fn normalize_builtin_tool_value(value: &mut Value) -> bool {
    let Some(obj) = value.as_object_mut() else {
        return false;
    };
    let Some(tool_type) = obj.get("type").and_then(Value::as_str) else {
        return false;
    };
    let normalized = match tool_type {
        "web_search_preview" | "web_search_preview_2025_03_11" => "web_search",
        _ => return false,
    };

    obj.insert("type".to_string(), Value::String(normalized.to_string()));
    true
}

fn remove_unsupported_responses_fields(obj: &mut Map<String, Value>) -> bool {
    let mut changed = false;
    for key in [
        "max_output_tokens",
        "max_completion_tokens",
        "temperature",
        "top_p",
        "truncation",
        "context_management",
        "user",
        "prompt_cache_retention",
        "safety_identifier",
        "stream_options",
    ] {
        changed |= obj.remove(key).is_some();
    }

    if obj.get("service_tier").is_some()
        && obj.get("service_tier").and_then(Value::as_str) != Some("priority")
    {
        obj.remove("service_tier");
        changed = true;
    }

    changed
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn merges_local_no_proxy_hosts() {
        assert_eq!(
            merge_local_no_proxy("example.com, localhost"),
            "example.com,localhost,127.0.0.1,127.0.0.0/8,::1,::1/128"
        );
        assert_eq!(
            merge_local_no_proxy(""),
            "127.0.0.1,127.0.0.0/8,localhost,::1,::1/128"
        );
    }

    #[test]
    fn normalizes_string_input_for_codex_responses() {
        let mut body = json!({
            "model": "gpt-5.4",
            "input": "pong",
            "stream": false,
            "store": true,
            "temperature": 0.1,
        });

        assert!(normalize_responses_body_for_codex(&mut body));
        assert_eq!(body.get("stream").and_then(Value::as_bool), Some(true));
        assert_eq!(body.get("store").and_then(Value::as_bool), Some(false));
        assert_eq!(body.get("instructions").and_then(Value::as_str), Some(""));
        assert!(body.get("temperature").is_none());
        assert_eq!(
            body.pointer("/input/0/content/0/type")
                .and_then(Value::as_str),
            Some("input_text")
        );
        assert_eq!(
            body.pointer("/input/0/content/0/text")
                .and_then(Value::as_str),
            Some("pong")
        );
    }

    #[test]
    fn normalizes_system_role_and_builtin_tool_aliases() {
        let mut body = json!({
            "model": "gpt-5.4",
            "input": [{
                "type": "message",
                "role": "system",
                "content": "be concise"
            }],
            "tools": [{"type": "web_search_preview"}],
        });

        normalize_responses_body_for_codex(&mut body);
        assert_eq!(
            body.pointer("/input/0/role").and_then(Value::as_str),
            Some("developer")
        );
        assert_eq!(
            body.pointer("/input/0/content/0/type")
                .and_then(Value::as_str),
            Some("input_text")
        );
        assert_eq!(
            body.pointer("/tools/0/type").and_then(Value::as_str),
            Some("web_search")
        );
    }

    #[test]
    fn codex_client_models_use_models_field_only() {
        let response = build_codex_client_models_response(&["gpt-5.4".to_string()]);
        assert!(response.get("models").and_then(Value::as_array).is_some());
        assert!(response.get("object").is_none());
        assert!(response.get("data").is_none());
        assert_eq!(
            response.pointer("/models/0/slug").and_then(Value::as_str),
            Some("gpt-5.4")
        );
        assert_eq!(
            response
                .pointer("/models/0/prefer_websockets")
                .and_then(Value::as_bool),
            Some(true)
        );
        assert_eq!(
            response
                .pointer("/models/0/shell_type")
                .and_then(Value::as_str),
            Some("shell_command")
        );
        assert_eq!(
            response
                .pointer("/models/0/supported_in_api")
                .and_then(Value::as_bool),
            Some(true)
        );
        assert!(response
            .pointer("/models/0/input_modalities")
            .and_then(Value::as_array)
            .is_some());
    }

    #[test]
    fn direct_responses_catalog_advertises_model_specific_reasoning_levels() {
        let model_ids =
            ["gpt-6.2-sol", "gpt-6.2-astra", "gpt-6-luna", "custom-model"].map(str::to_string);
        let catalog = build_direct_responses_models_catalog(&model_ids);
        let models = catalog["models"].as_array().unwrap();
        for (model, expected_last) in models.iter().zip(["ultra", "ultra", "max", "xhigh"]) {
            let levels = model["supported_reasoning_levels"].as_array().unwrap();
            assert_eq!(levels.last().unwrap()["effort"], expected_last);
        }
        let gateway = build_codex_client_models_response(&model_ids);
        assert_eq!(
            gateway["models"][0]["supported_reasoning_levels"]
                .as_array()
                .unwrap()
                .last()
                .unwrap()["effort"],
            "xhigh"
        );
    }
}
