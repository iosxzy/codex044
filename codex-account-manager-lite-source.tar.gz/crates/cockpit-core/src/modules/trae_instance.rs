use std::collections::BTreeSet;
use std::fs;
use std::path::PathBuf;
use std::sync::Mutex;

use chrono::Utc;
use uuid::Uuid;

use crate::models::{DefaultInstanceSettings, InstanceProfile, InstanceStore};
use crate::modules;
use crate::modules::instance::InstanceDefaults;
use crate::modules::instance_store;

pub use crate::modules::instance_store::{CreateInstanceParams, UpdateInstanceParams};

static TRAE_INSTANCE_STORE_LOCK: std::sync::LazyLock<Mutex<()>> =
    std::sync::LazyLock::new(|| Mutex::new(()));

const TRAE_INSTANCES_FILE: &str = "trae_instances.json";

fn instances_file_for_platform(
    platform: crate::modules::trae_account::TraePlatformKind,
) -> &'static str {
    match platform {
        crate::modules::trae_account::TraePlatformKind::Trae => TRAE_INSTANCES_FILE,
        crate::modules::trae_account::TraePlatformKind::TraeSolo => "trae_solo_instances.json",
        crate::modules::trae_account::TraePlatformKind::TraeCn => "trae_cn_instances.json",
        crate::modules::trae_account::TraePlatformKind::TraeSoloCn => "trae_solo_cn_instances.json",
    }
}

fn instances_path() -> Result<PathBuf, String> {
    instances_path_for_platform(crate::modules::trae_account::TraePlatformKind::Trae)
}

fn instances_path_for_platform(
    platform: crate::modules::trae_account::TraePlatformKind,
) -> Result<PathBuf, String> {
    let data_dir = modules::account::get_data_dir()?;
    Ok(data_dir.join(instances_file_for_platform(platform)))
}

pub fn load_instance_store() -> Result<InstanceStore, String> {
    load_instance_store_for_platform(crate::modules::trae_account::TraePlatformKind::Trae)
}

pub fn load_instance_store_for_platform(
    platform: crate::modules::trae_account::TraePlatformKind,
) -> Result<InstanceStore, String> {
    let path = instances_path_for_platform(platform)?;
    instance_store::load_instance_store(&path, instances_file_for_platform(platform))
}

pub fn save_instance_store(store: &InstanceStore) -> Result<(), String> {
    save_instance_store_for_platform(crate::modules::trae_account::TraePlatformKind::Trae, store)
}

pub fn save_instance_store_for_platform(
    platform: crate::modules::trae_account::TraePlatformKind,
    store: &InstanceStore,
) -> Result<(), String> {
    let path = instances_path_for_platform(platform)?;
    instance_store::save_instance_store(&path, instances_file_for_platform(platform), store)
}

pub fn load_default_settings() -> Result<DefaultInstanceSettings, String> {
    load_default_settings_for_platform(crate::modules::trae_account::TraePlatformKind::Trae)
}

pub fn load_default_settings_for_platform(
    platform: crate::modules::trae_account::TraePlatformKind,
) -> Result<DefaultInstanceSettings, String> {
    let store = load_instance_store_for_platform(platform)?;
    Ok(store.default_settings)
}

pub fn update_default_settings(
    bind_account_id: Option<Option<String>>,
    extra_args: Option<String>,
    follow_local_account: Option<bool>,
) -> Result<DefaultInstanceSettings, String> {
    update_default_settings_for_platform(
        crate::modules::trae_account::TraePlatformKind::Trae,
        bind_account_id,
        extra_args,
        follow_local_account,
    )
}

pub fn update_default_settings_for_platform(
    platform: crate::modules::trae_account::TraePlatformKind,
    bind_account_id: Option<Option<String>>,
    extra_args: Option<String>,
    follow_local_account: Option<bool>,
) -> Result<DefaultInstanceSettings, String> {
    let _lock = TRAE_INSTANCE_STORE_LOCK
        .lock()
        .map_err(|_| "无法获取实例锁")?;
    let mut store = load_instance_store_for_platform(platform)?;
    let settings = &mut store.default_settings;

    // Trae 实例暂不支持“跟随当前账号”。
    if follow_local_account == Some(true) {
        settings.follow_local_account = false;
    }

    if let Some(bind) = bind_account_id {
        settings.bind_account_id = bind;
        settings.follow_local_account = false;
    }

    if let Some(args) = extra_args {
        settings.extra_args = args.trim().to_string();
    }

    let updated = settings.clone();
    save_instance_store_for_platform(platform, &store)?;
    Ok(updated)
}

pub fn get_default_trae_user_data_dir() -> Result<PathBuf, String> {
    get_default_trae_user_data_dir_for_platform(
        crate::modules::trae_account::TraePlatformKind::Trae,
    )
}

pub fn get_default_trae_user_data_dir_for_platform(
    platform: crate::modules::trae_account::TraePlatformKind,
) -> Result<PathBuf, String> {
    crate::modules::trae_account::get_default_trae_data_dir_for_platform(platform)
}

pub fn get_default_instances_root_dir() -> Result<PathBuf, String> {
    get_default_instances_root_dir_for_platform(
        crate::modules::trae_account::TraePlatformKind::Trae,
    )
}

pub fn get_default_instances_root_dir_for_platform(
    platform: crate::modules::trae_account::TraePlatformKind,
) -> Result<PathBuf, String> {
    #[cfg(target_os = "macos")]
    {
        let home = dirs::home_dir().ok_or("无法获取用户主目录")?;
        return Ok(home
            .join(".antigravity_cockpit")
            .join("instances")
            .join(platform.provider_key()));
    }

    #[cfg(target_os = "windows")]
    {
        let appdata =
            std::env::var("APPDATA").map_err(|_| "无法获取 APPDATA 环境变量".to_string())?;
        return Ok(PathBuf::from(appdata)
            .join(".antigravity_cockpit")
            .join("instances")
            .join(platform.provider_key()));
    }

    #[cfg(target_os = "linux")]
    {
        let home = dirs::home_dir().ok_or("无法获取用户主目录")?;
        return Ok(home
            .join(".antigravity_cockpit")
            .join("instances")
            .join(platform.provider_key()));
    }

    #[allow(unreachable_code)]
    Err("Trae 应用多开仅支持 macOS、Windows 和 Linux".to_string())
}

pub fn get_instance_defaults() -> Result<InstanceDefaults, String> {
    get_instance_defaults_for_platform(crate::modules::trae_account::TraePlatformKind::Trae)
}

pub fn get_instance_defaults_for_platform(
    platform: crate::modules::trae_account::TraePlatformKind,
) -> Result<InstanceDefaults, String> {
    let root_dir = get_default_instances_root_dir_for_platform(platform)?;
    let default_user_data_dir = get_default_trae_user_data_dir_for_platform(platform)?;
    Ok(InstanceDefaults {
        root_dir: root_dir.to_string_lossy().to_string(),
        default_user_data_dir: default_user_data_dir.to_string_lossy().to_string(),
    })
}

pub fn create_instance(params: CreateInstanceParams) -> Result<InstanceProfile, String> {
    create_instance_for_platform(crate::modules::trae_account::TraePlatformKind::Trae, params)
}

pub fn create_instance_for_platform(
    platform: crate::modules::trae_account::TraePlatformKind,
    params: CreateInstanceParams,
) -> Result<InstanceProfile, String> {
    let _lock = TRAE_INSTANCE_STORE_LOCK
        .lock()
        .map_err(|_| "无法获取实例锁")?;
    let mut store = load_instance_store_for_platform(platform)?;

    let name = instance_store::normalize_name(&params.name)?;
    let user_data_dir = params.user_data_dir.trim().to_string();
    if user_data_dir.is_empty() {
        return Err("实例目录不能为空".to_string());
    }

    instance_store::ensure_unique(&store, &name, &user_data_dir, None)?;

    let user_dir_path = PathBuf::from(&user_data_dir);
    let init_mode = params
        .init_mode
        .as_deref()
        .unwrap_or("copy")
        .to_ascii_lowercase();
    let create_empty = init_mode == "empty";
    let use_existing_dir = init_mode == "existingdir" || init_mode == "existing_dir";

    if use_existing_dir {
        if !user_dir_path.exists() {
            let resolved = instance_store::display_path(&user_dir_path);
            return Err(format!("所选目录不存在: {}", resolved));
        }
        if !user_dir_path.is_dir() {
            return Err("所选路径不是目录".to_string());
        }
    } else if create_empty {
        if user_dir_path.exists() {
            let mut has_entries = false;
            if let Ok(mut iter) = fs::read_dir(&user_dir_path) {
                if iter.next().is_some() {
                    has_entries = true;
                }
            }
            if has_entries {
                let resolved_path = instance_store::display_path(&user_dir_path);
                return Err(format!("空白实例需要目标目录为空: {}", resolved_path));
            }
        }
        fs::create_dir_all(&user_dir_path).map_err(|e| format!("创建实例目录失败: {}", e))?;
    } else {
        let source_dir = match params.copy_source_instance_id.as_deref() {
            Some("__default__") | None => get_default_trae_user_data_dir_for_platform(platform)?,
            Some(source_id) => {
                let source_instance = store
                    .instances
                    .iter()
                    .find(|item| item.id == source_id)
                    .ok_or("复制来源实例不存在")?;
                PathBuf::from(&source_instance.user_data_dir)
            }
        };

        if user_dir_path.exists() {
            let mut has_entries = false;
            if let Ok(mut iter) = fs::read_dir(&user_dir_path) {
                if iter.next().is_some() {
                    has_entries = true;
                }
            }
            if has_entries {
                let resolved_path = instance_store::display_path(&user_dir_path);
                return Err(format!("复制来源实例需要目标目录为空: {}", resolved_path));
            }
        }

        if !source_dir.exists() {
            return Err("未找到复制来源目录，请先确保来源实例已初始化".to_string());
        }

        instance_store::copy_dir_recursive(&source_dir, &user_dir_path)?;
    }

    let instance = InstanceProfile {
        id: Uuid::new_v4().to_string(),
        name,
        user_data_dir,
        working_dir: params.working_dir,
        extra_args: params.extra_args.trim().to_string(),
        bind_account_id: if create_empty {
            None
        } else {
            params.bind_account_id
        },
        launch_mode: crate::models::InstanceLaunchMode::App,
        app_speed: crate::models::codex::CodexAppSpeed::Standard,
        created_at: Utc::now().timestamp_millis(),
        last_launched_at: None,
        last_pid: None,
    };

    store.instances.push(instance.clone());
    save_instance_store_for_platform(platform, &store)?;
    Ok(instance)
}

pub fn update_instance(params: UpdateInstanceParams) -> Result<InstanceProfile, String> {
    update_instance_for_platform(crate::modules::trae_account::TraePlatformKind::Trae, params)
}

pub fn update_instance_for_platform(
    platform: crate::modules::trae_account::TraePlatformKind,
    params: UpdateInstanceParams,
) -> Result<InstanceProfile, String> {
    let _lock = TRAE_INSTANCE_STORE_LOCK
        .lock()
        .map_err(|_| "无法获取实例锁")?;
    let mut store = load_instance_store_for_platform(platform)?;
    let index = store
        .instances
        .iter()
        .position(|instance| instance.id == params.instance_id)
        .ok_or("实例不存在")?;

    let current_id = store.instances[index].id.clone();
    let current_dir = store.instances[index].user_data_dir.clone();
    let next_name = params
        .name
        .as_ref()
        .map(|name| instance_store::normalize_name(name))
        .transpose()?;

    if let Some(ref normalized) = next_name {
        instance_store::ensure_unique(&store, normalized, &current_dir, Some(&current_id))?;
    }

    let instance = &mut store.instances[index];
    if let Some(normalized) = next_name {
        instance.name = normalized;
    }
    if let Some(ref extra_args) = params.extra_args {
        instance.extra_args = extra_args.trim().to_string();
    }
    if let Some(bind) = params.bind_account_id.clone() {
        instance.bind_account_id = bind;
    }

    let updated = instance.clone();
    save_instance_store_for_platform(platform, &store)?;
    Ok(updated)
}

pub fn delete_instance(instance_id: &str) -> Result<(), String> {
    delete_instance_for_platform(
        crate::modules::trae_account::TraePlatformKind::Trae,
        instance_id,
    )
}

pub fn delete_instance_for_platform(
    platform: crate::modules::trae_account::TraePlatformKind,
    instance_id: &str,
) -> Result<(), String> {
    let _lock = TRAE_INSTANCE_STORE_LOCK
        .lock()
        .map_err(|_| "无法获取实例锁")?;
    let mut store = load_instance_store_for_platform(platform)?;
    let index = store
        .instances
        .iter()
        .position(|instance| instance.id == instance_id)
        .ok_or("实例不存在")?;
    let user_data_dir = store.instances[index].user_data_dir.clone();

    if !user_data_dir.trim().is_empty() {
        let dir_path = PathBuf::from(&user_data_dir);
        modules::instance::delete_instance_directory(&dir_path)?;
    }

    store.instances.remove(index);
    save_instance_store_for_platform(platform, &store)?;
    Ok(())
}

pub fn update_instance_after_start(instance_id: &str, pid: u32) -> Result<InstanceProfile, String> {
    update_instance_after_start_for_platform(
        crate::modules::trae_account::TraePlatformKind::Trae,
        instance_id,
        pid,
    )
}

pub fn update_instance_after_start_for_platform(
    platform: crate::modules::trae_account::TraePlatformKind,
    instance_id: &str,
    pid: u32,
) -> Result<InstanceProfile, String> {
    let _lock = TRAE_INSTANCE_STORE_LOCK
        .lock()
        .map_err(|_| "无法获取实例锁")?;
    let mut store = load_instance_store_for_platform(platform)?;
    let mut updated = None;
    for instance in &mut store.instances {
        if instance.id == instance_id {
            instance.last_launched_at = Some(Utc::now().timestamp_millis());
            instance.last_pid = Some(pid);
            updated = Some(instance.clone());
            break;
        }
    }
    let updated = updated.ok_or("实例不存在")?;
    save_instance_store_for_platform(platform, &store)?;
    Ok(updated)
}

pub fn update_instance_pid(instance_id: &str, pid: Option<u32>) -> Result<InstanceProfile, String> {
    update_instance_pid_for_platform(
        crate::modules::trae_account::TraePlatformKind::Trae,
        instance_id,
        pid,
    )
}

pub fn update_instance_pid_for_platform(
    platform: crate::modules::trae_account::TraePlatformKind,
    instance_id: &str,
    pid: Option<u32>,
) -> Result<InstanceProfile, String> {
    let _lock = TRAE_INSTANCE_STORE_LOCK
        .lock()
        .map_err(|_| "无法获取实例锁")?;
    let mut store = load_instance_store_for_platform(platform)?;
    let mut updated = None;
    for instance in &mut store.instances {
        if instance.id == instance_id {
            instance.last_pid = pid;
            updated = Some(instance.clone());
            break;
        }
    }
    let updated = updated.ok_or("实例不存在")?;
    save_instance_store_for_platform(platform, &store)?;
    Ok(updated)
}

pub fn update_default_pid(pid: Option<u32>) -> Result<DefaultInstanceSettings, String> {
    update_default_pid_for_platform(crate::modules::trae_account::TraePlatformKind::Trae, pid)
}

pub fn update_default_pid_for_platform(
    platform: crate::modules::trae_account::TraePlatformKind,
    pid: Option<u32>,
) -> Result<DefaultInstanceSettings, String> {
    let _lock = TRAE_INSTANCE_STORE_LOCK
        .lock()
        .map_err(|_| "无法获取实例锁")?;
    let mut store = load_instance_store_for_platform(platform)?;
    store.default_settings.last_pid = pid;
    let updated = store.default_settings.clone();
    save_instance_store_for_platform(platform, &store)?;
    Ok(updated)
}

pub fn clear_all_pids() -> Result<(), String> {
    clear_all_pids_for_platform(crate::modules::trae_account::TraePlatformKind::Trae)
}

pub fn clear_all_pids_for_platform(
    platform: crate::modules::trae_account::TraePlatformKind,
) -> Result<(), String> {
    let _lock = TRAE_INSTANCE_STORE_LOCK
        .lock()
        .map_err(|_| "无法获取实例锁")?;
    let mut store = load_instance_store_for_platform(platform)?;
    store.default_settings.last_pid = None;
    for instance in &mut store.instances {
        instance.last_pid = None;
    }
    save_instance_store_for_platform(platform, &store)
}

pub fn build_storage_json_path(user_data_dir: &str) -> PathBuf {
    PathBuf::from(user_data_dir)
        .join("User")
        .join("globalStorage")
        .join("storage.json")
}

#[derive(Debug, Clone)]
pub struct TraeRunningBoundAccountContext {
    pub account_id: String,
    pub storage_path: PathBuf,
}

fn all_trae_platform_kinds() -> [crate::modules::trae_account::TraePlatformKind; 4] {
    [
        crate::modules::trae_account::TraePlatformKind::Trae,
        crate::modules::trae_account::TraePlatformKind::TraeSolo,
        crate::modules::trae_account::TraePlatformKind::TraeCn,
        crate::modules::trae_account::TraePlatformKind::TraeSoloCn,
    ]
}

pub fn resolve_running_bound_account_contexts(
) -> Result<Vec<TraeRunningBoundAccountContext>, String> {
    let mut contexts = Vec::new();
    let mut seen_ids = BTreeSet::new();
    for platform in all_trae_platform_kinds() {
        resolve_running_bound_account_contexts_for_platform(
            platform,
            &mut seen_ids,
            &mut contexts,
        )?;
    }
    Ok(contexts)
}

fn resolve_running_bound_account_contexts_for_platform(
    platform: crate::modules::trae_account::TraePlatformKind,
    seen_ids: &mut BTreeSet<String>,
    contexts: &mut Vec<TraeRunningBoundAccountContext>,
) -> Result<(), String> {
    let store = load_instance_store_for_platform(platform)?;

    if store
        .default_settings
        .last_pid
        .map(modules::process::is_pid_running)
        .unwrap_or(false)
    {
        if let Some(bind) = store
            .default_settings
            .bind_account_id
            .as_deref()
            .map(str::trim)
            .filter(|value| !value.is_empty())
        {
            if seen_ids.insert(bind.to_string()) {
                let default_dir = get_default_trae_user_data_dir_for_platform(platform)?;
                let storage_path = default_dir
                    .join("User")
                    .join("globalStorage")
                    .join("storage.json");
                contexts.push(TraeRunningBoundAccountContext {
                    account_id: bind.to_string(),
                    storage_path,
                });
            }
        }
    }

    for instance in &store.instances {
        if !instance
            .last_pid
            .map(modules::process::is_pid_running)
            .unwrap_or(false)
        {
            continue;
        }
        let Some(bind) = instance
            .bind_account_id
            .as_deref()
            .map(str::trim)
            .filter(|value| !value.is_empty())
        else {
            continue;
        };
        if seen_ids.insert(bind.to_string()) {
            contexts.push(TraeRunningBoundAccountContext {
                account_id: bind.to_string(),
                storage_path: build_storage_json_path(&instance.user_data_dir),
            });
        }
    }

    Ok(())
}
