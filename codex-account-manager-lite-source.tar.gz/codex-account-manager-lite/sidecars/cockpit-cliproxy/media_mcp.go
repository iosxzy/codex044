package main

import (
	"bufio"
	"bytes"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"mime/multipart"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"time"
)

const mediaMCPProtocolVersion = "2025-03-26"

type mediaMCPConfig struct {
	BaseURL      string
	APIKey       string
	Models       []string
	DefaultModel string
	ProviderName string
	OutputDir    string
	ConfigSource string
}

type mediaMCPExternalConfig struct {
	Active         bool     `json:"active"`
	BaseURL        string   `json:"baseUrl"`
	RuntimeBaseURL string   `json:"runtimeBaseUrl"`
	APIKey         string   `json:"apiKey"`
	Models         []string `json:"models"`
	DefaultModel   string   `json:"defaultModel"`
	ProviderName   string   `json:"providerName"`
}

type mediaMCPLocalConfig struct {
	Enabled             bool   `json:"enabled"`
	Port                int    `json:"port"`
	APIKey              string `json:"apiKey"`
	ClientBaseURLHost   string `json:"clientBaseUrlHost"`
	ImageGenerationMode string `json:"imageGenerationMode"`
}

type mediaMCPRequest struct {
	JSONRPC string          `json:"jsonrpc"`
	ID      json.RawMessage `json:"id,omitempty"`
	Method  string          `json:"method"`
	Params  json.RawMessage `json:"params,omitempty"`
}

type mediaMCPToolCallParams struct {
	Name      string         `json:"name"`
	Arguments map[string]any `json:"arguments"`
}

type mediaMCPImageResult struct {
	Data          string
	MIMEType      string
	SourceURL     string
	RevisedPrompt string
}

type mediaMCPServer struct {
	externalConfigPath string
	localConfigPath    string
	outputDir          string
	httpClient         *http.Client
}

func runMediaMCPServer(externalConfigPath, localConfigPath, outputDir string) error {
	server := &mediaMCPServer{
		externalConfigPath: strings.TrimSpace(externalConfigPath),
		localConfigPath:    strings.TrimSpace(localConfigPath),
		outputDir:          strings.TrimSpace(outputDir),
		httpClient: &http.Client{
			Timeout: 5 * time.Minute,
		},
	}
	return server.serve(os.Stdin, os.Stdout)
}

func (s *mediaMCPServer) serve(input io.Reader, output io.Writer) error {
	reader := bufio.NewReaderSize(input, 256*1024)
	writer := bufio.NewWriterSize(output, 256*1024)
	defer writer.Flush()

	for {
		line, err := reader.ReadBytes('\n')
		if errors.Is(err, io.EOF) && len(bytes.TrimSpace(line)) == 0 {
			return nil
		}
		if err != nil && !errors.Is(err, io.EOF) {
			return err
		}
		line = bytes.TrimSpace(line)
		if len(line) == 0 {
			if errors.Is(err, io.EOF) {
				return nil
			}
			continue
		}

		var request mediaMCPRequest
		if decodeErr := json.Unmarshal(line, &request); decodeErr != nil {
			if writeErr := writeMediaMCPMessage(writer, mediaMCPErrorResponse(nil, -32700, "Parse error")); writeErr != nil {
				return writeErr
			}
			continue
		}
		response := s.handleRequest(request)
		if response != nil {
			if writeErr := writeMediaMCPMessage(writer, response); writeErr != nil {
				return writeErr
			}
		}
		if errors.Is(err, io.EOF) {
			return nil
		}
	}
}

func writeMediaMCPMessage(writer *bufio.Writer, payload any) error {
	encoded, err := json.Marshal(payload)
	if err != nil {
		return err
	}
	if _, err = writer.Write(encoded); err != nil {
		return err
	}
	if err = writer.WriteByte('\n'); err != nil {
		return err
	}
	return writer.Flush()
}

func mediaMCPResponse(id json.RawMessage, result any) map[string]any {
	response := map[string]any{"jsonrpc": "2.0", "result": result}
	if len(id) == 0 {
		response["id"] = nil
	} else {
		response["id"] = json.RawMessage(id)
	}
	return response
}

func mediaMCPErrorResponse(id json.RawMessage, code int, message string) map[string]any {
	response := map[string]any{
		"jsonrpc": "2.0",
		"error":   map[string]any{"code": code, "message": message},
	}
	if len(id) == 0 {
		response["id"] = nil
	} else {
		response["id"] = json.RawMessage(id)
	}
	return response
}

func (s *mediaMCPServer) handleRequest(request mediaMCPRequest) any {
	if len(request.ID) == 0 {
		return nil
	}

	switch request.Method {
	case "initialize":
		protocolVersion := mediaMCPProtocolVersion
		var params struct {
			ProtocolVersion string `json:"protocolVersion"`
		}
		if json.Unmarshal(request.Params, &params) == nil && strings.TrimSpace(params.ProtocolVersion) != "" {
			protocolVersion = params.ProtocolVersion
		}
		return mediaMCPResponse(request.ID, map[string]any{
			"protocolVersion": protocolVersion,
			"capabilities":    map[string]any{"tools": map[string]any{}},
			"instructions":    "When an API service is active in Codex Account Manager, this server is the preferred image path. Use it for image creation and image editing through that selected API service before considering any other image-generation tool. When the user asks to draw, create, generate, make, or illustrate an image, call generate_image instead of only describing the image or claiming that image generation is unavailable. When the user asks to modify an existing image, call edit_image when a local image path is available.",
			"serverInfo": map[string]any{
				"name":    "codex-account-manager-media",
				"version": "0.1.0",
			},
		})
	case "ping":
		return mediaMCPResponse(request.ID, map[string]any{})
	case "tools/list":
		return mediaMCPResponse(request.ID, map[string]any{"tools": mediaMCPTools()})
	case "tools/call":
		var params mediaMCPToolCallParams
		if err := json.Unmarshal(request.Params, &params); err != nil {
			return mediaMCPErrorResponse(request.ID, -32602, "Invalid tools/call parameters")
		}
		return mediaMCPResponse(request.ID, s.callTool(params))
	default:
		return mediaMCPErrorResponse(request.ID, -32601, "Method not found")
	}
}

func mediaMCPTools() []map[string]any {
	return []map[string]any{
		{
			"name":        "generate_image",
			"description": "Preferred image-generation path when an API service is active in Codex Account Manager. Generate and return a raster image through that selected API service. Use this tool whenever the user asks to draw, create, generate, make, illustrate, or visualize an image, before using another image-generation tool. Do not respond with only a text description when image generation is requested. The tool saves the result locally and returns the generated image.",
			"inputSchema": map[string]any{
				"type": "object",
				"properties": map[string]any{
					"prompt":        map[string]any{"type": "string", "description": "Detailed image prompt."},
					"model":         map[string]any{"type": "string", "description": "Optional upstream image model override."},
					"size":          map[string]any{"type": "string", "description": "Optional output size, such as 1024x1024."},
					"quality":       map[string]any{"type": "string", "description": "Optional quality setting."},
					"output_format": map[string]any{"type": "string", "enum": []string{"png", "jpeg", "webp"}},
				},
				"required":             []string{"prompt"},
				"additionalProperties": false,
			},
		},
		{
			"name":        "edit_image",
			"description": "Preferred image-editing path when an API service is active in Codex Account Manager. Edit and return a local raster image through that selected API service before using another image-editing tool. Use this tool whenever the user asks to edit, modify, transform, retouch, extend, or remove something from an existing local image. The image_path must be an absolute local path.",
			"inputSchema": map[string]any{
				"type": "object",
				"properties": map[string]any{
					"prompt":        map[string]any{"type": "string", "description": "Requested image edit."},
					"image_path":    map[string]any{"type": "string", "description": "Absolute path to the local image to edit."},
					"model":         map[string]any{"type": "string", "description": "Optional upstream image model override."},
					"size":          map[string]any{"type": "string"},
					"quality":       map[string]any{"type": "string"},
					"output_format": map[string]any{"type": "string", "enum": []string{"png", "jpeg", "webp"}},
				},
				"required":             []string{"prompt", "image_path"},
				"additionalProperties": false,
			},
		},
	}
}

func (s *mediaMCPServer) callTool(params mediaMCPToolCallParams) map[string]any {
	config, err := s.loadConfig()
	if err != nil {
		return mediaMCPToolError(err.Error())
	}

	var result mediaMCPImageResult
	switch params.Name {
	case "generate_image":
		result, err = s.generateImage(config, params.Arguments)
	case "edit_image":
		result, err = s.editImage(config, params.Arguments)
	default:
		err = fmt.Errorf("unknown media tool: %s", params.Name)
	}
	if err != nil {
		return mediaMCPToolError(err.Error())
	}

	path, err := saveMediaMCPImage(config.OutputDir, result)
	if err != nil {
		return mediaMCPToolError(err.Error())
	}
	text := fmt.Sprintf("Image generated and saved to %s", path)
	if result.RevisedPrompt != "" {
		text += "\nRevised prompt: " + result.RevisedPrompt
	}
	return map[string]any{
		"content": []map[string]any{
			{"type": "text", "text": text},
			{"type": "image", "data": result.Data, "mimeType": result.MIMEType},
		},
	}
}

func mediaMCPToolError(message string) map[string]any {
	return map[string]any{
		"isError": true,
		"content": []map[string]any{{
			"type": "text",
			"text": message,
		}},
	}
}

func (s *mediaMCPServer) loadConfig() (mediaMCPConfig, error) {
	if s.externalConfigPath != "" {
		var external mediaMCPExternalConfig
		if err := readMediaMCPJSONFile(s.externalConfigPath, &external); err == nil && external.Active {
			baseURL := strings.TrimSpace(external.RuntimeBaseURL)
			if baseURL == "" {
				baseURL = strings.TrimSpace(external.BaseURL)
			}
			if baseURL != "" && strings.TrimSpace(external.APIKey) != "" {
				return mediaMCPConfig{
					BaseURL:      baseURL,
					APIKey:       strings.TrimSpace(external.APIKey),
					Models:       external.Models,
					DefaultModel: strings.TrimSpace(external.DefaultModel),
					ProviderName: strings.TrimSpace(external.ProviderName),
					OutputDir:    s.outputDir,
					ConfigSource: "proxy API service",
				}, nil
			}
		}
	}

	if s.localConfigPath != "" {
		var local mediaMCPLocalConfig
		if err := readMediaMCPJSONFile(s.localConfigPath, &local); err == nil && local.Enabled {
			if strings.EqualFold(strings.TrimSpace(local.ImageGenerationMode), "disabled") {
				return mediaMCPConfig{}, errors.New("image generation is disabled in the API service settings")
			}
			if local.Port > 0 && strings.TrimSpace(local.APIKey) != "" {
				return mediaMCPConfig{
					BaseURL:      fmt.Sprintf("http://127.0.0.1:%d/v1", local.Port),
					APIKey:       strings.TrimSpace(local.APIKey),
					DefaultModel: defaultImagesToolModel,
					OutputDir:    s.outputDir,
					ConfigSource: "local API service",
				}, nil
			}
		}
	}

	return mediaMCPConfig{}, errors.New("no running API service is available; start Local API Service or Proxy API Service in Codex Account Manager first")
}

func readMediaMCPJSONFile(path string, target any) error {
	content, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	if len(bytes.TrimSpace(content)) == 0 {
		return errors.New("empty configuration file")
	}
	return json.Unmarshal(content, target)
}

func mediaMCPImageModel(config mediaMCPConfig, override string) string {
	if model := strings.TrimSpace(override); model != "" {
		return model
	}
	preferred := []string{
		"gpt-image-2",
		"grok-imagine-image-quality-latest",
		"grok-imagine-image-quality",
		"grok-imagine-image",
		"imagen-4",
	}
	for _, candidate := range preferred {
		for _, model := range config.Models {
			if strings.EqualFold(strings.TrimSpace(model), candidate) {
				return strings.TrimSpace(model)
			}
		}
	}
	for _, model := range config.Models {
		lower := strings.ToLower(strings.TrimSpace(model))
		if strings.Contains(lower, "image") || strings.Contains(lower, "imagen") || strings.Contains(lower, "seedream") || strings.Contains(lower, "jimeng") {
			if !strings.Contains(lower, "video") {
				return strings.TrimSpace(model)
			}
		}
	}
	provider := strings.ToLower(config.ProviderName)
	if strings.Contains(provider, "grok") || strings.Contains(strings.ToLower(config.DefaultModel), "grok") {
		return "grok-imagine-image-quality"
	}
	return defaultImagesToolModel
}

func mediaMCPAPIURL(baseURL, endpoint string) (string, error) {
	parsed, err := url.Parse(strings.TrimSpace(baseURL))
	if err != nil || parsed.Scheme == "" || parsed.Host == "" {
		return "", errors.New("the active API service Base URL is invalid")
	}
	basePath := strings.TrimRight(parsed.Path, "/")
	endpointPath := "/" + strings.TrimLeft(endpoint, "/")
	if strings.HasSuffix(basePath, "/v1") && strings.HasPrefix(endpointPath, "/v1/") {
		endpointPath = strings.TrimPrefix(endpointPath, "/v1")
	}
	parsed.Path = basePath + endpointPath
	parsed.RawQuery = ""
	parsed.Fragment = ""
	return parsed.String(), nil
}

func mediaMCPStringArgument(arguments map[string]any, key string) string {
	value, _ := arguments[key].(string)
	return strings.TrimSpace(value)
}

func (s *mediaMCPServer) generateImage(config mediaMCPConfig, arguments map[string]any) (mediaMCPImageResult, error) {
	prompt := mediaMCPStringArgument(arguments, "prompt")
	if prompt == "" {
		return mediaMCPImageResult{}, errors.New("generate_image requires a prompt")
	}
	payload := map[string]any{
		"model":           mediaMCPImageModel(config, mediaMCPStringArgument(arguments, "model")),
		"prompt":          prompt,
		"response_format": "b64_json",
	}
	for _, key := range []string{"size", "quality", "output_format"} {
		if value := mediaMCPStringArgument(arguments, key); value != "" {
			payload[key] = value
		}
	}
	body, err := json.Marshal(payload)
	if err != nil {
		return mediaMCPImageResult{}, err
	}
	return s.sendImageRequest(config, imagesGenerationsPath, "application/json", body)
}

func (s *mediaMCPServer) editImage(config mediaMCPConfig, arguments map[string]any) (mediaMCPImageResult, error) {
	prompt := mediaMCPStringArgument(arguments, "prompt")
	imagePath := mediaMCPStringArgument(arguments, "image_path")
	if prompt == "" || imagePath == "" {
		return mediaMCPImageResult{}, errors.New("edit_image requires prompt and image_path")
	}
	image, err := os.Open(imagePath)
	if err != nil {
		return mediaMCPImageResult{}, fmt.Errorf("open edit image: %w", err)
	}
	defer image.Close()

	var body bytes.Buffer
	writer := multipart.NewWriter(&body)
	part, err := writer.CreateFormFile("image", filepath.Base(imagePath))
	if err != nil {
		return mediaMCPImageResult{}, err
	}
	if _, err = io.Copy(part, io.LimitReader(image, maxImageUploadBytes+1)); err != nil {
		return mediaMCPImageResult{}, err
	}
	fields := map[string]string{
		"prompt":          prompt,
		"model":           mediaMCPImageModel(config, mediaMCPStringArgument(arguments, "model")),
		"response_format": "b64_json",
	}
	for _, key := range []string{"size", "quality", "output_format"} {
		if value := mediaMCPStringArgument(arguments, key); value != "" {
			fields[key] = value
		}
	}
	for key, value := range fields {
		if err = writer.WriteField(key, value); err != nil {
			return mediaMCPImageResult{}, err
		}
	}
	if err = writer.Close(); err != nil {
		return mediaMCPImageResult{}, err
	}
	return s.sendImageRequest(config, imagesEditsPath, writer.FormDataContentType(), body.Bytes())
}

func (s *mediaMCPServer) sendImageRequest(config mediaMCPConfig, endpoint, contentType string, body []byte) (mediaMCPImageResult, error) {
	requestURL, err := mediaMCPAPIURL(config.BaseURL, endpoint)
	if err != nil {
		return mediaMCPImageResult{}, err
	}
	request, err := http.NewRequest(http.MethodPost, requestURL, bytes.NewReader(body))
	if err != nil {
		return mediaMCPImageResult{}, err
	}
	request.Header.Set("Authorization", "Bearer "+config.APIKey)
	request.Header.Set("Content-Type", contentType)
	request.Header.Set("Accept", "application/json")
	response, err := s.httpClient.Do(request)
	if err != nil {
		return mediaMCPImageResult{}, fmt.Errorf("%s image request failed: %w", config.ConfigSource, err)
	}
	defer response.Body.Close()
	responseBody, err := io.ReadAll(io.LimitReader(response.Body, 128*1024*1024))
	if err != nil {
		return mediaMCPImageResult{}, err
	}
	if response.StatusCode < 200 || response.StatusCode >= 300 {
		message := strings.TrimSpace(string(responseBody))
		if len(message) > 2000 {
			message = message[:2000]
		}
		return mediaMCPImageResult{}, fmt.Errorf("%s returned HTTP %d: %s", config.ConfigSource, response.StatusCode, message)
	}
	result, err := parseMediaMCPImageResponse(responseBody)
	if err != nil {
		return mediaMCPImageResult{}, err
	}
	if result.Data == "" && result.SourceURL != "" {
		result, err = s.downloadMediaMCPImage(result)
	}
	if err != nil {
		return mediaMCPImageResult{}, err
	}
	if result.Data == "" {
		return mediaMCPImageResult{}, errors.New("the image API returned no image data")
	}
	return result, nil
}

func parseMediaMCPImageResponse(body []byte) (mediaMCPImageResult, error) {
	var payload map[string]any
	if err := json.Unmarshal(body, &payload); err != nil {
		return mediaMCPImageResult{}, fmt.Errorf("the image API returned invalid JSON: %w", err)
	}
	items, _ := payload["data"].([]any)
	if len(items) == 0 {
		if output, ok := payload["output"].([]any); ok {
			items = output
		}
	}
	for _, item := range items {
		object, _ := item.(map[string]any)
		if object == nil {
			continue
		}
		data, _ := object["b64_json"].(string)
		if data == "" {
			data, _ = object["base64"].(string)
		}
		sourceURL, _ := object["url"].(string)
		revisedPrompt, _ := object["revised_prompt"].(string)
		if data != "" || sourceURL != "" {
			mimeType := mediaMCPMIMETypeFromBase64(data)
			return mediaMCPImageResult{
				Data:          data,
				MIMEType:      mimeType,
				SourceURL:     sourceURL,
				RevisedPrompt: revisedPrompt,
			}, nil
		}
	}
	return mediaMCPImageResult{}, errors.New("the image API response did not contain data[0].b64_json or data[0].url")
}

func mediaMCPMIMETypeFromBase64(data string) string {
	decoded, err := base64.StdEncoding.DecodeString(data)
	if err != nil || len(decoded) == 0 {
		return "image/png"
	}
	return mediaMCPNormalizeImageMIME(http.DetectContentType(decoded))
}

func mediaMCPNormalizeImageMIME(value string) string {
	value = strings.ToLower(strings.TrimSpace(strings.Split(value, ";")[0]))
	if strings.HasPrefix(value, "image/") {
		return value
	}
	return "image/png"
}

func (s *mediaMCPServer) downloadMediaMCPImage(result mediaMCPImageResult) (mediaMCPImageResult, error) {
	request, err := http.NewRequest(http.MethodGet, result.SourceURL, nil)
	if err != nil {
		return result, err
	}
	response, err := s.httpClient.Do(request)
	if err != nil {
		return result, fmt.Errorf("download generated image: %w", err)
	}
	defer response.Body.Close()
	if response.StatusCode < 200 || response.StatusCode >= 300 {
		return result, fmt.Errorf("download generated image returned HTTP %d", response.StatusCode)
	}
	content, err := io.ReadAll(io.LimitReader(response.Body, maxImageUploadBytes+1))
	if err != nil {
		return result, err
	}
	if len(content) > int(maxImageUploadBytes) {
		return result, errors.New("generated image exceeds the 64 MB limit")
	}
	result.Data = base64.StdEncoding.EncodeToString(content)
	result.MIMEType = mediaMCPNormalizeImageMIME(response.Header.Get("Content-Type"))
	if result.MIMEType == "image/png" && response.Header.Get("Content-Type") == "" {
		result.MIMEType = mediaMCPNormalizeImageMIME(http.DetectContentType(content))
	}
	return result, nil
}

func saveMediaMCPImage(outputDir string, result mediaMCPImageResult) (string, error) {
	decoded, err := base64.StdEncoding.DecodeString(result.Data)
	if err != nil {
		return "", fmt.Errorf("decode generated image: %w", err)
	}
	if outputDir == "" {
		outputDir = filepath.Join(os.TempDir(), "codex-account-manager-media")
	}
	if err = os.MkdirAll(outputDir, 0o700); err != nil {
		return "", fmt.Errorf("create image output directory: %w", err)
	}
	extension := ".png"
	switch result.MIMEType {
	case "image/jpeg":
		extension = ".jpg"
	case "image/webp":
		extension = ".webp"
	case "image/gif":
		extension = ".gif"
	}
	fileName := fmt.Sprintf("image-%s%s", time.Now().Format("20060102-150405.000"), extension)
	path := filepath.Join(outputDir, fileName)
	if err = os.WriteFile(path, decoded, 0o600); err != nil {
		return "", fmt.Errorf("save generated image: %w", err)
	}
	absPath, err := filepath.Abs(path)
	if err != nil {
		return path, nil
	}
	return absPath, nil
}
