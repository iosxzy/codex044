package responses

import (
	"bufio"
	"bytes"
	"context"
	"fmt"
	"strings"
	"time"

	translatorcommon "github.com/router-for-me/CLIProxyAPI/v7/internal/translator/common"
	"github.com/tidwall/gjson"
	"github.com/tidwall/sjson"
)

type claudeToResponsesState struct {
	Seq               int
	ResponseID        string
	CreatedAt         int64
	CurrentMsgID      string
	CurrentFCID       string
	CurrentBlockIndex int
	InTextBlock       bool
	InFuncBlock       bool
	StopReason        string
	StreamTruncated   bool
	Completed         bool
	FuncArgsBuf       map[int]*strings.Builder // index -> args
	// function call bookkeeping for output aggregation
	FuncNames   map[int]string // index -> function name
	FuncCallIDs map[int]string // index -> call id
	FuncSpecs   map[int]claudeResponsesToolSpec
	ToolSpecs   map[string]claudeResponsesToolSpec
	// message text aggregation
	TextBuf        strings.Builder
	CurrentTextBuf strings.Builder
	// output_index of the text block currently being streamed
	CurrentTextIndex int
	// Responses output_index assigned to each Claude content block. Claude block
	// indexes cannot be reused directly because unsupported block types are
	// skipped, which would leave gaps that desynchronize the client's view of
	// response.output.
	OutputIndexByBlock map[int]int
	NextOutputIndex    int
	// reasoning state
	ReasoningActive    bool
	ReasoningItemID    string
	ReasoningBuf       strings.Builder
	ReasoningPartAdded bool
	ReasoningIndex     int
	// usage aggregation
	InputTokens  int64
	OutputTokens int64
	UsageSeen    bool
}

// allocOutputIndex reserves the next Responses output_index for a Claude
// content block, or returns the index already assigned to it.
func (st *claudeToResponsesState) allocOutputIndex(block int) int {
	if st.OutputIndexByBlock == nil {
		st.OutputIndexByBlock = make(map[int]int)
	}
	if existing, ok := st.OutputIndexByBlock[block]; ok {
		return existing
	}
	assigned := st.NextOutputIndex
	st.NextOutputIndex++
	st.OutputIndexByBlock[block] = assigned
	return assigned
}

// outputIndex returns the Responses output_index assigned to a Claude content
// block, falling back to the block index when the block was never opened.
func (st *claudeToResponsesState) outputIndex(block int) int {
	if st.OutputIndexByBlock != nil {
		if assigned, ok := st.OutputIndexByBlock[block]; ok {
			return assigned
		}
	}
	return block
}

type claudeResponsesToolSpec struct {
	kind      string
	name      string
	namespace string
}

const (
	claudeResponsesToolFunction   = "function"
	claudeResponsesToolCustom     = "custom"
	claudeResponsesToolToolSearch = "tool_search"
)

var dataTag = []byte("data:")

func pickRequestJSON(originalRequestRawJSON, requestRawJSON []byte) []byte {
	if len(originalRequestRawJSON) > 0 && gjson.ValidBytes(originalRequestRawJSON) {
		return originalRequestRawJSON
	}
	if len(requestRawJSON) > 0 && gjson.ValidBytes(requestRawJSON) {
		return requestRawJSON
	}
	return nil
}

func emitEvent(event string, payload []byte) []byte {
	return translatorcommon.SSEEventData(event, payload)
}

func claudeResponsesToolSpecsFromRequest(rawJSON []byte) map[string]claudeResponsesToolSpec {
	specs := make(map[string]claudeResponsesToolSpec)
	if len(rawJSON) == 0 || !gjson.ValidBytes(rawJSON) {
		return specs
	}
	forEachResponsesTool(gjson.ParseBytes(rawJSON), func(tool gjson.Result) {
		addClaudeResponsesToolSpec(tool, "", specs)
	})
	return specs
}

func addClaudeResponsesToolSpec(tool gjson.Result, namespace string, specs map[string]claudeResponsesToolSpec) {
	toolType := strings.TrimSpace(tool.Get("type").String())
	switch toolType {
	case "", "function", "custom":
		name := responsesToolName(tool)
		if name == "" {
			return
		}
		upstreamName := name
		if namespace != "" {
			upstreamName = qualifyResponsesNamespaceToolName(namespace, name)
		}
		kind := claudeResponsesToolFunction
		if toolType == "custom" {
			kind = claudeResponsesToolCustom
		}
		specs[upstreamName] = claudeResponsesToolSpec{kind: kind, name: name, namespace: namespace}
	case "tool_search":
		specs["tool_search"] = claudeResponsesToolSpec{kind: claudeResponsesToolToolSearch, name: "tool_search"}
	case "namespace":
		childNamespace := strings.TrimSpace(tool.Get("name").String())
		if childNamespace == "" {
			childNamespace = namespace
		}
		children := tool.Get("tools")
		if !children.IsArray() {
			children = tool.Get("children")
		}
		children.ForEach(func(_, child gjson.Result) bool {
			addClaudeResponsesToolSpec(child, childNamespace, specs)
			return true
		})
	}
}

func claudeResponsesToolItemID(callID string, custom bool) string {
	if custom {
		return "ctc_" + callID
	}
	return "fc_" + callID
}

func claudeCustomToolInput(arguments string) string {
	arguments = strings.TrimSpace(arguments)
	if arguments == "" {
		return ""
	}
	if input := gjson.Get(arguments, "input"); input.Exists() && input.Type == gjson.String {
		return input.String()
	}
	return arguments
}

func claudeResponsesToolItem(callID, upstreamName, arguments, status string, spec claudeResponsesToolSpec) []byte {
	switch spec.kind {
	case claudeResponsesToolCustom:
		item := []byte(`{"id":"","type":"custom_tool_call","status":"","input":"","call_id":"","name":""}`)
		item, _ = sjson.SetBytes(item, "id", claudeResponsesToolItemID(callID, true))
		item, _ = sjson.SetBytes(item, "status", status)
		item, _ = sjson.SetBytes(item, "input", claudeCustomToolInput(arguments))
		item, _ = sjson.SetBytes(item, "call_id", callID)
		item, _ = sjson.SetBytes(item, "name", spec.name)
		return item
	case claudeResponsesToolToolSearch:
		item := []byte(`{"type":"tool_search_call","call_id":"","status":"","execution":"client","arguments":{}}`)
		item, _ = sjson.SetBytes(item, "call_id", callID)
		item, _ = sjson.SetBytes(item, "status", status)
		if gjson.Valid(arguments) {
			item, _ = sjson.SetRawBytes(item, "arguments", []byte(arguments))
		}
		return item
	default:
		item := []byte(`{"id":"","type":"function_call","status":"","arguments":"","call_id":"","name":""}`)
		item, _ = sjson.SetBytes(item, "id", claudeResponsesToolItemID(callID, false))
		item, _ = sjson.SetBytes(item, "status", status)
		item, _ = sjson.SetBytes(item, "arguments", arguments)
		item, _ = sjson.SetBytes(item, "call_id", callID)
		if spec.name != "" {
			item, _ = sjson.SetBytes(item, "name", spec.name)
			if spec.namespace != "" {
				item, _ = sjson.SetBytes(item, "namespace", spec.namespace)
			}
		} else {
			item, _ = sjson.SetBytes(item, "name", upstreamName)
		}
		return item
	}
}

// ConvertClaudeResponseToOpenAIResponses converts Claude SSE to OpenAI Responses SSE events.
func ConvertClaudeResponseToOpenAIResponses(ctx context.Context, modelName string, originalRequestRawJSON, requestRawJSON, rawJSON []byte, param *any) [][]byte {
	if *param == nil {
		requestJSON := pickRequestJSON(originalRequestRawJSON, requestRawJSON)
		*param = &claudeToResponsesState{
			FuncArgsBuf: make(map[int]*strings.Builder),
			FuncNames:   make(map[int]string),
			FuncCallIDs: make(map[int]string),
			FuncSpecs:   make(map[int]claudeResponsesToolSpec),
			ToolSpecs:   claudeResponsesToolSpecsFromRequest(requestJSON),
		}
	}
	st := (*param).(*claudeToResponsesState)

	// Expect `data: {..}` from Claude clients
	if !bytes.HasPrefix(rawJSON, dataTag) {
		return [][]byte{}
	}
	rawJSON = bytes.TrimSpace(rawJSON[5:])
	root := gjson.ParseBytes(rawJSON)
	ev := root.Get("type").String()
	var out [][]byte
	if st.Completed {
		return out
	}

	nextSeq := func() int { st.Seq++; return st.Seq }

	switch ev {
	case "message_start":
		if msg := root.Get("message"); msg.Exists() {
			st.ResponseID = msg.Get("id").String()
			st.CreatedAt = time.Now().Unix()
			// Reset per-message aggregation state
			st.TextBuf.Reset()
			st.CurrentTextBuf.Reset()
			st.ReasoningBuf.Reset()
			st.ReasoningActive = false
			st.InTextBlock = false
			st.InFuncBlock = false
			st.CurrentMsgID = ""
			st.CurrentFCID = ""
			st.CurrentBlockIndex = 0
			st.StopReason = ""
			st.StreamTruncated = false
			st.Completed = false
			st.ReasoningItemID = ""
			st.ReasoningIndex = 0
			st.ReasoningPartAdded = false
			st.FuncArgsBuf = make(map[int]*strings.Builder)
			st.FuncNames = make(map[int]string)
			st.FuncCallIDs = make(map[int]string)
			st.FuncSpecs = make(map[int]claudeResponsesToolSpec)
			st.CurrentTextIndex = 0
			st.OutputIndexByBlock = make(map[int]int)
			st.NextOutputIndex = 0
			st.InputTokens = 0
			st.OutputTokens = 0
			st.UsageSeen = false
			if usage := msg.Get("usage"); usage.Exists() {
				if v := usage.Get("input_tokens"); v.Exists() {
					st.InputTokens = v.Int()
					st.UsageSeen = true
				}
				if v := usage.Get("output_tokens"); v.Exists() {
					st.OutputTokens = v.Int()
					st.UsageSeen = true
				}
			}
			// response.created
			created := []byte(`{"type":"response.created","sequence_number":0,"response":{"id":"","object":"response","created_at":0,"status":"in_progress","background":false,"error":null,"output":[]}}`)
			created, _ = sjson.SetBytes(created, "sequence_number", nextSeq())
			created, _ = sjson.SetBytes(created, "response.id", st.ResponseID)
			created, _ = sjson.SetBytes(created, "response.created_at", st.CreatedAt)
			out = append(out, emitEvent("response.created", created))
			// response.in_progress
			inprog := []byte(`{"type":"response.in_progress","sequence_number":0,"response":{"id":"","object":"response","created_at":0,"status":"in_progress"}}`)
			inprog, _ = sjson.SetBytes(inprog, "sequence_number", nextSeq())
			inprog, _ = sjson.SetBytes(inprog, "response.id", st.ResponseID)
			inprog, _ = sjson.SetBytes(inprog, "response.created_at", st.CreatedAt)
			out = append(out, emitEvent("response.in_progress", inprog))
		}
	case "content_block_start":
		cb := root.Get("content_block")
		if !cb.Exists() {
			return out
		}
		idx := int(root.Get("index").Int())
		st.CurrentBlockIndex = idx
		typ := cb.Get("type").String()
		if typ == "text" {
			// open message item + content part
			st.InTextBlock = true
			st.CurrentTextBuf.Reset()
			outIdx := st.allocOutputIndex(idx)
			st.CurrentTextIndex = outIdx
			st.CurrentMsgID = fmt.Sprintf("msg_%s_0", st.ResponseID)
			item := []byte(`{"type":"response.output_item.added","sequence_number":0,"output_index":0,"item":{"id":"","type":"message","status":"in_progress","content":[],"role":"assistant"}}`)
			item, _ = sjson.SetBytes(item, "sequence_number", nextSeq())
			item, _ = sjson.SetBytes(item, "output_index", outIdx)
			item, _ = sjson.SetBytes(item, "item.id", st.CurrentMsgID)
			out = append(out, emitEvent("response.output_item.added", item))

			part := []byte(`{"type":"response.content_part.added","sequence_number":0,"item_id":"","output_index":0,"content_index":0,"part":{"type":"output_text","annotations":[],"logprobs":[],"text":""}}`)
			part, _ = sjson.SetBytes(part, "sequence_number", nextSeq())
			part, _ = sjson.SetBytes(part, "item_id", st.CurrentMsgID)
			part, _ = sjson.SetBytes(part, "output_index", outIdx)
			out = append(out, emitEvent("response.content_part.added", part))
		} else if typ == "tool_use" {
			st.InFuncBlock = true
			st.CurrentFCID = cb.Get("id").String()
			name := cb.Get("name").String()
			spec := st.ToolSpecs[name]
			st.FuncSpecs[idx] = spec
			outIdx := st.allocOutputIndex(idx)
			itemValue := claudeResponsesToolItem(st.CurrentFCID, name, "", "in_progress", spec)
			item := []byte(`{"type":"response.output_item.added","sequence_number":0,"output_index":0,"item":{}}`)
			item, _ = sjson.SetBytes(item, "sequence_number", nextSeq())
			item, _ = sjson.SetBytes(item, "output_index", outIdx)
			item, _ = sjson.SetRawBytes(item, "item", itemValue)
			out = append(out, emitEvent("response.output_item.added", item))
			if st.FuncArgsBuf[idx] == nil {
				st.FuncArgsBuf[idx] = &strings.Builder{}
			}
			// record function metadata for aggregation
			st.FuncCallIDs[idx] = st.CurrentFCID
			st.FuncNames[idx] = name
		} else if typ == "thinking" {
			// start reasoning item
			st.ReasoningActive = true
			st.ReasoningBuf.Reset()
			outIdx := st.allocOutputIndex(idx)
			st.ReasoningIndex = outIdx
			st.ReasoningItemID = fmt.Sprintf("rs_%s_%d", st.ResponseID, idx)
			item := []byte(`{"type":"response.output_item.added","sequence_number":0,"output_index":0,"item":{"id":"","type":"reasoning","status":"in_progress","summary":[]}}`)
			item, _ = sjson.SetBytes(item, "sequence_number", nextSeq())
			item, _ = sjson.SetBytes(item, "output_index", outIdx)
			item, _ = sjson.SetBytes(item, "item.id", st.ReasoningItemID)
			out = append(out, emitEvent("response.output_item.added", item))
			// add a summary part placeholder
			part := []byte(`{"type":"response.reasoning_summary_part.added","sequence_number":0,"item_id":"","output_index":0,"summary_index":0,"part":{"type":"summary_text","text":""}}`)
			part, _ = sjson.SetBytes(part, "sequence_number", nextSeq())
			part, _ = sjson.SetBytes(part, "item_id", st.ReasoningItemID)
			part, _ = sjson.SetBytes(part, "output_index", outIdx)
			out = append(out, emitEvent("response.reasoning_summary_part.added", part))
			st.ReasoningPartAdded = true
		}
	case "content_block_delta":
		d := root.Get("delta")
		if !d.Exists() {
			return out
		}
		dt := d.Get("type").String()
		if dt == "text_delta" {
			if t := d.Get("text"); t.Exists() {
				msg := []byte(`{"type":"response.output_text.delta","sequence_number":0,"item_id":"","output_index":0,"content_index":0,"delta":"","logprobs":[]}`)
				msg, _ = sjson.SetBytes(msg, "sequence_number", nextSeq())
				msg, _ = sjson.SetBytes(msg, "item_id", st.CurrentMsgID)
				msg, _ = sjson.SetBytes(msg, "output_index", st.CurrentTextIndex)
				msg, _ = sjson.SetBytes(msg, "delta", t.String())
				out = append(out, emitEvent("response.output_text.delta", msg))
				// aggregate text for response.output
				st.TextBuf.WriteString(t.String())
				st.CurrentTextBuf.WriteString(t.String())
			}
		} else if dt == "input_json_delta" {
			idx := int(root.Get("index").Int())
			if pj := d.Get("partial_json"); pj.Exists() {
				if st.FuncArgsBuf[idx] == nil {
					st.FuncArgsBuf[idx] = &strings.Builder{}
				}
				st.FuncArgsBuf[idx].WriteString(pj.String())
				if st.FuncSpecs[idx].kind == "" || st.FuncSpecs[idx].kind == claudeResponsesToolFunction {
					msg := []byte(`{"type":"response.function_call_arguments.delta","sequence_number":0,"item_id":"","output_index":0,"delta":""}`)
					msg, _ = sjson.SetBytes(msg, "sequence_number", nextSeq())
					msg, _ = sjson.SetBytes(msg, "item_id", claudeResponsesToolItemID(st.CurrentFCID, false))
					msg, _ = sjson.SetBytes(msg, "output_index", st.outputIndex(idx))
					msg, _ = sjson.SetBytes(msg, "delta", pj.String())
					out = append(out, emitEvent("response.function_call_arguments.delta", msg))
				}
			}
		} else if dt == "thinking_delta" {
			if st.ReasoningActive {
				if t := d.Get("thinking"); t.Exists() {
					st.ReasoningBuf.WriteString(t.String())
					msg := []byte(`{"type":"response.reasoning_summary_text.delta","sequence_number":0,"item_id":"","output_index":0,"summary_index":0,"delta":""}`)
					msg, _ = sjson.SetBytes(msg, "sequence_number", nextSeq())
					msg, _ = sjson.SetBytes(msg, "item_id", st.ReasoningItemID)
					msg, _ = sjson.SetBytes(msg, "output_index", st.ReasoningIndex)
					msg, _ = sjson.SetBytes(msg, "delta", t.String())
					out = append(out, emitEvent("response.reasoning_summary_text.delta", msg))
				}
			}
		}
	case "content_block_stop":
		idx := int(root.Get("index").Int())
		if st.InTextBlock {
			fullText := st.CurrentTextBuf.String()
			done := []byte(`{"type":"response.output_text.done","sequence_number":0,"item_id":"","output_index":0,"content_index":0,"text":"","logprobs":[]}`)
			done, _ = sjson.SetBytes(done, "sequence_number", nextSeq())
			done, _ = sjson.SetBytes(done, "item_id", st.CurrentMsgID)
			done, _ = sjson.SetBytes(done, "output_index", st.CurrentTextIndex)
			done, _ = sjson.SetBytes(done, "text", fullText)
			out = append(out, emitEvent("response.output_text.done", done))
			partDone := []byte(`{"type":"response.content_part.done","sequence_number":0,"item_id":"","output_index":0,"content_index":0,"part":{"type":"output_text","annotations":[],"logprobs":[],"text":""}}`)
			partDone, _ = sjson.SetBytes(partDone, "sequence_number", nextSeq())
			partDone, _ = sjson.SetBytes(partDone, "item_id", st.CurrentMsgID)
			partDone, _ = sjson.SetBytes(partDone, "output_index", st.CurrentTextIndex)
			partDone, _ = sjson.SetBytes(partDone, "part.text", fullText)
			out = append(out, emitEvent("response.content_part.done", partDone))
			final := []byte(`{"type":"response.output_item.done","sequence_number":0,"output_index":0,"item":{"id":"","type":"message","status":"completed","content":[{"type":"output_text","text":""}],"role":"assistant"}}`)
			final, _ = sjson.SetBytes(final, "sequence_number", nextSeq())
			final, _ = sjson.SetBytes(final, "output_index", st.CurrentTextIndex)
			final, _ = sjson.SetBytes(final, "item.id", st.CurrentMsgID)
			final, _ = sjson.SetBytes(final, "item.content.0.text", fullText)
			out = append(out, emitEvent("response.output_item.done", final))
			st.InTextBlock = false
		} else if st.InFuncBlock {
			args := "{}"
			if buf := st.FuncArgsBuf[idx]; buf != nil {
				if buf.Len() > 0 {
					args = buf.String()
				}
			}
			spec := st.FuncSpecs[idx]
			outIdx := st.outputIndex(idx)
			if spec.kind == claudeResponsesToolCustom {
				input := claudeCustomToolInput(args)
				if input != "" {
					inputDelta := []byte(`{"type":"response.custom_tool_call_input.delta","sequence_number":0,"item_id":"","output_index":0,"delta":""}`)
					inputDelta, _ = sjson.SetBytes(inputDelta, "sequence_number", nextSeq())
					inputDelta, _ = sjson.SetBytes(inputDelta, "item_id", claudeResponsesToolItemID(st.CurrentFCID, true))
					inputDelta, _ = sjson.SetBytes(inputDelta, "output_index", outIdx)
					inputDelta, _ = sjson.SetBytes(inputDelta, "delta", input)
					out = append(out, emitEvent("response.custom_tool_call_input.delta", inputDelta))
				}
				inputDone := []byte(`{"type":"response.custom_tool_call_input.done","sequence_number":0,"item_id":"","output_index":0,"input":""}`)
				inputDone, _ = sjson.SetBytes(inputDone, "sequence_number", nextSeq())
				inputDone, _ = sjson.SetBytes(inputDone, "item_id", claudeResponsesToolItemID(st.CurrentFCID, true))
				inputDone, _ = sjson.SetBytes(inputDone, "output_index", outIdx)
				inputDone, _ = sjson.SetBytes(inputDone, "input", input)
				out = append(out, emitEvent("response.custom_tool_call_input.done", inputDone))
			} else if spec.kind != claudeResponsesToolToolSearch {
				fcDone := []byte(`{"type":"response.function_call_arguments.done","sequence_number":0,"item_id":"","output_index":0,"arguments":""}`)
				fcDone, _ = sjson.SetBytes(fcDone, "sequence_number", nextSeq())
				fcDone, _ = sjson.SetBytes(fcDone, "item_id", claudeResponsesToolItemID(st.CurrentFCID, false))
				fcDone, _ = sjson.SetBytes(fcDone, "output_index", outIdx)
				fcDone, _ = sjson.SetBytes(fcDone, "arguments", args)
				out = append(out, emitEvent("response.function_call_arguments.done", fcDone))
			}
			itemValue := claudeResponsesToolItem(st.CurrentFCID, st.FuncNames[idx], args, "completed", spec)
			itemDone := []byte(`{"type":"response.output_item.done","sequence_number":0,"output_index":0,"item":{}}`)
			itemDone, _ = sjson.SetBytes(itemDone, "sequence_number", nextSeq())
			itemDone, _ = sjson.SetBytes(itemDone, "output_index", outIdx)
			itemDone, _ = sjson.SetRawBytes(itemDone, "item", itemValue)
			out = append(out, emitEvent("response.output_item.done", itemDone))
			st.InFuncBlock = false
		} else if st.ReasoningActive {
			full := st.ReasoningBuf.String()
			textDone := []byte(`{"type":"response.reasoning_summary_text.done","sequence_number":0,"item_id":"","output_index":0,"summary_index":0,"text":""}`)
			textDone, _ = sjson.SetBytes(textDone, "sequence_number", nextSeq())
			textDone, _ = sjson.SetBytes(textDone, "item_id", st.ReasoningItemID)
			textDone, _ = sjson.SetBytes(textDone, "output_index", st.ReasoningIndex)
			textDone, _ = sjson.SetBytes(textDone, "text", full)
			out = append(out, emitEvent("response.reasoning_summary_text.done", textDone))
			partDone := []byte(`{"type":"response.reasoning_summary_part.done","sequence_number":0,"item_id":"","output_index":0,"summary_index":0,"part":{"type":"summary_text","text":""}}`)
			partDone, _ = sjson.SetBytes(partDone, "sequence_number", nextSeq())
			partDone, _ = sjson.SetBytes(partDone, "item_id", st.ReasoningItemID)
			partDone, _ = sjson.SetBytes(partDone, "output_index", st.ReasoningIndex)
			partDone, _ = sjson.SetBytes(partDone, "part.text", full)
			out = append(out, emitEvent("response.reasoning_summary_part.done", partDone))
			// Close the reasoning output item itself. Emitting only the summary
			// part done leaves the item stuck in "in_progress", and clients that
			// pair response.output_item.added with response.output_item.done treat
			// the unclosed item as an unfinished turn and stop early.
			itemDone := []byte(`{"type":"response.output_item.done","sequence_number":0,"output_index":0,"item":{"id":"","type":"reasoning","status":"completed","summary":[{"type":"summary_text","text":""}]}}`)
			itemDone, _ = sjson.SetBytes(itemDone, "sequence_number", nextSeq())
			itemDone, _ = sjson.SetBytes(itemDone, "output_index", st.ReasoningIndex)
			itemDone, _ = sjson.SetBytes(itemDone, "item.id", st.ReasoningItemID)
			itemDone, _ = sjson.SetBytes(itemDone, "item.summary.0.text", full)
			out = append(out, emitEvent("response.output_item.done", itemDone))
			st.ReasoningActive = false
			st.ReasoningPartAdded = false
		}
		st.CurrentBlockIndex = 0
	case "message_delta":
		if stopReason := strings.TrimSpace(root.Get("delta.stop_reason").String()); stopReason != "" {
			st.StopReason = stopReason
		}
		if usage := root.Get("usage"); usage.Exists() {
			if v := usage.Get("output_tokens"); v.Exists() {
				st.OutputTokens = v.Int()
				st.UsageSeen = true
			}
			if v := usage.Get("input_tokens"); v.Exists() {
				st.InputTokens = v.Int()
				st.UsageSeen = true
			}
		}
	case "message_stop":

		status := "completed"
		if st.StreamTruncated || st.StopReason == "max_tokens" {
			status = "incomplete"
		}
		completed := []byte(`{"type":"response.completed","sequence_number":0,"response":{"id":"","object":"response","created_at":0,"status":"completed","background":false,"error":null}}`)
		completed, _ = sjson.SetBytes(completed, "sequence_number", nextSeq())
		completed, _ = sjson.SetBytes(completed, "response.id", st.ResponseID)
		completed, _ = sjson.SetBytes(completed, "response.created_at", st.CreatedAt)
		completed, _ = sjson.SetBytes(completed, "response.status", status)
		if status == "incomplete" {
			completed, _ = sjson.SetBytes(completed, "response.incomplete_details.reason", "max_output_tokens")
		}
		// Inject original request fields into response as per docs/response.completed.json

		reqBytes := pickRequestJSON(originalRequestRawJSON, requestRawJSON)
		if len(reqBytes) > 0 {
			req := gjson.ParseBytes(reqBytes)
			if v := req.Get("instructions"); v.Exists() {
				completed, _ = sjson.SetBytes(completed, "response.instructions", v.String())
			}
			if v := req.Get("max_output_tokens"); v.Exists() {
				completed, _ = sjson.SetBytes(completed, "response.max_output_tokens", v.Int())
			}
			if v := req.Get("max_tool_calls"); v.Exists() {
				completed, _ = sjson.SetBytes(completed, "response.max_tool_calls", v.Int())
			}
			if v := req.Get("model"); v.Exists() {
				completed, _ = sjson.SetBytes(completed, "response.model", v.String())
			}
			if v := req.Get("parallel_tool_calls"); v.Exists() {
				completed, _ = sjson.SetBytes(completed, "response.parallel_tool_calls", v.Bool())
			}
			if v := req.Get("previous_response_id"); v.Exists() {
				completed, _ = sjson.SetBytes(completed, "response.previous_response_id", v.String())
			}
			if v := req.Get("prompt_cache_key"); v.Exists() {
				completed, _ = sjson.SetBytes(completed, "response.prompt_cache_key", v.String())
			}
			if v := req.Get("reasoning"); v.Exists() {
				completed, _ = sjson.SetBytes(completed, "response.reasoning", v.Value())
			}
			if v := req.Get("safety_identifier"); v.Exists() {
				completed, _ = sjson.SetBytes(completed, "response.safety_identifier", v.String())
			}
			if v := req.Get("service_tier"); v.Exists() {
				completed, _ = sjson.SetBytes(completed, "response.service_tier", v.String())
			}
			if v := req.Get("store"); v.Exists() {
				completed, _ = sjson.SetBytes(completed, "response.store", v.Bool())
			}
			if v := req.Get("temperature"); v.Exists() {
				completed, _ = sjson.SetBytes(completed, "response.temperature", v.Float())
			}
			if v := req.Get("text"); v.Exists() {
				completed, _ = sjson.SetBytes(completed, "response.text", v.Value())
			}
			if v := req.Get("tool_choice"); v.Exists() {
				completed, _ = sjson.SetBytes(completed, "response.tool_choice", v.Value())
			}
			if v := req.Get("tools"); v.Exists() {
				completed, _ = sjson.SetBytes(completed, "response.tools", v.Value())
			}
			if v := req.Get("top_logprobs"); v.Exists() {
				completed, _ = sjson.SetBytes(completed, "response.top_logprobs", v.Int())
			}
			if v := req.Get("top_p"); v.Exists() {
				completed, _ = sjson.SetBytes(completed, "response.top_p", v.Float())
			}
			if v := req.Get("truncation"); v.Exists() {
				completed, _ = sjson.SetBytes(completed, "response.truncation", v.String())
			}
			if v := req.Get("user"); v.Exists() {
				completed, _ = sjson.SetBytes(completed, "response.user", v.Value())
			}
			if v := req.Get("metadata"); v.Exists() {
				completed, _ = sjson.SetBytes(completed, "response.metadata", v.Value())
			}
		}

		// Build response.output from aggregated state
		outputsWrapper := []byte(`{"arr":[]}`)
		// reasoning item (if any)
		if st.ReasoningBuf.Len() > 0 || st.ReasoningPartAdded {
			item := []byte(`{"id":"","type":"reasoning","summary":[{"type":"summary_text","text":""}]}`)
			item, _ = sjson.SetBytes(item, "id", st.ReasoningItemID)
			item, _ = sjson.SetBytes(item, "summary.0.text", st.ReasoningBuf.String())
			outputsWrapper, _ = sjson.SetRawBytes(outputsWrapper, "arr.-1", item)
		}
		// assistant message item (if any text)
		if st.TextBuf.Len() > 0 || st.InTextBlock || st.CurrentMsgID != "" {
			item := []byte(`{"id":"","type":"message","status":"completed","content":[{"type":"output_text","annotations":[],"logprobs":[],"text":""}],"role":"assistant"}`)
			item, _ = sjson.SetBytes(item, "id", st.CurrentMsgID)
			item, _ = sjson.SetBytes(item, "content.0.text", st.TextBuf.String())
			outputsWrapper, _ = sjson.SetRawBytes(outputsWrapper, "arr.-1", item)
		}
		// function_call items (in ascending index order for determinism)
		if len(st.FuncArgsBuf) > 0 {
			// collect indices
			idxs := make([]int, 0, len(st.FuncArgsBuf))
			for idx := range st.FuncArgsBuf {
				idxs = append(idxs, idx)
			}
			// simple sort (small N), avoid adding new imports
			for i := 0; i < len(idxs); i++ {
				for j := i + 1; j < len(idxs); j++ {
					if idxs[j] < idxs[i] {
						idxs[i], idxs[j] = idxs[j], idxs[i]
					}
				}
			}
			for _, idx := range idxs {
				args := ""
				if b := st.FuncArgsBuf[idx]; b != nil {
					args = b.String()
				}
				callID := st.FuncCallIDs[idx]
				name := st.FuncNames[idx]
				if callID == "" && st.CurrentFCID != "" {
					callID = st.CurrentFCID
				}
				item := claudeResponsesToolItem(callID, name, args, "completed", st.FuncSpecs[idx])
				outputsWrapper, _ = sjson.SetRawBytes(outputsWrapper, "arr.-1", item)
			}
		}
		if gjson.GetBytes(outputsWrapper, "arr.#").Int() > 0 {
			completed, _ = sjson.SetRawBytes(completed, "response.output", []byte(gjson.GetBytes(outputsWrapper, "arr").Raw))
		}

		reasoningTokens := int64(0)
		if st.ReasoningBuf.Len() > 0 {
			reasoningTokens = int64(st.ReasoningBuf.Len() / 4)
		}
		usagePresent := st.UsageSeen || reasoningTokens > 0
		if usagePresent {
			completed, _ = sjson.SetBytes(completed, "response.usage.input_tokens", st.InputTokens)
			completed, _ = sjson.SetBytes(completed, "response.usage.input_tokens_details.cached_tokens", 0)
			completed, _ = sjson.SetBytes(completed, "response.usage.output_tokens", st.OutputTokens)
			if reasoningTokens > 0 {
				completed, _ = sjson.SetBytes(completed, "response.usage.output_tokens_details.reasoning_tokens", reasoningTokens)
			}
			total := st.InputTokens + st.OutputTokens
			if total > 0 || st.UsageSeen {
				completed, _ = sjson.SetBytes(completed, "response.usage.total_tokens", total)
			}
		}
		out = append(out, emitEvent("response.completed", completed))
		st.Completed = true
	}

	return out
}

// CompleteClaudeResponseToOpenAIResponses finalizes a clean EOF when an
// Anthropic-compatible upstream omits the terminal message_stop event.
func CompleteClaudeResponseToOpenAIResponses(ctx context.Context, modelName string, originalRequestRawJSON, requestRawJSON []byte, param *any) [][]byte {
	if param == nil || *param == nil {
		return claudeResponsesStreamFailure("", "Upstream Anthropic stream ended before message_start", param)
	}
	st, ok := (*param).(*claudeToResponsesState)
	if !ok || st.Completed {
		return nil
	}

	hasOutput := st.TextBuf.Len() > 0 || st.ReasoningBuf.Len() > 0 || len(st.FuncNames) > 0 || st.InTextBlock || st.InFuncBlock || st.ReasoningActive
	if strings.TrimSpace(st.ResponseID) == "" || !hasOutput {
		return claudeResponsesStreamFailure(st.ResponseID, "Upstream Anthropic stream ended before message_stop", param)
	}

	var out [][]byte
	if st.InTextBlock || st.InFuncBlock || st.ReasoningActive {
		closeEvent := []byte(fmt.Sprintf(`data: {"type":"content_block_stop","index":%d}`, st.CurrentBlockIndex))
		out = append(out, ConvertClaudeResponseToOpenAIResponses(ctx, modelName, originalRequestRawJSON, requestRawJSON, closeEvent, param)...)
	}
	if st.StopReason == "" {
		st.StreamTruncated = true
	}
	out = append(out, ConvertClaudeResponseToOpenAIResponses(ctx, modelName, originalRequestRawJSON, requestRawJSON, []byte(`data: {"type":"message_stop"}`), param)...)
	return out
}

func claudeResponsesStreamFailure(responseID, message string, param *any) [][]byte {
	st := &claudeToResponsesState{ResponseID: strings.TrimSpace(responseID), CreatedAt: time.Now().Unix(), Completed: true}
	if st.ResponseID == "" {
		st.ResponseID = fmt.Sprintf("resp_claude_%d", time.Now().UnixNano())
	}
	if param != nil {
		*param = st
	}
	failed := []byte(`{"type":"response.failed","sequence_number":1,"response":{"id":"","object":"response","created_at":0,"status":"failed","error":{"message":"","type":"stream_truncated"},"output":[]}}`)
	failed, _ = sjson.SetBytes(failed, "response.id", st.ResponseID)
	failed, _ = sjson.SetBytes(failed, "response.created_at", st.CreatedAt)
	failed, _ = sjson.SetBytes(failed, "response.error.message", message)
	return [][]byte{emitEvent("response.failed", failed)}
}

// ConvertClaudeResponseToOpenAIResponsesNonStream aggregates Claude SSE into a single OpenAI Responses JSON.
func ConvertClaudeResponseToOpenAIResponsesNonStream(_ context.Context, _ string, originalRequestRawJSON, requestRawJSON, rawJSON []byte, _ *any) []byte {
	// Aggregate Claude SSE lines into a single OpenAI Responses JSON (non-stream)
	// We follow the same aggregation logic as the streaming variant but produce
	// one final object matching docs/out.json structure.

	// Collect SSE data: lines start with "data: "; ignore others
	var chunks [][]byte
	{
		// Use a simple scanner to iterate through raw bytes
		// Note: extremely large responses may require increasing the buffer
		scanner := bufio.NewScanner(bytes.NewReader(rawJSON))
		buf := make([]byte, 52_428_800) // 50MB
		scanner.Buffer(buf, 52_428_800)
		for scanner.Scan() {
			line := scanner.Bytes()
			if !bytes.HasPrefix(line, dataTag) {
				continue
			}
			chunks = append(chunks, line[len(dataTag):])
		}
	}

	requestJSON := pickRequestJSON(originalRequestRawJSON, requestRawJSON)
	toolSpecs := claudeResponsesToolSpecsFromRequest(requestJSON)

	// Base OpenAI Responses (non-stream) object
	out := []byte(`{"id":"","object":"response","created_at":0,"status":"completed","background":false,"error":null,"incomplete_details":null,"output":[],"usage":{"input_tokens":0,"input_tokens_details":{"cached_tokens":0},"output_tokens":0,"output_tokens_details":{},"total_tokens":0}}`)

	// Aggregation state
	var (
		responseID      string
		createdAt       int64
		currentMsgID    string
		currentFCID     string
		textBuf         strings.Builder
		reasoningBuf    strings.Builder
		reasoningActive bool
		reasoningItemID string
		inputTokens     int64
		outputTokens    int64
	)

	// Per-index tool call aggregation
	type toolState struct {
		id   string
		name string
		args strings.Builder
	}
	toolCalls := make(map[int]*toolState)

	// Walk through SSE chunks to fill state
	for _, ch := range chunks {
		root := gjson.ParseBytes(ch)
		ev := root.Get("type").String()

		switch ev {
		case "message_start":
			if msg := root.Get("message"); msg.Exists() {
				responseID = msg.Get("id").String()
				createdAt = time.Now().Unix()
				if usage := msg.Get("usage"); usage.Exists() {
					inputTokens = usage.Get("input_tokens").Int()
				}
			}

		case "content_block_start":
			cb := root.Get("content_block")
			if !cb.Exists() {
				continue
			}
			idx := int(root.Get("index").Int())
			typ := cb.Get("type").String()
			switch typ {
			case "text":
				currentMsgID = "msg_" + responseID + "_0"
			case "tool_use":
				currentFCID = cb.Get("id").String()
				name := cb.Get("name").String()
				if toolCalls[idx] == nil {
					toolCalls[idx] = &toolState{id: currentFCID, name: name}
				} else {
					toolCalls[idx].id = currentFCID
					toolCalls[idx].name = name
				}
			case "thinking":
				reasoningActive = true
				reasoningItemID = fmt.Sprintf("rs_%s_%d", responseID, idx)
			}

		case "content_block_delta":
			d := root.Get("delta")
			if !d.Exists() {
				continue
			}
			dt := d.Get("type").String()
			switch dt {
			case "text_delta":
				if t := d.Get("text"); t.Exists() {
					textBuf.WriteString(t.String())
				}
			case "input_json_delta":
				if pj := d.Get("partial_json"); pj.Exists() {
					idx := int(root.Get("index").Int())
					if toolCalls[idx] == nil {
						toolCalls[idx] = &toolState{}
					}
					toolCalls[idx].args.WriteString(pj.String())
				}
			case "thinking_delta":
				if reasoningActive {
					if t := d.Get("thinking"); t.Exists() {
						reasoningBuf.WriteString(t.String())
					}
				}
			}

		case "content_block_stop":
			// Nothing special to finalize for non-stream aggregation
			_ = root

		case "message_delta":
			if usage := root.Get("usage"); usage.Exists() {
				outputTokens = usage.Get("output_tokens").Int()
			}
		}
	}

	// Populate base fields
	out, _ = sjson.SetBytes(out, "id", responseID)
	out, _ = sjson.SetBytes(out, "created_at", createdAt)

	// Inject request echo fields as top-level (similar to streaming variant)
	reqBytes := requestJSON
	if len(reqBytes) > 0 {
		req := gjson.ParseBytes(reqBytes)
		if v := req.Get("instructions"); v.Exists() {
			out, _ = sjson.SetBytes(out, "instructions", v.String())
		}
		if v := req.Get("max_output_tokens"); v.Exists() {
			out, _ = sjson.SetBytes(out, "max_output_tokens", v.Int())
		}
		if v := req.Get("max_tool_calls"); v.Exists() {
			out, _ = sjson.SetBytes(out, "max_tool_calls", v.Int())
		}
		if v := req.Get("model"); v.Exists() {
			out, _ = sjson.SetBytes(out, "model", v.String())
		}
		if v := req.Get("parallel_tool_calls"); v.Exists() {
			out, _ = sjson.SetBytes(out, "parallel_tool_calls", v.Bool())
		}
		if v := req.Get("previous_response_id"); v.Exists() {
			out, _ = sjson.SetBytes(out, "previous_response_id", v.String())
		}
		if v := req.Get("prompt_cache_key"); v.Exists() {
			out, _ = sjson.SetBytes(out, "prompt_cache_key", v.String())
		}
		if v := req.Get("reasoning"); v.Exists() {
			out, _ = sjson.SetBytes(out, "reasoning", v.Value())
		}
		if v := req.Get("safety_identifier"); v.Exists() {
			out, _ = sjson.SetBytes(out, "safety_identifier", v.String())
		}
		if v := req.Get("service_tier"); v.Exists() {
			out, _ = sjson.SetBytes(out, "service_tier", v.String())
		}
		if v := req.Get("store"); v.Exists() {
			out, _ = sjson.SetBytes(out, "store", v.Bool())
		}
		if v := req.Get("temperature"); v.Exists() {
			out, _ = sjson.SetBytes(out, "temperature", v.Float())
		}
		if v := req.Get("text"); v.Exists() {
			out, _ = sjson.SetBytes(out, "text", v.Value())
		}
		if v := req.Get("tool_choice"); v.Exists() {
			out, _ = sjson.SetBytes(out, "tool_choice", v.Value())
		}
		if v := req.Get("tools"); v.Exists() {
			out, _ = sjson.SetBytes(out, "tools", v.Value())
		}
		if v := req.Get("top_logprobs"); v.Exists() {
			out, _ = sjson.SetBytes(out, "top_logprobs", v.Int())
		}
		if v := req.Get("top_p"); v.Exists() {
			out, _ = sjson.SetBytes(out, "top_p", v.Float())
		}
		if v := req.Get("truncation"); v.Exists() {
			out, _ = sjson.SetBytes(out, "truncation", v.String())
		}
		if v := req.Get("user"); v.Exists() {
			out, _ = sjson.SetBytes(out, "user", v.Value())
		}
		if v := req.Get("metadata"); v.Exists() {
			out, _ = sjson.SetBytes(out, "metadata", v.Value())
		}
	}

	// Build output array
	outputsWrapper := []byte(`{"arr":[]}`)
	if reasoningBuf.Len() > 0 {
		item := []byte(`{"id":"","type":"reasoning","summary":[{"type":"summary_text","text":""}]}`)
		item, _ = sjson.SetBytes(item, "id", reasoningItemID)
		item, _ = sjson.SetBytes(item, "summary.0.text", reasoningBuf.String())
		outputsWrapper, _ = sjson.SetRawBytes(outputsWrapper, "arr.-1", item)
	}
	if currentMsgID != "" || textBuf.Len() > 0 {
		item := []byte(`{"id":"","type":"message","status":"completed","content":[{"type":"output_text","annotations":[],"logprobs":[],"text":""}],"role":"assistant"}`)
		item, _ = sjson.SetBytes(item, "id", currentMsgID)
		item, _ = sjson.SetBytes(item, "content.0.text", textBuf.String())
		outputsWrapper, _ = sjson.SetRawBytes(outputsWrapper, "arr.-1", item)
	}
	if len(toolCalls) > 0 {
		// Preserve index order
		idxs := make([]int, 0, len(toolCalls))
		for i := range toolCalls {
			idxs = append(idxs, i)
		}
		for i := 0; i < len(idxs); i++ {
			for j := i + 1; j < len(idxs); j++ {
				if idxs[j] < idxs[i] {
					idxs[i], idxs[j] = idxs[j], idxs[i]
				}
			}
		}
		for _, i := range idxs {
			st := toolCalls[i]
			args := st.args.String()
			if args == "" {
				args = "{}"
			}
			item := claudeResponsesToolItem(st.id, st.name, args, "completed", toolSpecs[st.name])
			outputsWrapper, _ = sjson.SetRawBytes(outputsWrapper, "arr.-1", item)
		}
	}
	if gjson.GetBytes(outputsWrapper, "arr.#").Int() > 0 {
		out, _ = sjson.SetRawBytes(out, "output", []byte(gjson.GetBytes(outputsWrapper, "arr").Raw))
	}

	// Usage
	total := inputTokens + outputTokens
	out, _ = sjson.SetBytes(out, "usage.input_tokens", inputTokens)
	out, _ = sjson.SetBytes(out, "usage.output_tokens", outputTokens)
	out, _ = sjson.SetBytes(out, "usage.total_tokens", total)
	if reasoningBuf.Len() > 0 {
		// Rough estimate similar to chat completions
		reasoningTokens := int64(len(reasoningBuf.String()) / 4)
		if reasoningTokens > 0 {
			out, _ = sjson.SetBytes(out, "usage.output_tokens_details.reasoning_tokens", reasoningTokens)
		}
	}

	return out
}
