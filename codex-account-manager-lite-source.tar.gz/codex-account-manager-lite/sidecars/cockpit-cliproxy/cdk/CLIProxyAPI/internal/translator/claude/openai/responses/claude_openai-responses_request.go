package responses

import (
	"crypto/rand"
	"fmt"
	"math/big"
	"strings"

	"github.com/router-for-me/CLIProxyAPI/v7/internal/registry"
	"github.com/router-for-me/CLIProxyAPI/v7/internal/thinking"
	"github.com/tidwall/gjson"
	"github.com/tidwall/sjson"
)

const customToolInputSchemaJSON = `{"type":"object","properties":{"input":{"type":"string"}},"required":["input"]}`
const toolSearchInputSchemaJSON = `{"type":"object","properties":{"query":{"type":"string"},"limit":{"type":"integer"}}}`

// ConvertOpenAIResponsesRequestToClaude transforms an OpenAI Responses API request
// into a Claude Messages API request using only gjson/sjson for JSON handling.
// It supports:
// - instructions -> system message
// - input[].type==message with input_text/output_text -> user/assistant messages
// - function_call -> assistant tool_use
// - function_call_output -> user tool_result
// - tools[].parameters -> tools[].input_schema
// - max_output_tokens -> max_tokens
// - stream passthrough via parameter
func ConvertOpenAIResponsesRequestToClaude(modelName string, inputRawJSON []byte, stream bool) []byte {
	rawJSON := inputRawJSON

	// Base Claude message payload
	// Authentication-aware metadata is injected by ClaudeExecutor after this
	// translation. Keeping it out of the translator avoids cross-request state.
	out := []byte(`{"model":"","max_tokens":32000,"messages":[]}`)

	root := gjson.ParseBytes(rawJSON)

	// Convert OpenAI Responses reasoning.effort to Claude thinking config.
	if v := root.Get("reasoning.effort"); v.Exists() {
		effort := strings.ToLower(strings.TrimSpace(v.String()))
		if effort != "" {
			mi := registry.LookupModelInfo(modelName, "claude")
			supportsAdaptive := mi != nil && mi.Thinking != nil && len(mi.Thinking.Levels) > 0
			supportsMax := supportsAdaptive && thinking.HasLevel(mi.Thinking.Levels, string(thinking.LevelMax))

			// Claude 4.6 supports adaptive thinking with output_config.effort.
			// MapToClaudeEffort normalizes levels (e.g. minimal→low, xhigh→high) to avoid
			// validation errors since validate treats same-provider unsupported levels as errors.
			if supportsAdaptive {
				switch effort {
				case "none":
					out, _ = sjson.SetBytes(out, "thinking.type", "disabled")
					out, _ = sjson.DeleteBytes(out, "thinking.budget_tokens")
					out, _ = sjson.DeleteBytes(out, "output_config.effort")
				case "auto":
					out, _ = sjson.SetBytes(out, "thinking.type", "adaptive")
					out, _ = sjson.DeleteBytes(out, "thinking.budget_tokens")
					out, _ = sjson.DeleteBytes(out, "output_config.effort")
				default:
					if mapped, ok := thinking.MapToClaudeEffort(effort, supportsMax); ok {
						effort = mapped
					}
					out, _ = sjson.SetBytes(out, "thinking.type", "adaptive")
					out, _ = sjson.DeleteBytes(out, "thinking.budget_tokens")
					out, _ = sjson.SetBytes(out, "output_config.effort", effort)
				}
			} else {
				// Legacy/manual thinking (budget_tokens).
				budget, ok := thinking.ConvertLevelToBudget(effort)
				if ok {
					switch budget {
					case 0:
						out, _ = sjson.SetBytes(out, "thinking.type", "disabled")
					case -1:
						out, _ = sjson.SetBytes(out, "thinking.type", "enabled")
					default:
						if budget > 0 {
							out, _ = sjson.SetBytes(out, "thinking.type", "enabled")
							out, _ = sjson.SetBytes(out, "thinking.budget_tokens", budget)
						}
					}
				}
			}
		}
	}

	// Helper for generating tool call IDs when missing
	genToolCallID := func() string {
		const letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
		var b strings.Builder
		for i := 0; i < 24; i++ {
			n, _ := rand.Int(rand.Reader, big.NewInt(int64(len(letters))))
			b.WriteByte(letters[n.Int64()])
		}
		return "toolu_" + b.String()
	}

	// Model
	out, _ = sjson.SetBytes(out, "model", modelName)

	// Max tokens
	if mot := root.Get("max_output_tokens"); mot.Exists() {
		out, _ = sjson.SetBytes(out, "max_tokens", mot.Int())
	}

	// Anthropic requires thinking.budget_tokens < max_tokens. The thinking
	// config and max_tokens are derived independently above, so a high effort
	// level (xhigh maps to 32768) can exceed the default 32000 max_tokens and
	// make the upstream reject the whole turn. Reconcile them here, once both
	// values are final.
	out = reconcileClaudeThinkingBudget(out)

	// Stream
	out, _ = sjson.SetBytes(out, "stream", stream)

	// instructions -> Anthropic top-level system prompt. Sending the Codex
	// operating instructions as a user message makes Claude answer them as if
	// they were a chat turn, so it replies once and stops instead of driving the
	// tool loop.
	instructionsText := ""
	extractedFromSystem := false
	if instr := root.Get("instructions"); instr.Exists() && instr.Type == gjson.String {
		instructionsText = instr.String()
		if instructionsText != "" {
			out, _ = sjson.SetBytes(out, "system", instructionsText)
		}
	}

	if instructionsText == "" {
		if input := root.Get("input"); input.Exists() && input.IsArray() {
			input.ForEach(func(_, item gjson.Result) bool {
				if strings.EqualFold(item.Get("role").String(), "system") {
					var builder strings.Builder
					if parts := item.Get("content"); parts.Exists() && parts.IsArray() {
						parts.ForEach(func(_, part gjson.Result) bool {
							textResult := part.Get("text")
							text := textResult.String()
							if builder.Len() > 0 && text != "" {
								builder.WriteByte('\n')
							}
							builder.WriteString(text)
							return true
						})
					} else if parts.Type == gjson.String {
						builder.WriteString(parts.String())
					}
					instructionsText = builder.String()
					if instructionsText != "" {
						out, _ = sjson.SetBytes(out, "system", instructionsText)
						extractedFromSystem = true
					}
				}
				return instructionsText == ""
			})
		}
	}

	// input array processing
	if input := root.Get("input"); input.Exists() && input.IsArray() {
		input.ForEach(func(_, item gjson.Result) bool {
			if extractedFromSystem && strings.EqualFold(item.Get("role").String(), "system") {
				return true
			}
			typ := item.Get("type").String()
			if typ == "" && item.Get("role").String() != "" {
				typ = "message"
			}
			switch typ {
			case "message":
				// Determine role and construct Claude-compatible content parts.
				var role string
				var textAggregate strings.Builder
				var partsJSON []string
				hasImage := false
				hasFile := false
				if parts := item.Get("content"); parts.Exists() && parts.IsArray() {
					parts.ForEach(func(_, part gjson.Result) bool {
						ptype := part.Get("type").String()
						switch ptype {
						case "input_text", "output_text":
							if t := part.Get("text"); t.Exists() {
								txt := t.String()
								textAggregate.WriteString(txt)
								contentPart := []byte(`{"type":"text","text":""}`)
								contentPart, _ = sjson.SetBytes(contentPart, "text", txt)
								partsJSON = append(partsJSON, string(contentPart))
							}
							if ptype == "input_text" {
								role = "user"
							} else {
								role = "assistant"
							}
						case "input_image":
							url := part.Get("image_url").String()
							if url == "" {
								url = part.Get("url").String()
							}
							if url != "" {
								var contentPart []byte
								if strings.HasPrefix(url, "data:") {
									trimmed := strings.TrimPrefix(url, "data:")
									mediaAndData := strings.SplitN(trimmed, ";base64,", 2)
									mediaType := "application/octet-stream"
									data := ""
									if len(mediaAndData) == 2 {
										if mediaAndData[0] != "" {
											mediaType = mediaAndData[0]
										}
										data = mediaAndData[1]
									}
									if data != "" {
										contentPart = []byte(`{"type":"image","source":{"type":"base64","media_type":"","data":""}}`)
										contentPart, _ = sjson.SetBytes(contentPart, "source.media_type", mediaType)
										contentPart, _ = sjson.SetBytes(contentPart, "source.data", data)
									}
								} else {
									contentPart = []byte(`{"type":"image","source":{"type":"url","url":""}}`)
									contentPart, _ = sjson.SetBytes(contentPart, "source.url", url)
								}
								if len(contentPart) > 0 {
									partsJSON = append(partsJSON, string(contentPart))
									if role == "" {
										role = "user"
									}
									hasImage = true
								}
							}
						case "input_file":
							fileData := part.Get("file_data").String()
							if fileData != "" {
								mediaType := "application/octet-stream"
								data := fileData
								if strings.HasPrefix(fileData, "data:") {
									trimmed := strings.TrimPrefix(fileData, "data:")
									mediaAndData := strings.SplitN(trimmed, ";base64,", 2)
									if len(mediaAndData) == 2 {
										if mediaAndData[0] != "" {
											mediaType = mediaAndData[0]
										}
										data = mediaAndData[1]
									}
								}
								contentPart := []byte(`{"type":"document","source":{"type":"base64","media_type":"","data":""}}`)
								contentPart, _ = sjson.SetBytes(contentPart, "source.media_type", mediaType)
								contentPart, _ = sjson.SetBytes(contentPart, "source.data", data)
								partsJSON = append(partsJSON, string(contentPart))
								if role == "" {
									role = "user"
								}
								hasFile = true
							}
						}
						return true
					})
				} else if parts.Type == gjson.String {
					textAggregate.WriteString(parts.String())
				}

				// Fallback to given role if content types not decisive
				if role == "" {
					r := item.Get("role").String()
					switch r {
					case "user", "assistant", "system":
						role = r
					default:
						role = "user"
					}
				}

				if len(partsJSON) > 0 {
					msg := []byte(`{"role":"","content":[]}`)
					msg, _ = sjson.SetBytes(msg, "role", role)
					if len(partsJSON) == 1 && !hasImage && !hasFile {
						// Preserve legacy behavior for single text content
						msg, _ = sjson.DeleteBytes(msg, "content")
						textPart := gjson.Parse(partsJSON[0])
						msg, _ = sjson.SetBytes(msg, "content", textPart.Get("text").String())
					} else {
						for _, partJSON := range partsJSON {
							msg, _ = sjson.SetRawBytes(msg, "content.-1", []byte(partJSON))
						}
					}
					out, _ = sjson.SetRawBytes(out, "messages.-1", msg)
				} else if textAggregate.Len() > 0 || role == "system" {
					msg := []byte(`{"role":"","content":""}`)
					msg, _ = sjson.SetBytes(msg, "role", role)
					msg, _ = sjson.SetBytes(msg, "content", textAggregate.String())
					out, _ = sjson.SetRawBytes(out, "messages.-1", msg)
				}

			case "function_call":
				// Map to assistant tool_use
				callID := item.Get("call_id").String()
				if callID == "" {
					callID = genToolCallID()
				}
				name := item.Get("name").String()
				argsStr := item.Get("arguments").String()

				toolUse := []byte(`{"type":"tool_use","id":"","name":"","input":{}}`)
				toolUse, _ = sjson.SetBytes(toolUse, "id", callID)
				toolUse, _ = sjson.SetBytes(toolUse, "name", name)
				if argsStr != "" && gjson.Valid(argsStr) {
					argsJSON := gjson.Parse(argsStr)
					if argsJSON.IsObject() {
						toolUse, _ = sjson.SetRawBytes(toolUse, "input", []byte(argsJSON.Raw))
					}
				}

				asst := []byte(`{"role":"assistant","content":[]}`)
				asst, _ = sjson.SetRawBytes(asst, "content.-1", toolUse)
				out, _ = sjson.SetRawBytes(out, "messages.-1", asst)

			case "custom_tool_call":
				callID := item.Get("call_id").String()
				if callID == "" {
					callID = genToolCallID()
				}
				toolUse := []byte(`{"type":"tool_use","id":"","name":"","input":{"input":""}}`)
				toolUse, _ = sjson.SetBytes(toolUse, "id", callID)
				toolUse, _ = sjson.SetBytes(toolUse, "name", item.Get("name").String())
				toolUse, _ = sjson.SetBytes(toolUse, "input.input", item.Get("input").String())

				asst := []byte(`{"role":"assistant","content":[]}`)
				asst, _ = sjson.SetRawBytes(asst, "content.-1", toolUse)
				out, _ = sjson.SetRawBytes(out, "messages.-1", asst)

			case "tool_search_call":
				callID := item.Get("call_id").String()
				if callID == "" {
					callID = genToolCallID()
				}
				toolUse := []byte(`{"type":"tool_use","id":"","name":"tool_search","input":{}}`)
				toolUse, _ = sjson.SetBytes(toolUse, "id", callID)
				if arguments := item.Get("arguments"); arguments.Exists() && arguments.IsObject() {
					toolUse, _ = sjson.SetRawBytes(toolUse, "input", []byte(arguments.Raw))
				}

				asst := []byte(`{"role":"assistant","content":[]}`)
				asst, _ = sjson.SetRawBytes(asst, "content.-1", toolUse)
				out, _ = sjson.SetRawBytes(out, "messages.-1", asst)

			case "function_call_output", "custom_tool_call_output", "tool_search_output":
				// Map to user tool_result
				callID := item.Get("call_id").String()
				outputStr := item.Get("output").String()
				toolResult := []byte(`{"type":"tool_result","tool_use_id":"","content":""}`)
				toolResult, _ = sjson.SetBytes(toolResult, "tool_use_id", callID)
				toolResult, _ = sjson.SetBytes(toolResult, "content", outputStr)

				usr := []byte(`{"role":"user","content":[]}`)
				usr, _ = sjson.SetRawBytes(usr, "content.-1", toolResult)
				out, _ = sjson.SetRawBytes(out, "messages.-1", usr)
			}
			return true
		})
	}

	includedToolNames := map[string]struct{}{}
	toolNameMap := map[string]string{}

	// Collect both initially declared and dynamically loaded Codex tools.
	toolsJSON := []byte("[]")
	forEachResponsesTool(root, func(tool gjson.Result) {
		convertedTools := convertResponsesToolToClaudeTools(tool, toolNameMap)
		for _, tJSON := range convertedTools {
			toolName := gjson.GetBytes(tJSON, "name").String()
			if toolName == "" {
				continue
			}
			if _, duplicate := includedToolNames[toolName]; duplicate {
				continue
			}
			includedToolNames[toolName] = struct{}{}
			toolsJSON, _ = sjson.SetRawBytes(toolsJSON, "-1", tJSON)
		}
	})
	if parsedTools := gjson.ParseBytes(toolsJSON); parsedTools.IsArray() && len(parsedTools.Array()) > 0 {
		out, _ = sjson.SetRawBytes(out, "tools", toolsJSON)
	}

	// Map tool_choice similar to Chat Completions translator (optional in docs, safe to handle)
	if toolChoice := root.Get("tool_choice"); toolChoice.Exists() {
		switch toolChoice.Type {
		case gjson.String:
			switch toolChoice.String() {
			case "auto":
				out, _ = sjson.SetRawBytes(out, "tool_choice", []byte(`{"type":"auto"}`))
			case "none":
				// Leave unset; implies no tools
			case "required":
				if len(includedToolNames) > 0 {
					out, _ = sjson.SetRawBytes(out, "tool_choice", []byte(`{"type":"any"}`))
				}
			}
		case gjson.JSON:
			choiceType := toolChoice.Get("type").String()
			if choiceType == "function" || choiceType == "custom" || choiceType == "tool_search" {
				fn := toolChoice.Get("function.name").String()
				if fn == "" {
					fn = toolChoice.Get("name").String()
				}
				if fn == "" && choiceType == "tool_search" {
					fn = "tool_search"
				}
				if mappedName := toolNameMap[fn]; mappedName != "" {
					fn = mappedName
				}
				if _, ok := includedToolNames[fn]; ok {
					toolChoiceJSON := []byte(`{"name":"","type":"tool"}`)
					toolChoiceJSON, _ = sjson.SetBytes(toolChoiceJSON, "name", fn)
					out, _ = sjson.SetRawBytes(out, "tool_choice", toolChoiceJSON)
				}
			}
		default:

		}
	}

	// Anthropic expects one message per conversational turn with strictly
	// alternating roles. The input loop above emits a separate message for every
	// Responses item, so an assistant turn that produced text plus two tool calls
	// becomes three adjacent assistant messages. Fold same-role neighbours back
	// into single messages so tool_use blocks stay attached to the assistant turn
	// that produced them and their tool_result blocks line up in the next turn.
	out = mergeAdjacentClaudeMessages(out)

	return out
}

// mergeAdjacentClaudeMessages collapses consecutive messages that share a role
// into one message whose content is the concatenation of the originals. String
// content is promoted to a text block so it can be merged with block content.
func mergeAdjacentClaudeMessages(body []byte) []byte {
	messages := gjson.GetBytes(body, "messages")
	if !messages.IsArray() {
		return body
	}
	items := messages.Array()
	if len(items) < 2 {
		return body
	}

	merged := []byte(`[]`)
	mergedCount := 0
	lastRole := ""
	changed := false
	for _, item := range items {
		role := item.Get("role").String()
		blocks := claudeMessageContentBlocks(item.Get("content"))
		if len(blocks) == 0 {
			merged, _ = sjson.SetRawBytes(merged, "-1", []byte(item.Raw))
			mergedCount++
			lastRole = role
			continue
		}
		if role != "" && role == lastRole && mergedCount > 0 {
			target := fmt.Sprintf("%d.content", mergedCount-1)
			for _, block := range blocks {
				merged, _ = sjson.SetRawBytes(merged, target+".-1", block)
			}
			changed = true
			continue
		}
		msg := []byte(`{"role":"","content":[]}`)
		msg, _ = sjson.SetBytes(msg, "role", role)
		for _, block := range blocks {
			msg, _ = sjson.SetRawBytes(msg, "content.-1", block)
		}
		merged, _ = sjson.SetRawBytes(merged, "-1", msg)
		mergedCount++
		lastRole = role
	}
	if !changed {
		return body
	}
	body, _ = sjson.SetRawBytes(body, "messages", merged)
	return body
}

// claudeMessageContentBlocks normalizes Claude message content into a slice of
// content blocks. Plain string content becomes a single text block.
func claudeMessageContentBlocks(content gjson.Result) [][]byte {
	switch {
	case content.IsArray():
		var blocks [][]byte
		content.ForEach(func(_, block gjson.Result) bool {
			blocks = append(blocks, []byte(block.Raw))
			return true
		})
		return blocks
	case content.Type == gjson.String:
		if content.String() == "" {
			return nil
		}
		block := []byte(`{"type":"text","text":""}`)
		block, _ = sjson.SetBytes(block, "text", content.String())
		return [][]byte{block}
	default:
		return nil
	}
}

// claudeMinThinkingBudget is the smallest extended-thinking budget Anthropic
// accepts. Clamping below this value is rejected, so max_tokens has to grow
// instead when the requested budget cannot be reduced far enough.
const claudeMinThinkingBudget = 1024

// reconcileClaudeThinkingBudget enforces Anthropic's thinking.budget_tokens <
// max_tokens constraint. The Responses request maps reasoning.effort and
// max_output_tokens independently, so a high effort level can produce a budget
// that meets or exceeds max_tokens and makes the upstream reject the request
// with "thinking.budget_tokens must be less than max_tokens".
//
// Preference order mirrors the upstream thinking middleware: shrink the budget
// to fit under max_tokens, and only raise max_tokens when shrinking would push
// the budget below the provider minimum.
func reconcileClaudeThinkingBudget(body []byte) []byte {
	budgetResult := gjson.GetBytes(body, "thinking.budget_tokens")
	if !budgetResult.Exists() {
		return body
	}
	budget := budgetResult.Int()
	if budget <= 0 {
		return body
	}
	maxTokensResult := gjson.GetBytes(body, "max_tokens")
	if !maxTokensResult.Exists() {
		return body
	}
	maxTokens := maxTokensResult.Int()
	if maxTokens <= 0 || budget < maxTokens {
		return body
	}

	if clamped := maxTokens - 1; clamped >= claudeMinThinkingBudget {
		body, _ = sjson.SetBytes(body, "thinking.budget_tokens", clamped)
		return body
	}

	body, _ = sjson.SetBytes(body, "max_tokens", budget+1)
	return body
}

func convertResponsesToolToClaudeTools(tool gjson.Result, toolNameMap map[string]string) [][]byte {
	toolType := strings.TrimSpace(tool.Get("type").String())
	switch toolType {
	case "", "function":
		if tJSON, ok := convertResponsesFunctionToolToClaude(tool, ""); ok {
			return [][]byte{tJSON}
		}
	case "custom":
		if tJSON, ok := convertResponsesCustomToolToClaude(tool, ""); ok {
			return [][]byte{tJSON}
		}
	case "tool_search":
		toolNameMap["tool_search"] = "tool_search"
		return [][]byte{newClaudeTool(
			"tool_search",
			"Search and load Codex tools, plugins, connectors, and MCP namespaces for the current task.",
			[]byte(toolSearchInputSchemaJSON),
		)}
	case "namespace":
		return convertResponsesNamespaceToolToClaude(tool, toolNameMap)
	case "web_search":
		if tJSON, ok := convertResponsesWebSearchToolToClaude(tool); ok {
			if name := gjson.GetBytes(tJSON, "name").String(); name != "" {
				toolNameMap[name] = name
			}
			return [][]byte{tJSON}
		}
	default:
		if isUnsupportedOpenAIBuiltinToolType(toolType) {
			return nil
		}
	}
	return nil
}

func forEachResponsesTool(root gjson.Result, visit func(gjson.Result)) {
	if tools := root.Get("tools"); tools.IsArray() {
		tools.ForEach(func(_, tool gjson.Result) bool {
			visit(tool)
			return true
		})
	}
	collectEmbeddedResponsesTools(root.Get("input"), visit)
}

func collectEmbeddedResponsesTools(value gjson.Result, visit func(gjson.Result)) {
	if !value.Exists() {
		return
	}
	if value.IsArray() {
		value.ForEach(func(_, item gjson.Result) bool {
			collectEmbeddedResponsesTools(item, visit)
			return true
		})
		return
	}
	if !value.IsObject() {
		return
	}
	itemType := value.Get("type").String()
	if itemType == "additional_tools" || itemType == "tool_search_output" {
		value.Get("tools").ForEach(func(_, tool gjson.Result) bool {
			visit(tool)
			return true
		})
	}
	value.ForEach(func(_, child gjson.Result) bool {
		collectEmbeddedResponsesTools(child, visit)
		return true
	})
}

func convertResponsesNamespaceToolToClaude(tool gjson.Result, toolNameMap map[string]string) [][]byte {
	namespaceName := strings.TrimSpace(tool.Get("name").String())
	children := tool.Get("tools")
	if !children.Exists() || !children.IsArray() {
		return nil
	}

	var out [][]byte
	children.ForEach(func(_, child gjson.Result) bool {
		childName := responsesToolName(child)
		qualifiedName := qualifyResponsesNamespaceToolName(namespaceName, childName)
		var tJSON []byte
		var ok bool
		if child.Get("type").String() == "custom" {
			tJSON, ok = convertResponsesCustomToolToClaude(child, qualifiedName)
		} else {
			tJSON, ok = convertResponsesFunctionToolToClaude(child, qualifiedName)
		}
		if ok {
			out = append(out, tJSON)
			toolNameMap[qualifiedName] = qualifiedName
			if childName != "" {
				toolNameMap[childName] = qualifiedName
			}
		}
		return true
	})
	return out
}

func convertResponsesFunctionToolToClaude(tool gjson.Result, overrideName string) ([]byte, bool) {
	name := strings.TrimSpace(overrideName)
	if name == "" {
		name = responsesToolName(tool)
	}
	if name == "" {
		return nil, false
	}

	return newClaudeTool(name, responsesToolDescription(tool), normalizeClaudeToolInputSchema(responsesToolParameters(tool))), true
}

func convertResponsesCustomToolToClaude(tool gjson.Result, overrideName string) ([]byte, bool) {
	name := strings.TrimSpace(overrideName)
	if name == "" {
		name = responsesToolName(tool)
	}
	if name == "" {
		return nil, false
	}
	return newClaudeTool(name, responsesToolDescription(tool), []byte(customToolInputSchemaJSON)), true
}

func newClaudeTool(name, description string, inputSchema []byte) []byte {
	tJSON := []byte(`{"name":"","input_schema":{}}`)
	tJSON, _ = sjson.SetBytes(tJSON, "name", name)
	if description != "" {
		tJSON, _ = sjson.SetBytes(tJSON, "description", description)
	}
	tJSON, _ = sjson.SetRawBytes(tJSON, "input_schema", inputSchema)
	return tJSON
}

func convertResponsesWebSearchToolToClaude(tool gjson.Result) ([]byte, bool) {
	if externalWebAccess := tool.Get("external_web_access"); externalWebAccess.Exists() && !externalWebAccess.Bool() {
		return nil, false
	}

	name := strings.TrimSpace(tool.Get("name").String())
	if name == "" {
		name = "web_search"
	}
	tJSON := []byte(`{"type":"web_search_20250305","name":""}`)
	tJSON, _ = sjson.SetBytes(tJSON, "name", name)
	if maxUses := tool.Get("max_uses"); maxUses.Exists() {
		tJSON, _ = sjson.SetBytes(tJSON, "max_uses", maxUses.Int())
	}
	if allowedDomains := tool.Get("filters.allowed_domains"); allowedDomains.Exists() && allowedDomains.IsArray() {
		tJSON, _ = sjson.SetRawBytes(tJSON, "allowed_domains", []byte(allowedDomains.Raw))
	}
	if userLocation := tool.Get("user_location"); userLocation.Exists() && userLocation.IsObject() {
		tJSON, _ = sjson.SetRawBytes(tJSON, "user_location", []byte(userLocation.Raw))
	}
	return tJSON, true
}

func responsesToolName(tool gjson.Result) string {
	if name := strings.TrimSpace(tool.Get("name").String()); name != "" {
		return name
	}
	return strings.TrimSpace(tool.Get("function.name").String())
}

func responsesToolDescription(tool gjson.Result) string {
	if description := tool.Get("description").String(); description != "" {
		return description
	}
	return tool.Get("function.description").String()
}

func responsesToolParameters(tool gjson.Result) gjson.Result {
	for _, path := range []string{
		"parameters",
		"parametersJsonSchema",
		"input_schema",
		"function.parameters",
		"function.parametersJsonSchema",
	} {
		if parameters := tool.Get(path); parameters.Exists() {
			return parameters
		}
	}
	return gjson.Result{}
}

func normalizeClaudeToolInputSchema(parameters gjson.Result) []byte {
	raw := strings.TrimSpace(parameters.Raw)
	if raw == "" || raw == "null" || !gjson.Valid(raw) {
		return []byte(`{"type":"object","properties":{}}`)
	}
	result := gjson.Parse(raw)
	if !result.IsObject() {
		return []byte(`{"type":"object","properties":{}}`)
	}
	schema := []byte(raw)
	schemaType := result.Get("type").String()
	if schemaType == "" {
		schema, _ = sjson.SetBytes(schema, "type", "object")
		schemaType = "object"
	}
	if schemaType == "object" && !result.Get("properties").Exists() {
		schema, _ = sjson.SetRawBytes(schema, "properties", []byte(`{}`))
	}
	return schema
}

func qualifyResponsesNamespaceToolName(namespaceName, childName string) string {
	childName = strings.TrimSpace(childName)
	if childName == "" || namespaceName == "" || strings.HasPrefix(childName, "mcp__") {
		return childName
	}
	if strings.HasPrefix(childName, namespaceName) {
		return childName
	}
	if strings.HasSuffix(namespaceName, "__") {
		return namespaceName + childName
	}
	return namespaceName + "__" + childName
}

func isUnsupportedOpenAIBuiltinToolType(toolType string) bool {
	switch toolType {
	case "image_generation", "file_search", "code_interpreter", "computer_use_preview":
		return true
	default:
		return false
	}
}
