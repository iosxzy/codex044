package executor

import (
	"bytes"
	"context"
	"crypto"
	"crypto/ed25519"
	"crypto/sha512"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	cliproxyauth "github.com/router-for-me/CLIProxyAPI/v7/sdk/cliproxy/auth"
	"golang.org/x/crypto/curve25519"
	"golang.org/x/crypto/nacl/box"
)

const agentIdentityAuthAPIBaseURL = "https://auth.openai.com/api/accounts"

var codexAgentIdentityLocks sync.Map

type codexAgentIdentityKey struct {
	runtimeID  string
	privateKey ed25519.PrivateKey
	taskID     string
}

type codexAgentIdentityTaskResponse struct {
	TaskID               string `json:"task_id"`
	TaskIDCamel          string `json:"taskId"`
	EncryptedTaskID      string `json:"encrypted_task_id"`
	EncryptedTaskIDCamel string `json:"encryptedTaskId"`
}

type codexHTTPDoer interface {
	Do(*http.Request) (*http.Response, error)
}

func codexAgentIdentityMetadataString(auth *cliproxyauth.Auth, key string) string {
	if auth == nil || auth.Metadata == nil {
		return ""
	}
	if value, ok := auth.Metadata[key].(string); ok {
		return strings.TrimSpace(value)
	}
	for _, nestedKey := range []string{"agent_identity", "agentIdentity"} {
		nested, ok := auth.Metadata[nestedKey].(map[string]any)
		if !ok {
			continue
		}
		if value, ok := nested[key].(string); ok {
			return strings.TrimSpace(value)
		}
	}
	return ""
}

func isCodexAgentIdentity(auth *cliproxyauth.Auth) bool {
	mode := strings.ToLower(codexAgentIdentityMetadataString(auth, "auth_mode"))
	return mode == "agentidentity" || mode == "agent_identity" || codexAgentIdentityMetadataString(auth, "agent_runtime_id") != ""
}

func codexAgentIdentityKeyFromAuth(auth *cliproxyauth.Auth) (codexAgentIdentityKey, error) {
	runtimeID := codexAgentIdentityMetadataString(auth, "agent_runtime_id")
	if runtimeID == "" {
		return codexAgentIdentityKey{}, errors.New("agent identity runtime id is missing")
	}
	encodedPrivateKey := codexAgentIdentityMetadataString(auth, "agent_private_key")
	if encodedPrivateKey == "" {
		return codexAgentIdentityKey{}, errors.New("agent identity private key is missing")
	}
	der, err := base64.StdEncoding.DecodeString(encodedPrivateKey)
	if err != nil {
		return codexAgentIdentityKey{}, errors.New("agent identity private key is not valid base64")
	}
	parsed, err := x509.ParsePKCS8PrivateKey(der)
	if err != nil {
		return codexAgentIdentityKey{}, errors.New("agent identity private key is not valid PKCS#8")
	}
	privateKey, ok := parsed.(ed25519.PrivateKey)
	if !ok || len(privateKey) != ed25519.PrivateKeySize {
		return codexAgentIdentityKey{}, errors.New("agent identity private key is not Ed25519")
	}
	return codexAgentIdentityKey{
		runtimeID:  runtimeID,
		privateKey: privateKey,
		taskID:     codexAgentIdentityMetadataString(auth, "task_id"),
	}, nil
}

func buildCodexAgentAssertion(key codexAgentIdentityKey, now time.Time) (string, error) {
	if key.runtimeID == "" || key.taskID == "" {
		return "", errors.New("agent identity runtime or task id is missing")
	}
	timestamp := now.UTC().Format(time.RFC3339)
	signature, err := key.privateKey.Sign(nil, []byte(key.runtimeID+":"+key.taskID+":"+timestamp), crypto.Hash(0))
	if err != nil {
		return "", errors.New("failed to sign agent assertion")
	}
	envelope, err := json.Marshal(map[string]string{
		"agent_runtime_id": key.runtimeID,
		"task_id":          key.taskID,
		"timestamp":        timestamp,
		"signature":        base64.StdEncoding.EncodeToString(signature),
	})
	if err != nil {
		return "", errors.New("failed to serialize agent assertion")
	}
	return "AgentAssertion " + base64.RawURLEncoding.EncodeToString(envelope), nil
}

func decryptCodexAgentTaskID(key codexAgentIdentityKey, encoded string) (string, error) {
	ciphertext, err := base64.StdEncoding.DecodeString(strings.TrimSpace(encoded))
	if err != nil {
		return "", errors.New("encrypted agent task id is not valid base64")
	}
	digest := sha512.Sum512(key.privateKey.Seed())
	var curvePrivate [32]byte
	copy(curvePrivate[:], digest[:32])
	curvePrivate[0] &= 248
	curvePrivate[31] &= 127
	curvePrivate[31] |= 64
	curvePublicBytes, err := curve25519.X25519(curvePrivate[:], curve25519.Basepoint)
	if err != nil {
		return "", errors.New("failed to derive agent identity decryption key")
	}
	var curvePublic [32]byte
	copy(curvePublic[:], curvePublicBytes)
	plaintext, ok := box.OpenAnonymous(nil, ciphertext, &curvePublic, &curvePrivate)
	if !ok {
		return "", errors.New("failed to decrypt encrypted agent task id")
	}
	taskID := strings.TrimSpace(string(plaintext))
	if taskID == "" {
		return "", errors.New("decrypted agent task id is empty")
	}
	return taskID, nil
}

func registerCodexAgentIdentityTask(ctx context.Context, client codexHTTPDoer, key codexAgentIdentityKey) (string, error) {
	timestamp := time.Now().UTC().Format(time.RFC3339)
	signature, err := key.privateKey.Sign(nil, []byte(key.runtimeID+":"+timestamp), crypto.Hash(0))
	if err != nil {
		return "", errors.New("failed to sign agent task registration")
	}
	body, err := json.Marshal(map[string]string{
		"timestamp": timestamp,
		"signature": base64.StdEncoding.EncodeToString(signature),
	})
	if err != nil {
		return "", errors.New("failed to serialize agent task registration")
	}
	registerCtx, cancel := context.WithTimeout(ctx, 30*time.Second)
	defer cancel()
	url := strings.TrimRight(agentIdentityAuthAPIBaseURL, "/") + "/v1/agent/" + key.runtimeID + "/task/register"
	req, err := http.NewRequestWithContext(registerCtx, http.MethodPost, url, bytes.NewReader(body))
	if err != nil {
		return "", errors.New("failed to build agent task registration request")
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json")
	resp, err := client.Do(req)
	if err != nil {
		return "", errors.New("agent task registration request failed")
	}
	defer resp.Body.Close()
	if resp.StatusCode < http.StatusOK || resp.StatusCode >= http.StatusMultipleChoices {
		return "", fmt.Errorf("agent task registration returned status %d", resp.StatusCode)
	}
	var result codexAgentIdentityTaskResponse
	if err := json.NewDecoder(io.LimitReader(resp.Body, 64*1024)).Decode(&result); err != nil {
		return "", errors.New("agent task registration response is invalid")
	}
	for _, taskID := range []string{result.TaskID, result.TaskIDCamel} {
		if taskID = strings.TrimSpace(taskID); taskID != "" {
			return taskID, nil
		}
	}
	encrypted := strings.TrimSpace(result.EncryptedTaskID)
	if encrypted == "" {
		encrypted = strings.TrimSpace(result.EncryptedTaskIDCamel)
	}
	if encrypted == "" {
		return "", errors.New("agent task registration response omitted task id")
	}
	return decryptCodexAgentTaskID(key, encrypted)
}

func persistCodexAgentIdentityTask(auth *cliproxyauth.Auth, taskID string) error {
	if auth == nil || auth.Metadata == nil {
		return errors.New("agent identity metadata is unavailable")
	}
	auth.Metadata["task_id"] = taskID
	if nested, ok := auth.Metadata["agent_identity"].(map[string]any); ok {
		nested["task_id"] = taskID
	}
	path := ""
	if auth.Attributes != nil {
		path = strings.TrimSpace(auth.Attributes["path"])
	}
	if path == "" {
		return nil
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return errors.New("failed to read agent identity auth file")
	}
	var value map[string]any
	if err := json.Unmarshal(data, &value); err != nil {
		return errors.New("failed to parse agent identity auth file")
	}
	value["task_id"] = taskID
	if nested, ok := value["agent_identity"].(map[string]any); ok {
		nested["task_id"] = taskID
	}
	encoded, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return errors.New("failed to serialize agent identity auth file")
	}
	mode := os.FileMode(0600)
	if info, statErr := os.Stat(path); statErr == nil {
		mode = info.Mode().Perm()
	}
	tmp, err := os.CreateTemp(filepath.Dir(path), ".agent-identity-*.json")
	if err != nil {
		return errors.New("failed to create agent identity auth file")
	}
	tmpPath := tmp.Name()
	defer os.Remove(tmpPath)
	if err := tmp.Chmod(mode); err != nil {
		tmp.Close()
		return errors.New("failed to secure agent identity auth file")
	}
	if _, err := tmp.Write(encoded); err != nil {
		tmp.Close()
		return errors.New("failed to write agent identity auth file")
	}
	if err := tmp.Close(); err != nil {
		return errors.New("failed to close agent identity auth file")
	}
	if err := os.Rename(tmpPath, path); err != nil {
		return errors.New("failed to replace agent identity auth file")
	}
	return nil
}

func ensureCodexAgentIdentityTask(ctx context.Context, client codexHTTPDoer, auth *cliproxyauth.Auth, expectedTaskID string) error {
	if !isCodexAgentIdentity(auth) {
		return nil
	}
	lockKey := auth.ID
	if lockKey == "" {
		lockKey = codexAgentIdentityMetadataString(auth, "agent_runtime_id")
	}
	actual, _ := codexAgentIdentityLocks.LoadOrStore(lockKey, &sync.Mutex{})
	mu := actual.(*sync.Mutex)
	mu.Lock()
	defer mu.Unlock()

	currentTaskID := codexAgentIdentityMetadataString(auth, "task_id")
	if currentTaskID != "" && (expectedTaskID == "" || currentTaskID != expectedTaskID) {
		return nil
	}
	key, err := codexAgentIdentityKeyFromAuth(auth)
	if err != nil {
		return err
	}
	newTaskID, err := registerCodexAgentIdentityTask(ctx, client, key)
	if err != nil {
		return err
	}
	return persistCodexAgentIdentityTask(auth, newTaskID)
}

func applyCodexAuthorization(ctx context.Context, client codexHTTPDoer, req *http.Request, auth *cliproxyauth.Auth, bearerToken string) error {
	if !isCodexAgentIdentity(auth) {
		req.Header.Set("Authorization", "Bearer "+bearerToken)
		return nil
	}
	if err := ensureCodexAgentIdentityTask(ctx, client, auth, ""); err != nil {
		return err
	}
	key, err := codexAgentIdentityKeyFromAuth(auth)
	if err != nil {
		return err
	}
	assertion, err := buildCodexAgentAssertion(key, time.Now())
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", assertion)
	return nil
}

func isCodexAgentIdentityTaskInvalid(statusCode int, body []byte) bool {
	if statusCode != http.StatusUnauthorized {
		return false
	}
	lower := strings.ToLower(string(body))
	compact := strings.NewReplacer(" ", "", "\t", "", "\r", "", "\n", "").Replace(lower)
	for _, marker := range []string{`"code":"invalid_task_id"`, `"code":"task_not_found"`, `"code":"task_expired"`, `"error":"invalid_task_id"`} {
		if strings.Contains(compact, marker) {
			return true
		}
	}
	for _, marker := range []string{"invalid task_id", "invalid task id", "task_id is invalid", "task id is invalid", "task not found", "task expired", "unknown task_id", "unknown task id"} {
		if strings.Contains(lower, marker) {
			return true
		}
	}
	return false
}

func cloneCodexRequestForRetry(req *http.Request) (*http.Request, error) {
	cloned := req.Clone(req.Context())
	if req.GetBody == nil {
		return nil, errors.New("agent identity request body cannot be replayed")
	}
	body, err := req.GetBody()
	if err != nil {
		return nil, errors.New("agent identity request body cannot be replayed")
	}
	cloned.Body = body
	return cloned, nil
}

func doCodexRequestWithAgentIdentityRecovery(ctx context.Context, client codexHTTPDoer, req *http.Request, auth *cliproxyauth.Auth) (*http.Response, error) {
	resp, err := client.Do(req)
	if err != nil || !isCodexAgentIdentity(auth) || resp == nil || resp.StatusCode != http.StatusUnauthorized {
		return resp, err
	}
	body, readErr := io.ReadAll(io.LimitReader(resp.Body, 1024*1024))
	if readErr != nil {
		return resp, nil
	}
	if !isCodexAgentIdentityTaskInvalid(resp.StatusCode, body) {
		resp.Body = io.NopCloser(bytes.NewReader(body))
		return resp, nil
	}
	resp.Body.Close()
	expectedTaskID := codexAgentIdentityMetadataString(auth, "task_id")
	if err := ensureCodexAgentIdentityTask(ctx, client, auth, expectedTaskID); err != nil {
		return nil, err
	}
	retry, err := cloneCodexRequestForRetry(req)
	if err != nil {
		return nil, err
	}
	if err := applyCodexAuthorization(ctx, client, retry, auth, ""); err != nil {
		return nil, err
	}
	return client.Do(retry)
}

func redactCodexAgentIdentityBody(auth *cliproxyauth.Auth, body []byte) []byte {
	if !isCodexAgentIdentity(auth) || len(body) == 0 {
		return body
	}
	redacted := string(body)
	for _, key := range []string{"agent_private_key", "agent_runtime_id", "task_id", "access_token", "refresh_token", "id_token", "api_key"} {
		if value := codexAgentIdentityMetadataString(auth, key); value != "" {
			redacted = strings.ReplaceAll(redacted, value, "[redacted]")
		}
	}
	for offset := 0; offset < len(redacted); {
		start := strings.Index(redacted[offset:], "AgentAssertion ")
		if start < 0 {
			break
		}
		start += offset + len("AgentAssertion ")
		end := start
		for end < len(redacted) && !strings.ContainsRune(" \t\r\n\"',}", rune(redacted[end])) {
			end++
		}
		redacted = redacted[:start] + "[redacted]" + redacted[end:]
		offset = start + len("[redacted]")
	}
	return []byte(redacted)
}
