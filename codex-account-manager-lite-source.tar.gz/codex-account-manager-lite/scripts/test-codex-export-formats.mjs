import assert from 'node:assert/strict';

import { transformCodexExportJson } from '../src/codexExportFormats.ts';

const AUTH_CLAIM = 'https://api.openai.com/auth';

function encodeBase64Url(value) {
  return Buffer.from(JSON.stringify(value)).toString('base64url');
}

function makeJwt(payload) {
  return `${encodeBase64Url({ alg: 'none', typ: 'JWT' })}.${encodeBase64Url(payload)}.sig`;
}

function decodeJwtPart(token, index) {
  return JSON.parse(Buffer.from(token.split('.')[index], 'base64url').toString('utf8'));
}

function makeOauthAccount(overrides = {}) {
  const accessToken = makeJwt({
    exp: 4_102_444_800,
    sub: 'user-export',
    [AUTH_CLAIM]: {
      chatgpt_account_id: 'acc-export',
      chatgpt_user_id: 'user-export',
      chatgpt_plan_type: 'pro',
      organization_id: 'org-export',
    },
  });
  const account = {
    id: 'stored-export',
    email: 'export@example.com',
    auth_mode: 'oauth',
    account_id: 'acc-export',
    account_note: 'keep this note',
    two_factor_secret: 'SECRET-2FA',
    account_password: 'password-1',
    phone_number: '15500000000',
    mail_url: 'https://mail.example.test/inbox',
    tags: ['primary'],
    tokens: {
      id_token: '',
      access_token: accessToken,
    },
    token_updated_at: 1_752_000_000,
    created_at: 1,
    last_used: 2,
  };
  return {
    ...account,
    ...overrides,
    tokens: { ...account.tokens, ...(overrides.tokens || {}) },
  };
}

const accessOnly = makeOauthAccount();
const standard = JSON.parse(transformCodexExportJson(JSON.stringify([accessOnly]), 'cockpit_tools'));
assert.equal(decodeJwtPart(standard.id_token, 0).cpa_synthetic, true);
assert.equal(decodeJwtPart(standard.id_token, 1)[AUTH_CLAIM].chatgpt_account_id, 'acc-export');
assert.equal(standard.account_note, 'keep this note');
assert.equal(standard.two_factor_secret, 'SECRET-2FA');
assert.equal(standard.account_password, 'password-1');
assert.equal(standard.phone_number, '15500000000');
assert.equal(standard.mail_url, 'https://mail.example.test/inbox');
assert.notEqual(standard.expired, '');

const refreshable = makeOauthAccount({
  tokens: { refresh_token: 'rt-export' },
  session_token: 'session-export',
  disabled: true,
});
const cpa = JSON.parse(transformCodexExportJson(JSON.stringify([refreshable]), 'cpa'));
assert.equal(cpa.expired, '');
assert.equal(cpa.password, 'password-1');
assert.equal(cpa.session_token, 'session-export');
assert.equal(cpa.disabled, true);
assert.equal(cpa.workspace_id, 'acc-export');

const sub2api = JSON.parse(transformCodexExportJson(JSON.stringify([refreshable]), 'sub2api'));
assert.equal(sub2api.accounts.length, 1);
assert.equal(sub2api.accounts[0].credentials.refresh_token, 'rt-export');
assert.equal(sub2api.accounts[0].credentials.chatgpt_account_id, 'acc-export');
assert.equal(decodeJwtPart(sub2api.accounts[0].credentials.id_token, 0).cpa_synthetic, true);

const secondOauth = makeOauthAccount({ id: 'stored-export-2', email: 'export2@example.com' });
for (const format of ['cockpit_tools', 'sub2api', 'cpa']) {
  const payload = JSON.parse(transformCodexExportJson(JSON.stringify([accessOnly, secondOauth]), format));
  const exportedAccounts = format === 'sub2api' ? payload.accounts : payload;
  assert.equal(exportedAccounts.length, 2, `${format} should preserve all accounts`);
}

const apiKeyAccount = {
  id: 'api-key-account',
  email: 'api-key@example.com',
  auth_mode: 'apikey',
  openai_api_key: 'sk-test',
  api_base_url: 'https://example.test/v1',
  api_provider_mode: 'custom',
  api_model_catalog: ['model-1'],
  api_supports_vision: true,
  tokens: { id_token: '', access_token: '' },
  created_at: 1,
  last_used: 2,
};
const apiKeyStandard = JSON.parse(
  transformCodexExportJson(JSON.stringify([apiKeyAccount]), 'cockpit_tools'),
);
assert.equal(apiKeyStandard.OPENAI_API_KEY, 'sk-test');
assert.deepEqual(apiKeyStandard.api_model_catalog, ['model-1']);
assert.equal(apiKeyStandard.api_supports_vision, true);
const mixedStandard = JSON.parse(
  transformCodexExportJson(JSON.stringify([accessOnly, apiKeyAccount]), 'cockpit_tools'),
);
assert.equal(mixedStandard.length, 2);
assert.equal(mixedStandard[1].OPENAI_API_KEY, 'sk-test');
assert.throws(
  () => transformCodexExportJson(JSON.stringify([apiKeyAccount]), 'sub2api'),
  /仅支持导出为标准 JSON/,
);
assert.throws(
  () => transformCodexExportJson(JSON.stringify([apiKeyAccount]), 'cpa'),
  /仅支持导出为标准 JSON/,
);

const agentIdentityAccount = {
  id: 'agent-account',
  email: 'agent@example.com',
  auth_mode: 'agentIdentity',
  agent_identity: {
    agent_runtime_id: 'runtime-test',
    agent_private_key: 'private-test',
    task_id: 'task-test',
    account_id: 'account-test',
    chatgpt_user_id: 'user-test',
    email: 'agent@example.com',
    plan_type: 'plus',
  },
  tokens: { id_token: '', access_token: '' },
  created_at: 1,
  last_used: 2,
};
const agentStandard = JSON.parse(
  transformCodexExportJson(JSON.stringify([agentIdentityAccount]), 'cockpit_tools'),
);
assert.equal(agentStandard.auth_mode, 'agentIdentity');
assert.equal(agentStandard.agent_identity.task_id, 'task-test');
const agentSub2api = JSON.parse(
  transformCodexExportJson(JSON.stringify([agentIdentityAccount]), 'sub2api'),
);
assert.equal(agentSub2api.accounts[0].credentials.auth_mode, 'agentIdentity');
assert.equal(agentSub2api.accounts[0].credentials.agent_runtime_id, 'runtime-test');
assert.throws(
  () => transformCodexExportJson(JSON.stringify([agentIdentityAccount]), 'cpa'),
  /不支持 CPA 格式/,
);

console.log('Codex export format tests passed.');
