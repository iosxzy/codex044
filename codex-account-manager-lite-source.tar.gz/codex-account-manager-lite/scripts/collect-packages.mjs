import { copyFileSync, existsSync, mkdirSync, readdirSync, rmSync, statSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const targetRoot = path.join(projectRoot, "src-tauri", "target");
const bucket = process.argv.slice(2).find((arg) => arg !== "--") || "all";
const outputDir = path.join(projectRoot, "packages", bucket);
const installerExts = new Set([".dmg", ".msi", ".exe", ".deb", ".AppImage", ".rpm"]);
const installers = [];

function walk(dir) {
  if (!existsSync(dir)) {
    return;
  }

  for (const entry of readdirSync(dir)) {
    const fullPath = path.join(dir, entry);
    const stats = statSync(fullPath);

    if (stats.isDirectory()) {
      walk(fullPath);
      continue;
    }

    if (installerExts.has(path.extname(entry))) {
      installers.push(fullPath);
    }
  }
}

function uniqueDestination(filePath) {
  const parsed = path.parse(filePath);
  let destination = path.join(outputDir, path.basename(filePath));
  let counter = 2;

  while (existsSync(destination)) {
    destination = path.join(outputDir, `${parsed.name}-${counter}${parsed.ext}`);
    counter += 1;
  }

  return destination;
}

walk(targetRoot);
rmSync(outputDir, { force: true, recursive: true });
mkdirSync(outputDir, { recursive: true });

for (const installer of installers) {
  copyFileSync(installer, uniqueDestination(installer));
}

if (installers.length === 0) {
  console.error(`No installer packages found under ${targetRoot}`);
  process.exit(1);
}

console.log(`Copied ${installers.length} installer package(s) to ${outputDir}`);
