# codex账号管理器

一个独立的 Codex 账号管理小工具。它参考并复用 Cockpit Tools 中的 Codex 账号核心逻辑，但不改造 Cockpit Tools 主应用入口。

## 功能范围

- Codex OAuth 授权登录
- 导入本机 `~/.codex/auth.json`
- 从 JSON / 文件导入 Codex 账号
- 添加和编辑 API Key 账号
- 切换当前 Codex 账号并写回官方 `auth.json`
- 刷新单账号 / 全部账号配额
- 编辑名称、备注、标签
- 导出账号 JSON
- 删除账号
- 打开 `~/.codex/config.toml`

多开实例、唤醒任务、本地 API 服务、模型供应商管理等全量功能不在精简版内。

## 数据兼容

账号逻辑直接调用 `crates/cockpit-core` 的 Codex 模块，默认使用与 Cockpit Tools 相同的数据目录和 `~/.codex` 写入规则。

如需隔离数据，可以启动前设置：

```bash
export COCKPIT_TOOLS_DATA_DIR="$HOME/.codex_account_manager_lite"
```

## 本地开发

```bash
cd codex-account-manager-lite
npm install
npm run tauri:dev
```

## 打包命令

| 平台 | 产物 | 架构 |
| --- | --- | --- |
| macOS | `.dmg` | ARM64 + x86_64 universal |
| Windows | `.msi` / `.exe` | x86_64 |
| Linux | `.deb` / `.AppImage` / `.rpm` | x86_64 + ARM64 |

```bash
npm run package:mac
npm run package:windows
npm run package:linux:x64
npm run package:linux:arm64
```

打包完成后的安装包会自动收集到 `packages/<platform>/`。

跨平台产物建议用仓库根目录的 `Codex Lite Packages` GitHub Actions 工作流构建。
