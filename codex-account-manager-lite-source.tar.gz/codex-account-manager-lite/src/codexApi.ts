import { invoke } from '@tauri-apps/api/core';
import type {
  CodexAccount,
  CodexAppSpeed,
  CodexAppSpeedConfig,
  CodexApiProviderMode,
  CodexBatchImportPreview,
  CodexCloudImportResult,
  CodexExternalApiServiceActivationResult,
  CodexExternalApiServiceConfig,
  CodexFileImportResult,
  CodexLocalAccessClientBaseUrlHost,
  CodexLocalAccessPortCleanupResult,
  CodexLocalAccessState,
  CodexOAuthLoginStartResponse,
  CodexProviderWireApi,
  CodexQuota,
  CodexServerUpdateInfo,
} from './types';

export const listCodexAccounts = () =>
  invoke<CodexAccount[]>('list_codex_accounts');

export const getCurrentCodexAccount = () =>
  invoke<CodexAccount | null>('get_current_codex_account');

export const getCodexConfigTomlPath = () =>
  invoke<string>('get_codex_config_toml_path');

export const getCodexApiServiceAppSpeedConfig = () =>
  invoke<CodexAppSpeedConfig>('get_codex_api_service_app_speed_config');

export const saveCodexApiServiceAppSpeed = (speed: CodexAppSpeed) =>
  invoke<CodexAppSpeedConfig>('save_codex_api_service_app_speed', { speed });

export const switchCodexAccount = (accountId: string) =>
  invoke<CodexAccount>('switch_codex_account', { accountId });

export const restartCodexDefaultApp = () =>
  invoke<number>('restart_codex_default_app');

export const deleteCodexAccount = (accountId: string) =>
  invoke<void>('delete_codex_account', { accountId });

export const deleteCodexAccounts = (accountIds: string[]) =>
  invoke<void>('delete_codex_accounts', { accountIds });

export const importCodexFromLocal = () =>
  invoke<CodexAccount>('import_codex_from_local');

export const importCodexFromJson = (jsonContent: string) =>
  invoke<CodexAccount[]>('import_codex_from_json', { jsonContent });

export const importCodexFromFiles = (filePaths: string[]) =>
  invoke<CodexFileImportResult>('import_codex_from_files', { filePaths });

export const previewCodexCloudImport = () =>
  invoke<CodexBatchImportPreview>('preview_codex_cloud_import');

export const confirmCodexCloudImport = (sessionId: string, itemIds: string[]) =>
  invoke<CodexCloudImportResult>('confirm_codex_cloud_import', { sessionId, itemIds });

export const cancelCodexCloudImport = (sessionId: string) =>
  invoke<void>('cancel_codex_cloud_import', { sessionId });

export const exportCodexAccounts = (accountIds: string[]) =>
  invoke<string>('export_codex_accounts', { accountIds });

export const saveCodexExportFile = (filePath: string, content: string) =>
  invoke<void>('save_codex_export_file', { filePath, content });

export const saveCodexExportFiles = (
  directoryPath: string,
  files: { fileName: string; content: string }[],
) => invoke<void>('save_codex_export_files', { directoryPath, files });

export const checkServerUpdate = (currentVersion: string) =>
  invoke<CodexServerUpdateInfo>('check_server_update', { currentVersion });

export const downloadServerUpdate = (url: string, fileName: string) =>
  invoke<string>('download_server_update', { url, fileName });

export const installServerUpdate = (packagePath: string, kind?: string | null) =>
  invoke<void>('install_server_update', { packagePath, kind: kind ?? null });

export const refreshCodexQuota = (accountId: string) =>
  invoke<CodexQuota>('refresh_codex_quota', { accountId });

export const refreshAllCodexQuotas = () =>
  invoke<number>('refresh_all_codex_quotas');

export const refreshCodexSubscriptionInfo = (accountId: string) =>
  invoke<CodexAccount>('refresh_codex_subscription_info', { accountId });

export const refreshCodexAccountProfile = (accountId: string) =>
  invoke<CodexAccount>('refresh_codex_account_profile', { accountId });

export const addCodexAccountWithApiKey = (params: {
  apiKey: string;
  apiBaseUrl?: string;
  apiProviderMode?: CodexApiProviderMode;
  apiProviderId?: string;
  apiProviderName?: string;
  apiModelCatalog?: string[];
  apiSupportsVision?: boolean;
  apiModelVisionSupport?: Record<string, boolean>;
  apiVisionRoutingModel?: string;
  accountName?: string;
  apiWireApi?: CodexProviderWireApi;
}) =>
  invoke<CodexAccount>('add_codex_account_with_api_key', {
    apiKey: params.apiKey,
    apiBaseUrl: params.apiBaseUrl ?? null,
    apiProviderMode: params.apiProviderMode ?? null,
    apiProviderId: params.apiProviderId ?? null,
    apiProviderName: params.apiProviderName ?? null,
    apiModelCatalog: params.apiModelCatalog ?? null,
    apiSupportsVision: params.apiSupportsVision ?? false,
    apiModelVisionSupport: params.apiModelVisionSupport ?? {},
    apiVisionRoutingModel: params.apiVisionRoutingModel ?? null,
    accountName: params.accountName ?? null,
    apiWireApi: params.apiWireApi ?? null,
  });

export const updateCodexAccountName = (accountId: string, name: string) =>
  invoke<CodexAccount>('update_codex_account_name', { accountId, name });

export const updateCodexAccountTags = (accountId: string, tags: string[]) =>
  invoke<CodexAccount>('update_codex_account_tags', { accountId, tags });

export const updateCodexAccountNote = (accountId: string, note: string) =>
  invoke<CodexAccount>('update_codex_account_note', { accountId, note });

export const updateCodexAccountAppSpeed = (accountId: string, speed: CodexAppSpeed) =>
  invoke<CodexAccount>('update_codex_account_app_speed', { accountId, speed });

export const updateCodexApiKeyCredentials = (
  accountId: string,
  params: {
    apiKey: string;
    apiBaseUrl?: string;
    apiProviderMode?: CodexApiProviderMode;
    apiProviderId?: string;
    apiProviderName?: string;
    apiModelCatalog?: string[];
    apiSupportsVision?: boolean;
    apiModelVisionSupport?: Record<string, boolean>;
    apiVisionRoutingModel?: string;
    apiWireApi?: CodexProviderWireApi;
  },
) =>
  invoke<CodexAccount>('update_codex_api_key_credentials', {
    accountId,
    apiKey: params.apiKey,
    apiBaseUrl: params.apiBaseUrl ?? null,
    apiProviderMode: params.apiProviderMode ?? null,
    apiProviderId: params.apiProviderId ?? null,
    apiProviderName: params.apiProviderName ?? null,
    apiModelCatalog: params.apiModelCatalog ?? null,
    apiSupportsVision: params.apiSupportsVision ?? false,
    apiModelVisionSupport: params.apiModelVisionSupport ?? {},
    apiVisionRoutingModel: params.apiVisionRoutingModel ?? null,
    apiWireApi: params.apiWireApi ?? null,
  });

export const startCodexOAuthLogin = () =>
  invoke<CodexOAuthLoginStartResponse>('codex_oauth_login_start');

export const completeCodexOAuthLogin = (loginId: string) =>
  invoke<CodexAccount>('codex_oauth_login_completed', {
    loginId,
    reauthAccountId: null,
  });

export const cancelCodexOAuthLogin = (loginId?: string) =>
  invoke<void>('codex_oauth_login_cancel', { loginId: loginId ?? null });

export const submitCodexOAuthCallbackUrl = (loginId: string, callbackUrl: string) =>
  invoke<void>('codex_oauth_submit_callback_url', { loginId, callbackUrl });

export const getCodexLocalAccessState = () =>
  invoke<CodexLocalAccessState>('codex_local_access_get_state');

export const getCodexLocalAccessStateLight = () =>
  invoke<CodexLocalAccessState>('codex_local_access_get_state_light');

export const saveCodexLocalAccessAccounts = (
  accountIds: string[],
  restrictFreeAccounts: boolean,
) =>
  invoke<CodexLocalAccessState>('codex_local_access_save_accounts', {
    accountIds,
    restrictFreeAccounts,
  });

export const removeCodexLocalAccessAccount = (accountId: string) =>
  invoke<CodexLocalAccessState>('codex_local_access_remove_account', { accountId });

export const rotateCodexLocalAccessApiKey = () =>
  invoke<CodexLocalAccessState>('codex_local_access_rotate_api_key');

export const updateCodexLocalAccessPort = (port: number) =>
  invoke<CodexLocalAccessState>('codex_local_access_update_port', { port });

export const updateCodexLocalAccessClientBaseUrlHost = (
  clientBaseUrlHost: CodexLocalAccessClientBaseUrlHost,
) =>
  invoke<CodexLocalAccessState>('codex_local_access_update_client_base_url_host', {
    clientBaseUrlHost,
  });

export const getCodexExternalApiServiceConfig = () =>
  invoke<CodexExternalApiServiceConfig | null>('get_codex_external_api_service_config');

export const activateCodexExternalApiService = (params: {
  profileId?: string | null;
  profileName?: string | null;
  apiKey?: string | null;
  apiBaseUrl: string;
  apiProviderName?: string | null;
  refreshCloudDefault?: boolean;
}) =>
  invoke<CodexExternalApiServiceActivationResult>(
    'activate_codex_external_api_service',
    {
      profileId: params.profileId ?? null,
      profileName: params.profileName ?? null,
      apiKey: params.apiKey ?? null,
      apiBaseUrl: params.apiBaseUrl,
      apiProviderName: params.apiProviderName ?? null,
      refreshCloudDefault: params.refreshCloudDefault ?? false,
    },
  );

export const deleteCodexExternalApiServiceProfile = (profileId: string) =>
  invoke<CodexExternalApiServiceActivationResult>(
    'delete_codex_external_api_service_profile',
    { profileId },
  );

export const deactivateCodexExternalApiService = () =>
  invoke<CodexExternalApiServiceActivationResult>('deactivate_codex_external_api_service');

export const setCodexLocalAccessEnabled = (enabled: boolean) =>
  invoke<CodexLocalAccessState>('codex_local_access_set_enabled', { enabled });

export const activateCodexLocalAccess = () =>
  invoke<CodexLocalAccessState>('codex_local_access_activate');

export const killCodexLocalAccessPort = () =>
  invoke<CodexLocalAccessPortCleanupResult>('codex_local_access_kill_port');
