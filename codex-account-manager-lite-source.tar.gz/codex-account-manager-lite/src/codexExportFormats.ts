import type { CodexAccount } from './types';

export type CodexExportFormat = 'cockpit_tools' | 'sub2api' | 'cpa';

type JsonRecord = Record<string, unknown>;

const INVALID_FILE_CHARS_REGEX = /[<>:"/\\|?*\x00-\x1F]/g;
const OPENAI_AUTH_CLAIM = 'https://api.openai.com/auth';
const SYNTHETIC_ID_TOKEN_TTL_SECONDS = 90 * 24 * 60 * 60;

interface Sub2apiBatchCreatePayload {
  exported_at: string;
  proxies: [];
  accounts: Sub2apiCreateAccountItem[];
  type: 'sub2api-data';
  version: 1;
}

interface Sub2apiCreateAccountItem {
  name: string;
  platform: 'openai';
  type: 'oauth';
  expires_at?: number;
  auto_pause_on_expired?: boolean;
  credentials: JsonRecord;
  extra?: JsonRecord;
  concurrency: number;
  priority: number;
  rate_multiplier: number;
}

interface CodexPortableTokenStorage extends JsonRecord {
  id_token: string;
  access_token: string;
  refresh_token: string;
  account_id: string;
  last_refresh: string;
  email: string;
  type: 'codex';
  expired: string;
}

interface CpaTokenStorage extends JsonRecord {
  access_token: string;
  account_id: string;
  disabled: boolean;
  email: string;
  expired: string;
  id_token: string;
  last_refresh: string;
  password: string;
  refresh_token: string;
  session_token: string;
  type: 'codex';
  workspace_id: string;
}

export interface CodexExportContent {
  fileNameBase: string;
  jsonContent: string;
}

function toJsonRecord(value: unknown): JsonRecord | null {
  return value && typeof value === 'object' && !Array.isArray(value) ? (value as JsonRecord) : null;
}

function toStringValue(value: unknown): string | undefined {
  if (typeof value === 'string') {
    const trimmed = value.trim();
    return trimmed || undefined;
  }
  if (typeof value === 'number' && Number.isFinite(value)) {
    return String(value);
  }
  return undefined;
}

function toNumberValue(value: unknown): number | undefined {
  return typeof value === 'number' && Number.isFinite(value) ? value : undefined;
}

function stripUnavailable(value: unknown): unknown {
  if (Array.isArray(value)) {
    return value.map(stripUnavailable).filter((item) => item !== undefined);
  }
  if (toJsonRecord(value)) {
    const entries = Object.entries(value as JsonRecord)
      .map(([key, item]) => [key, stripUnavailable(item)] as const)
      .filter(([, item]) => item !== undefined && item !== null && item !== '');
    return entries.length ? Object.fromEntries(entries) : undefined;
  }
  return value === '' ? undefined : value;
}

export function sanitizeFileNameSegment(input: string | undefined, fallback: string): string {
  const raw = (input || '').trim();
  const normalized = raw
    .replace(INVALID_FILE_CHARS_REGEX, '_')
    .replace(/\s+/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_+|_+$/g, '');
  return normalized || fallback;
}

function decodeJwtPayload(token: string | undefined): JsonRecord | null {
  if (!token) return null;
  const parts = token.split('.');
  if (parts.length < 2) return null;

  const payloadPart = parts[1];
  const padded = payloadPart + '='.repeat((4 - (payloadPart.length % 4)) % 4);
  const base64 = padded.replace(/-/g, '+').replace(/_/g, '/');

  try {
    const binary = atob(base64);
    const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
    const text = new TextDecoder().decode(bytes);
    return toJsonRecord(JSON.parse(text));
  } catch {
    return null;
  }
}

function encodeBase64UrlJson(value: JsonRecord): string {
  const bytes = new TextEncoder().encode(JSON.stringify(value));
  let binary = '';
  for (const byte of bytes) {
    binary += String.fromCharCode(byte);
  }
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

function resolveAuthPayload(account: CodexAccount): JsonRecord | null {
  const idTokenPayload = decodeJwtPayload(account.tokens?.id_token);
  const accessTokenPayload = decodeJwtPayload(account.tokens?.access_token);
  const accessAuthPayload = toJsonRecord(accessTokenPayload?.[OPENAI_AUTH_CLAIM]);
  const idAuthPayload = toJsonRecord(idTokenPayload?.[OPENAI_AUTH_CLAIM]);
  if (!accessAuthPayload && !idAuthPayload) return null;
  return {
    ...(accessAuthPayload || {}),
    ...(idAuthPayload || {}),
  };
}

function resolveAccountId(account: CodexAccount): string | undefined {
  const authPayload = resolveAuthPayload(account);
  return (
    toStringValue(account.account_id) ||
    toStringValue(authPayload?.chatgpt_account_id) ||
    toStringValue(authPayload?.account_id)
  );
}

function resolveUserId(account: CodexAccount): string | undefined {
  const idTokenPayload = decodeJwtPayload(account.tokens?.id_token);
  const accessTokenPayload = decodeJwtPayload(account.tokens?.access_token);
  const authPayload = resolveAuthPayload(account);
  return (
    toStringValue(account.user_id) ||
    toStringValue(authPayload?.chatgpt_user_id) ||
    toStringValue(authPayload?.user_id) ||
    toStringValue(idTokenPayload?.sub) ||
    toStringValue(accessTokenPayload?.sub)
  );
}

function resolveOrganizationId(account: CodexAccount): string | undefined {
  const authPayload = resolveAuthPayload(account);
  return toStringValue(account.organization_id) || toStringValue(authPayload?.organization_id);
}

function resolvePlanType(account: CodexAccount): string | undefined {
  const authPayload = resolveAuthPayload(account);
  return toStringValue(account.plan_type) || toStringValue(authPayload?.chatgpt_plan_type);
}

function resolveWorkspaceId(account: CodexAccount): string | undefined {
  const idTokenPayload = decodeJwtPayload(account.tokens?.id_token);
  const accessTokenPayload = decodeJwtPayload(account.tokens?.access_token);
  return (
    toStringValue(account.workspace_id) ||
    toStringValue(accessTokenPayload?.workspace_id) ||
    toStringValue(idTokenPayload?.workspace_id) ||
    resolveAccountId(account)
  );
}

function resolveClientId(account: CodexAccount): string | undefined {
  const idTokenPayload = decodeJwtPayload(account.tokens?.id_token);
  const accessTokenPayload = decodeJwtPayload(account.tokens?.access_token);
  return (
    toStringValue(account.client_id) ||
    toStringValue(accessTokenPayload?.client_id) ||
    toStringValue(idTokenPayload?.client_id)
  );
}

function normalizeTimestampToIso(value: unknown): string | undefined {
  if (typeof value === 'string') {
    const trimmed = value.trim();
    if (!trimmed) return undefined;
    const parsed = Date.parse(trimmed);
    return Number.isFinite(parsed) ? new Date(parsed).toISOString() : trimmed;
  }

  const numeric = toNumberValue(value);
  if (numeric == null) return undefined;
  const millis = numeric > 1_000_000_000_000 ? numeric : numeric * 1000;
  const date = new Date(millis);
  return Number.isNaN(date.getTime()) ? undefined : date.toISOString();
}

function formatSub2apiExportedAt(): string {
  return new Date().toISOString().replace(/\.\d{3}Z$/, 'Z');
}

function resolveSubscriptionExpiresAt(account: CodexAccount): string | undefined {
  const authPayload = resolveAuthPayload(account);
  return (
    normalizeTimestampToIso(account.subscription_active_until) ||
    normalizeTimestampToIso(authPayload?.chatgpt_subscription_active_until)
  );
}

function resolveAccessTokenExpiry(account: CodexAccount): string | undefined {
  const expiry = resolveAccessTokenExpiryEpoch(account);
  return expiry == null ? undefined : normalizeTimestampToIso(expiry);
}

function resolvePortableAccountExpiry(account: CodexAccount): string | undefined {
  if (account.tokens.refresh_token?.trim()) return undefined;
  return resolveAccessTokenExpiry(account);
}

function resolveAccessTokenExpiryEpoch(account: CodexAccount): number | undefined {
  const accessTokenPayload = decodeJwtPayload(account.tokens?.access_token);
  const idTokenPayload = decodeJwtPayload(account.tokens?.id_token);
  const accessExp = toNumberValue(accessTokenPayload?.exp);
  if (accessExp != null) {
    return Math.trunc(accessExp);
  }
  const idExp = toNumberValue(idTokenPayload?.exp);
  return idExp == null ? undefined : Math.trunc(idExp);
}

function resolveLastRefresh(account: CodexAccount): string {
  return normalizeTimestampToIso(account.token_updated_at) || new Date().toISOString();
}

function resolveExpiresIn(account: CodexAccount): number | undefined {
  const expiresAt = resolveAccessTokenExpiryEpoch(account);
  if (expiresAt == null) return undefined;
  return Math.max(0, expiresAt - Math.trunc(Date.now() / 1000));
}

function resolveDisplayName(account: CodexAccount): string {
  return account.account_name?.trim() || account.email?.trim() || account.id;
}

function buildSyntheticCodexIdToken(account: CodexAccount): string | undefined {
  const accountId = resolveAccountId(account);
  if (!accountId) return undefined;

  const now = Math.trunc(Date.now() / 1000);
  const auth: JsonRecord = { chatgpt_account_id: accountId };
  const planType = resolvePlanType(account);
  const userId = resolveUserId(account);
  if (planType) auth.chatgpt_plan_type = planType;
  if (userId) {
    auth.chatgpt_user_id = userId;
    auth.user_id = userId;
  }

  const payload: JsonRecord = {
    iat: now,
    exp:
      (!account.tokens.refresh_token?.trim() && resolveAccessTokenExpiryEpoch(account))
      || now + SYNTHETIC_ID_TOKEN_TTL_SECONDS,
    [OPENAI_AUTH_CLAIM]: auth,
  };
  if (account.email?.trim()) payload.email = account.email.trim();

  const header = { alg: 'none', typ: 'JWT', cpa_synthetic: true };
  return `${encodeBase64UrlJson(header)}.${encodeBase64UrlJson(payload)}.synthetic`;
}

function resolvePortableIdToken(account: CodexAccount): string {
  return account.tokens.id_token?.trim() || buildSyntheticCodexIdToken(account) || '';
}

function resolveEmailKey(account: CodexAccount): string | undefined {
  const email = account.email?.trim().toLowerCase();
  if (!email) return undefined;
  return email.replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '') || undefined;
}

function buildSub2apiCredentials(account: CodexAccount): JsonRecord {
  if (isCodexAgentIdentityAccount(account)) {
    const identity = account.agent_identity;
    return stripUnavailable({
      auth_mode: 'agentIdentity',
      agent_runtime_id: identity?.agent_runtime_id,
      agent_private_key: identity?.agent_private_key,
      task_id: identity?.task_id,
      account_id: identity?.account_id || account.account_id,
      chatgpt_user_id: identity?.chatgpt_user_id || account.user_id,
      email: identity?.email || account.email,
      plan_type: identity?.plan_type || account.plan_type,
      chatgpt_account_is_fedramp: identity?.chatgpt_account_is_fedramp,
    }) as JsonRecord;
  }
  const chatgptAccountId = resolveAccountId(account);
  return stripUnavailable({
    access_token: account.tokens.access_token,
    account_id: chatgptAccountId,
    chatgpt_account_id: chatgptAccountId,
    workspace_id: resolveWorkspaceId(account),
    chatgpt_user_id: resolveUserId(account),
    client_id: resolveClientId(account),
    expires_at: resolveAccessTokenExpiryEpoch(account),
    expires_in: resolveExpiresIn(account),
    id_token: resolvePortableIdToken(account),
    email: account.email?.trim(),
    plan_type: resolvePlanType(account),
    refresh_token: account.tokens.refresh_token?.trim(),
    organization_id: resolveOrganizationId(account),
    subscription_expires_at: resolveSubscriptionExpiresAt(account),
  }) as JsonRecord;
}

function toSub2apiAccount(account: CodexAccount): Sub2apiCreateAccountItem {
  const chatgptAccountId = resolveAccountId(account);
  const expiresAt = resolveAccessTokenExpiryEpoch(account);
  return {
    name: resolveDisplayName(account),
    platform: 'openai',
    type: 'oauth',
    expires_at: expiresAt,
    auto_pause_on_expired: expiresAt == null ? undefined : true,
    credentials: buildSub2apiCredentials(account),
    extra: stripUnavailable({
      email: account.email?.trim(),
      email_key: resolveEmailKey(account),
      name: resolveDisplayName(account),
      source: account.token_source_mode?.trim() || 'cockpit_tools',
      last_refresh: resolveLastRefresh(account),
      account_id: chatgptAccountId,
      chatgpt_account_id: chatgptAccountId,
      workspace_id: resolveWorkspaceId(account),
    }) as JsonRecord | undefined,
    concurrency: 10,
    priority: 1,
    rate_multiplier: 1.0,
  };
}

function toPortableTokenStorage(account: CodexAccount): CodexPortableTokenStorage {
  const accountId = resolveAccountId(account) || '';
  const planType = resolvePlanType(account);
  const workspaceId = resolveWorkspaceId(account);
  return {
    id_token: resolvePortableIdToken(account),
    access_token: account.tokens.access_token || '',
    refresh_token: account.tokens.refresh_token?.trim() || '',
    account_id: accountId,
    chatgpt_account_id: accountId,
    workspace_id: workspaceId || accountId,
    last_refresh: resolveLastRefresh(account),
    email: account.email || '',
    name: resolveDisplayName(account),
    plan_type: planType || '',
    chatgpt_plan_type: planType || '',
    type: 'codex',
    expired: resolvePortableAccountExpiry(account) || '',
    user_id: resolveUserId(account),
    organization_id: resolveOrganizationId(account),
    client_id: resolveClientId(account),
    subscription_active_until: resolveSubscriptionExpiresAt(account),
    auth_file_plan_type: account.auth_file_plan_type?.trim() || undefined,
    account_name: account.account_name?.trim() || undefined,
    account_structure: account.account_structure?.trim() || undefined,
    account_note: account.account_note?.trim() || undefined,
    two_factor_secret: account.two_factor_secret?.trim() || undefined,
    account_password: account.account_password || account.password || undefined,
    phone_number: account.phone_number?.trim() || undefined,
    mail_url: account.mail_url?.trim() || undefined,
    authorization_status: account.authorization_status?.trim() || undefined,
    tags: account.tags?.length ? account.tags : undefined,
  };
}

function toCpaTokenStorage(account: CodexAccount): CpaTokenStorage {
  const accountId = resolveAccountId(account) || '';
  return {
    access_token: account.tokens.access_token || '',
    account_id: accountId,
    disabled: account.disabled ?? false,
    email: account.email || '',
    expired: resolvePortableAccountExpiry(account) || '',
    id_token: resolvePortableIdToken(account),
    last_refresh: resolveLastRefresh(account),
    password: account.account_password || account.password || '',
    refresh_token: account.tokens.refresh_token?.trim() || '',
    session_token: account.session_token?.trim() || '',
    type: 'codex',
    workspace_id: resolveWorkspaceId(account) || accountId,
  };
}

function isCodexApiKeyAccount(account: CodexAccount): boolean {
  return account.auth_mode === 'apikey' || Boolean(account.openai_api_key?.trim());
}

function isCodexAgentIdentityAccount(account: CodexAccount): boolean {
  const mode = account.auth_mode?.trim().toLowerCase();
  return mode === 'agentidentity' || mode === 'agent_identity' || Boolean(account.agent_identity);
}

function toPortableApiKeyStorage(account: CodexAccount): JsonRecord {
  const payload: JsonRecord = {
    auth_mode: 'apikey',
    OPENAI_API_KEY: account.openai_api_key || '',
    email: account.email || '',
    api_provider_mode: account.api_provider_mode,
    api_model_catalog: account.api_model_catalog,
    api_wire_api: account.api_wire_api,
    api_supports_vision: account.api_supports_vision,
    api_model_vision_support: account.api_model_vision_support,
    api_vision_routing_model: account.api_vision_routing_model,
    account_name: account.account_name,
    account_note: account.account_note,
    two_factor_secret: account.two_factor_secret,
    account_password: account.account_password || account.password,
    phone_number: account.phone_number,
    mail_url: account.mail_url,
    tags: account.tags,
  };

  if (account.api_base_url?.trim()) {
    payload.api_base_url = account.api_base_url.trim();
  }
  if (account.api_provider_id?.trim()) {
    payload.api_provider_id = account.api_provider_id.trim();
  }
  if (account.api_provider_name?.trim()) {
    payload.api_provider_name = account.api_provider_name.trim();
  }

  return stripUnavailable(payload) as JsonRecord;
}

function toPortableAgentIdentityStorage(account: CodexAccount): JsonRecord {
  return stripUnavailable({
    auth_mode: 'agentIdentity',
    agent_identity: account.agent_identity,
    email: account.email,
    account_name: account.account_name,
    account_note: account.account_note,
    two_factor_secret: account.two_factor_secret,
    account_password: account.account_password || account.password,
    phone_number: account.phone_number,
    mail_url: account.mail_url,
    tags: account.tags,
  }) as JsonRecord;
}

function toCockpitToolsPortableStorage(account: CodexAccount): CodexPortableTokenStorage | JsonRecord {
  if (isCodexApiKeyAccount(account)) {
    return toPortableApiKeyStorage(account);
  }
  if (isCodexAgentIdentityAccount(account)) {
    return toPortableAgentIdentityStorage(account);
  }
  return toPortableTokenStorage(account);
}

export function parseCockpitToolsCodexExport(rawJson: string): CodexAccount[] {
  const parsed = JSON.parse(rawJson) as unknown;
  if (Array.isArray(parsed)) {
    return parsed as CodexAccount[];
  }
  if (parsed && typeof parsed === 'object') {
    return [parsed as CodexAccount];
  }
  return [];
}

export function transformCodexExportJson(rawJson: string, format: CodexExportFormat): string {
  const accounts = parseCockpitToolsCodexExport(rawJson);

  if (format === 'cockpit_tools') {
    const portableAccounts = accounts.map(toCockpitToolsPortableStorage);
    const normalizedPayload = portableAccounts.length === 1 ? portableAccounts[0] : portableAccounts;
    return JSON.stringify(normalizedPayload, null, 2);
  }

  if (accounts.some(isCodexApiKeyAccount)) {
    throw new Error('API Key 账号仅支持导出为标准 JSON');
  }

  if (format === 'cpa' && accounts.some(isCodexAgentIdentityAccount)) {
    throw new Error('Agent Identity 账号不支持 CPA 格式');
  }

  if (format === 'sub2api') {
    const payload: Sub2apiBatchCreatePayload = {
      exported_at: formatSub2apiExportedAt(),
      proxies: [],
      accounts: accounts.map(toSub2apiAccount),
      type: 'sub2api-data',
      version: 1,
    };
    return JSON.stringify(payload, null, 2);
  }

  const cpaPayload = accounts.map(toCpaTokenStorage);
  const normalizedPayload = cpaPayload.length === 1 ? cpaPayload[0] : cpaPayload;
  return JSON.stringify(normalizedPayload, null, 2);
}

export function buildCodexExportFileNameBase(baseName: string, format: CodexExportFormat): string {
  if (format === 'cockpit_tools') {
    return baseName;
  }
  return `${baseName}_${format}`;
}

export function buildCodexExportContent(
  rawJson: string,
  format: CodexExportFormat,
  baseName: string,
): CodexExportContent {
  const fileNameBase = buildCodexExportFileNameBase(baseName, format);

  return {
    fileNameBase,
    jsonContent: transformCodexExportJson(rawJson, format),
  };
}
