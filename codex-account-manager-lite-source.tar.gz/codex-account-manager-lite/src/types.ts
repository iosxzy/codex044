export type CodexApiProviderMode = 'openai_builtin' | 'custom';
export type CodexProviderWireApi = 'responses' | 'chat_completions' | 'anthropic' | 'gemini';
export type CodexAppSpeed = 'standard' | 'fast';

export interface CodexAppSpeedConfig {
  speed: CodexAppSpeed;
  globalStatePath: string;
}

export interface CodexTokens {
  id_token: string;
  access_token: string;
  refresh_token?: string;
}

export interface CodexAgentIdentity {
  agent_runtime_id: string;
  agent_private_key: string;
  task_id?: string;
  account_id: string;
  chatgpt_user_id: string;
  email?: string;
  plan_type?: string;
  chatgpt_account_is_fedramp?: boolean;
}

export interface CodexQuotaErrorInfo {
  code?: string;
  message: string;
  timestamp: number;
}

export interface CodexQuota {
  hourly_percentage: number;
  hourly_reset_time?: number;
  hourly_window_minutes?: number;
  hourly_window_present?: boolean;
  weekly_percentage: number;
  weekly_reset_time?: number;
  weekly_window_minutes?: number;
  weekly_window_present?: boolean;
  reset_credits_available?: number;
  reset_credits_next_expires_at?: number;
  raw_data?: unknown;
}

export interface CodexAccount {
  id: string;
  email: string;
  auth_mode?: string;
  agent_identity?: CodexAgentIdentity;
  login_method?: string;
  loginMethod?: string;
  auth_method?: string;
  authMethod?: string;
  signed_in_with?: string;
  signedInWith?: string;
  openai_api_key?: string;
  api_base_url?: string;
  api_provider_mode?: CodexApiProviderMode;
  api_provider_id?: string;
  api_provider_name?: string;
  api_model_catalog?: string[];
  api_wire_api?: CodexProviderWireApi | null;
  api_supports_vision?: boolean;
  api_model_vision_support?: Record<string, boolean>;
  api_vision_routing_model?: string | null;
  app_speed?: CodexAppSpeed;
  user_id?: string;
  plan_type?: string;
  subscription_active_until?: string;
  auth_file_plan_type?: string;
  account_id?: string;
  workspace_id?: string;
  client_id?: string;
  organization_id?: string;
  account_name?: string;
  account_structure?: string;
  account_note?: string;
  two_factor_secret?: string;
  account_password?: string;
  phone_number?: string;
  mail_url?: string;
  session_token?: string;
  password?: string;
  disabled?: boolean;
  authorization_status?: string;
  tokens: CodexTokens;
  token_generation?: number;
  token_updated_at?: number;
  token_source_mode?: string;
  cloud_imported?: boolean;
  requires_reauth?: boolean;
  reauth_reason?: string;
  quota?: CodexQuota;
  quota_error?: CodexQuotaErrorInfo;
  tags?: string[];
  created_at: number;
  last_used: number;
}

export interface CodexOAuthLoginStartResponse {
  loginId: string;
  authUrl: string;
}

export interface CodexFileImportResult {
  imported: CodexAccount[];
  failed: { email: string; error: string }[];
}

export interface CodexBatchImportItem {
  itemId: string;
  source: string;
  label: string;
  accountId?: string | null;
  email?: string | null;
  accountType: string;
  provider?: string | null;
  quotaStatus: string;
  quotaError?: string | null;
  status: string;
  error?: string | null;
  defaultSelected: boolean;
  selectable: boolean;
  existing: boolean;
  duplicate?: boolean;
}

export interface CodexBatchImportPreview {
  sessionId: string;
  status: string;
  checkQuota: boolean;
  total: number;
  items: CodexBatchImportItem[];
}

export interface CodexCloudImportResult {
  imported: CodexAccount[];
  failed: { error: string }[];
}

export interface CodexServerUpdateFile {
  name: string;
  url: string;
  size?: number | null;
  sha256?: string | null;
  platform?: string | null;
  arch?: string | null;
  kind?: string | null;
}

export interface CodexServerUpdateInfo {
  currentVersion: string;
  latestVersion: string;
  hasUpdate: boolean;
  notes?: string | null;
  download?: CodexServerUpdateFile | null;
  files: CodexServerUpdateFile[];
}

export interface QuotaMetric {
  key: string;
  label: string;
  percentage: number;
  resetTime?: number;
}

export type CodexLocalAccessScope = 'localhost' | 'lan';
export type CodexLocalAccessClientBaseUrlHost = 'localhost' | '127.0.0.1';
export type CodexLocalAccessGatewayMode = 'legacy' | 'sidecar';
export type CodexLocalAccessRoutingStrategy =
  | 'auto'
  | 'quota_high_first'
  | 'quota_low_first'
  | 'plan_high_first'
  | 'plan_low_first'
  | 'expiry_soon_first'
  | 'custom';

export interface CodexLocalAccessProviderGateway {
  baseUrl: string;
  apiKey: string;
  upstreamModel: string;
  upstreamModels?: string[];
  wireApi?: CodexProviderWireApi | null;
  supportsVision?: boolean;
  modelCapabilities?: Record<string, { supportsVision?: boolean }>;
  visionRoutingModel?: string | null;
}

export interface CodexLocalAccessApiKey {
  id: string;
  label: string;
  key: string;
  providerGateway?: CodexLocalAccessProviderGateway | null;
  accountIds?: string[];
  modelPrefix?: string | null;
  allowedModels: string[];
  excludedModels: string[];
  enabled: boolean;
  createdAt: number;
  updatedAt: number;
  lastUsedAt?: number | null;
}

export interface CodexLocalAccessCollection {
  enabled: boolean;
  port: number;
  apiKey: string;
  apiKeys: CodexLocalAccessApiKey[];
  accessScope: CodexLocalAccessScope;
  clientBaseUrlHost: CodexLocalAccessClientBaseUrlHost;
  gatewayMode: CodexLocalAccessGatewayMode;
  upstreamProxyUrl?: string | null;
  routingStrategy: CodexLocalAccessRoutingStrategy;
  debugLogs: boolean;
  excludedModels: string[];
  sessionAffinity: boolean;
  sessionAffinityTtlMs: number;
  maxRetryCredentials: number;
  maxRetryIntervalMs: number;
  disableCooling: boolean;
  restrictFreeAccounts: boolean;
  boundOauthAccountId?: string | null;
  accountIds: string[];
  createdAt: number;
  updatedAt: number;
}

export interface CodexLocalAccessUsageStats {
  requestCount: number;
  successCount: number;
  failureCount: number;
  totalTokens: number;
  inputTokens: number;
  outputTokens: number;
  estimatedCostUsd: number;
}

export interface CodexLocalAccessStats {
  totals: CodexLocalAccessUsageStats;
}

export interface CodexLocalAccessProfileAttachment {
  profileDir: string;
  attached: boolean;
  configAttached: boolean;
  authAttached: boolean;
  modelProvider: string | null;
  baseUrl: string | null;
  expectedBaseUrl: string | null;
  error: string | null;
}

export interface CodexLocalAccessState {
  collection: CodexLocalAccessCollection | null;
  running: boolean;
  defaultProfile: CodexLocalAccessProfileAttachment | null;
  apiPortUrl: string | null;
  baseUrl: string | null;
  lanBaseUrl: string | null;
  modelIds: string[];
  lastError: string | null;
  memberCount: number;
  stats: CodexLocalAccessStats;
}

export interface CodexLocalAccessPortCleanupResult {
  killedCount: number;
  state: CodexLocalAccessState;
}

export interface CodexExternalApiServiceProfileConfig {
  id: string;
  name: string;
  providerName?: string | null;
  baseUrl: string;
  apiKey?: string | null;
  hasApiKey: boolean;
  source?: 'manual' | 'cloud';
  active: boolean;
  updatedAt: number;
  lastUsedAt?: number | null;
  wireApi?: CodexProviderWireApi | null;
  models: string[];
  defaultModel?: string | null;
  detectedAt?: number | null;
}

export interface CodexExternalApiServiceConfig {
  profileId?: string | null;
  providerName?: string | null;
  baseUrl: string;
  hasApiKey: boolean;
  source?: 'manual' | 'cloud';
  active: boolean;
  updatedAt: number;
  profiles: CodexExternalApiServiceProfileConfig[];
  wireApi?: CodexProviderWireApi | null;
  models: string[];
  defaultModel?: string | null;
  detectedAt?: number | null;
}

export interface CodexExternalApiServiceActivationResult {
  config: CodexExternalApiServiceConfig;
  state: CodexLocalAccessState;
}
