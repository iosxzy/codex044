import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ChangeEvent,
  type MouseEvent as ReactMouseEvent,
} from 'react';
import { listen, type UnlistenFn } from '@tauri-apps/api/event';
import { getCurrentWindow } from '@tauri-apps/api/window';
import { open as openFileDialog, save as saveFileDialog } from '@tauri-apps/plugin-dialog';
import { openPath, openUrl } from '@tauri-apps/plugin-opener';
import {
  AlertTriangle,
  Calendar,
  ChevronLeft,
  ChevronRight,
  Check,
  Clock,
  Copy,
  Download,
  Edit3,
  Eye,
  EyeOff,
  ExternalLink,
  FileJson,
  FolderOpen,
  KeyRound,
  Loader2,
  LogIn,
  Power,
  RefreshCw,
  Search,
  Server,
  Settings,
  Trash2,
  Upload,
  UserCheck,
  X,
} from 'lucide-react';
import appIcon from './assets/app-icon.png';
import packageJson from '../package.json';
import * as api from './codexApi';
import {
  buildCodexExportFileNameBase,
  buildCodexExportContent,
  parseCockpitToolsCodexExport,
  sanitizeFileNameSegment,
  type CodexExportFormat,
} from './codexExportFormats';
import type {
  CodexAccount,
  CodexAppSpeed,
  CodexBatchImportPreview,
  CodexExternalApiServiceConfig,
  CodexExternalApiServiceProfileConfig,
  CodexLocalAccessState,
  CodexProviderWireApi,
  CodexServerUpdateInfo,
  QuotaMetric,
} from './types';

type AddMode = 'oauth' | 'api-key' | 'json';
type FilterMode = 'all' | 'oauth' | 'agent-identity' | 'api-key' | 'current' | 'attention';
type ExportOutputMode = 'merged' | 'separate';
type MessageTone = 'info' | 'success' | 'warning' | 'error';
type Message = { tone: MessageTone; text: string } | null;
type AutoRefreshMinutes = -1 | 1 | 2 | 5 | 10;
type FileImportProgress = { current: number; total: number; email?: string } | null;
type CloudImportProgress = {
  sessionId: string;
  current: number;
  total: number;
  imported: number;
  failed: number;
  account?: CodexAccount | null;
  currentLabel?: string | null;
  cancelled: boolean;
  done: boolean;
} | null;
type ExportDocument = { id: string; label: string; fileNameBase: string; jsonContent: string };
type ServerUpdatePhase = 'idle' | 'checking' | 'available' | 'downloading' | 'downloaded' | 'installing' | 'up-to-date' | 'error';
type FormattedExportContent =
  | { type: 'single'; fileNameBase: string; jsonContent: string }
  | { type: 'multiple'; fileNameBase: string; documents: ExportDocument[] };
type ServerUpdateState = {
  phase: ServerUpdatePhase;
  info: CodexServerUpdateInfo | null;
  packagePath: string;
  error: string;
};
type BusyAction =
  | 'initial'
  | 'refresh-all'
  | 'import-files'
  | 'cloud-preview'
  | 'export'
  | 'config'
  | 'api-service-activate'
  | 'api-service-disable'
  | 'api-service-key'
  | 'api-service-port'
  | 'api-service-save'
  | 'api-service-speed'
  | 'api-service-external'
  | 'delete-selected'
  | 'delete-errors'
  | `switch:${string}`
  | `speed:${string}`
  | `export:${string}`
  | `refresh:${string}`
  | `delete:${string}`
  | `api-service-membership:${string}`
  | `api-service-remove:${string}`;

type EditDraft = {
  account: CodexAccount;
  name: string;
  note: string;
  tags: string;
  apiKey: string;
  apiBaseUrl: string;
  apiWireApi: CodexProviderWireApi;
};
type ApiServiceAddressMode = 'localhost' | 'external-api';

const OPENAI_BASE_URL = 'https://api.openai.com/v1';
const APP_VERSION = packageJson.version;
const AUTO_REFRESH_STORAGE_KEY = 'codex-account-manager-lite.auto-refresh-minutes';
const API_SERVICE_CARD_STORAGE_KEY = 'codex-account-manager-lite.show-api-service-card';
const API_SERVICE_ADDRESS_MODE_STORAGE_KEY = 'codex-account-manager-lite.api-service-address-mode';
const EXPORT_FORMAT_STORAGE_KEY = 'codex-account-manager-lite.export-format';
const EXPORT_OUTPUT_MODE_STORAGE_KEY = 'codex-account-manager-lite.export-output-mode';
const ACCOUNT_PAGE_SIZE_STORAGE_KEY = 'codex-account-manager-lite.account-page-size';
const API_SERVICE_MEMBER_PAGE_SIZE_STORAGE_KEY = 'codex-account-manager-lite.api-service-member-page-size';
const AUTO_REFRESH_OPTIONS: AutoRefreshMinutes[] = [-1, 1, 2, 5, 10];
const ACCOUNT_PAGE_SIZE_OPTIONS = [20, 50, 100] as const;
const API_SERVICE_MEMBER_PAGE_SIZE_OPTIONS = [50, 100, 200] as const;
const CLOUD_IMPORT_TOKEN_SOURCE_MODE = 'cloud_import';
const DEFAULT_SERVER_UPDATE_STATE: ServerUpdateState = {
  phase: 'idle',
  info: null,
  packagePath: '',
  error: '',
};
const EXPORT_FORMAT_OPTIONS: { value: CodexExportFormat; label: string }[] = [
  { value: 'cockpit_tools', label: '标准 JSON' },
  { value: 'sub2api', label: 'sub2api 格式' },
  { value: 'cpa', label: 'cpa 格式' },
];
const EXPORT_OUTPUT_MODE_OPTIONS: { value: ExportOutputMode; label: string }[] = [
  { value: 'merged', label: '全部账号合并为一个文件' },
  { value: 'separate', label: '每个账号单独一个文件' },
];
const API_SERVICE_MODE_OPTIONS: { value: ApiServiceAddressMode; label: string }[] = [
  { value: 'localhost', label: '本地代理' },
  { value: 'external-api', label: '代理 API 服务' },
];

function parseAutoRefreshMinutes(value: string | null): AutoRefreshMinutes {
  const parsed = Number(value);
  return AUTO_REFRESH_OPTIONS.includes(parsed as AutoRefreshMinutes)
    ? (parsed as AutoRefreshMinutes)
    : 10;
}

function formatAutoRefreshClock() {
  const date = new Date();
  const pad = (value: number) => String(value).padStart(2, '0');
  return `${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

function readApiServiceCardVisible() {
  return localStorage.getItem(API_SERVICE_CARD_STORAGE_KEY) !== 'false';
}

function isApiServiceAddressMode(value: string | null): value is ApiServiceAddressMode {
  return API_SERVICE_MODE_OPTIONS.some((option) => option.value === value);
}

function apiServiceModeLabel(mode: ApiServiceAddressMode) {
  return API_SERVICE_MODE_OPTIONS.find((option) => option.value === mode)?.label ?? mode;
}

function readApiServiceAddressMode() {
  const value = localStorage.getItem(API_SERVICE_ADDRESS_MODE_STORAGE_KEY);
  if (value === '127.0.0.1') return 'localhost';
  return isApiServiceAddressMode(value) ? value : null;
}

function saveApiServiceAddressMode(mode: ApiServiceAddressMode) {
  localStorage.setItem(API_SERVICE_ADDRESS_MODE_STORAGE_KEY, mode);
}

function readExportFormat(): CodexExportFormat {
  const value = localStorage.getItem(EXPORT_FORMAT_STORAGE_KEY);
  return EXPORT_FORMAT_OPTIONS.some((option) => option.value === value)
    ? (value as CodexExportFormat)
    : 'cockpit_tools';
}

function readExportOutputMode(): ExportOutputMode {
  const value = localStorage.getItem(EXPORT_OUTPUT_MODE_STORAGE_KEY);
  return value === 'separate' ? 'separate' : 'merged';
}

function serverUpdateButtonLabel(phase: ServerUpdatePhase) {
  if (phase === 'checking') return '检查中';
  if (phase === 'available') return '有更新';
  if (phase === 'downloading') return '下载中';
  if (phase === 'downloaded') return '重启安装';
  if (phase === 'installing') return '安装中';
  if (phase === 'up-to-date') return '已是最新';
  if (phase === 'error') return '重试更新';
  return '检查更新';
}

function stripError(value: unknown) {
  return String(value).replace(/^Error:\s*/, '');
}

function compactUpdateNotes(value?: string | null) {
  return (value || '').trim().replace(/\s+/g, ' ');
}

function normalizeJsonImportInput(value: string) {
  return value.replace(/[\u2028\u2029]/g, '\n').trim();
}

function decodeJwtPayload(token?: string) {
  const payload = token?.split('.')[1];
  if (!payload) return null;
  try {
    const normalized = payload.replace(/-/g, '+').replace(/_/g, '/');
    const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, '=');
    return JSON.parse(atob(padded)) as Record<string, unknown>;
  } catch {
    return null;
  }
}

function stringValue(value: unknown) {
  return typeof value === 'string' && value.trim() ? value.trim() : '';
}

function isApiKeyAccount(account: CodexAccount) {
  return (account.auth_mode || '').trim().toLowerCase() === 'apikey';
}

function isAgentIdentityAccount(account: CodexAccount) {
  const mode = (account.auth_mode || '').trim().toLowerCase();
  return mode === 'agentidentity' || mode === 'agent_identity' || Boolean(account.agent_identity);
}

function accountAuthModeLabel(account: CodexAccount) {
  if (isApiKeyAccount(account)) return 'API Key';
  if (isAgentIdentityAccount(account)) return 'Agent Identity';
  return 'OAuth';
}

function normalizeLoginMethodLabel(value?: string | null) {
  const raw = value?.trim();
  if (!raw) return '';
  const lower = raw.toLowerCase();
  if (['unknown', 'unknown_method', 'providerunknown', 'provider_unknown', '未知'].includes(lower)) {
    return '未知方式';
  }
  if (['api_key', 'apikey', 'api key'].includes(lower)) return 'API Key';
  if (lower === 'oauth') return 'OAuth';
  if (lower === 'password') return 'Password';
  if (lower === 'google') return 'Google';
  if (lower === 'github') return 'GitHub';
  if (lower === 'microsoft') return 'Microsoft';
  return raw;
}

function loginMethodLabel(account: CodexAccount) {
  const idTokenPayload = decodeJwtPayload(account.tokens?.id_token);
  const authProvider = stringValue(idTokenPayload?.auth_provider);
  return (
    normalizeLoginMethodLabel(
      account.login_method ||
        account.loginMethod ||
        account.auth_method ||
        account.authMethod ||
        account.signed_in_with ||
        account.signedInWith ||
        authProvider,
    ) || (isApiKeyAccount(account) ? 'API Key' : isAgentIdentityAccount(account) ? 'Agent Identity' : '未知方式')
  );
}

function loginMethodText(account: CodexAccount) {
  return `使用 ${loginMethodLabel(account)} 登录`;
}

function displayName(account: CodexAccount) {
  if (isApiKeyAccount(account)) {
    return account.account_name?.trim() || account.api_provider_name?.trim() || 'API Key';
  }
  return account.account_name?.trim() || account.email;
}

function isCloudImportedAccount(account: CodexAccount) {
  return Boolean(account.cloud_imported)
    || (account.token_source_mode || '').trim().toLowerCase() === CLOUD_IMPORT_TOKEN_SOURCE_MODE;
}

function markCloudImportedAccount(account: CodexAccount): CodexAccount {
  return {
    ...account,
    cloud_imported: true,
    token_source_mode: CLOUD_IMPORT_TOKEN_SOURCE_MODE,
  };
}

function isAttentionAccount(account: CodexAccount) {
  return Boolean(account.requires_reauth || account.quota_error?.message);
}

function formatExportTimestamp(date = new Date()) {
  const pad = (value: number) => String(value).padStart(2, '0');
  return [
    date.getFullYear(),
    pad(date.getMonth() + 1),
    pad(date.getDate()),
    '-',
    pad(date.getHours()),
    pad(date.getMinutes()),
    pad(date.getSeconds()),
  ].join('');
}

function exportFormatLabel(format: CodexExportFormat) {
  if (format === 'cockpit_tools') return '标准 JSON';
  if (format === 'sub2api') return 'sub2api 格式';
  return 'cpa 格式';
}

function exportSingleFileNameBase(fileNameBase: string, format: CodexExportFormat) {
  if (format === 'cockpit_tools') {
    return `${fileNameBase}_standard_json`;
  }
  return fileNameBase;
}

function exportFormatFileNameBase(format: CodexExportFormat) {
  if (format === 'cockpit_tools') return 'standard_json';
  return format;
}

function exportFileName(fileNameBase: string, timestamp: string) {
  return `${sanitizeFileNameSegment(fileNameBase, 'codex_accounts')}_${timestamp}.json`;
}

function getDirectoryPath(filePath: string) {
  const slashIndex = Math.max(filePath.lastIndexOf('/'), filePath.lastIndexOf('\\'));
  return slashIndex > 0 ? filePath.slice(0, slashIndex) : filePath;
}

function buildExportDefaultFileNameBase(fileNameBase: string, format: CodexExportFormat) {
  return exportSingleFileNameBase(
    buildCodexExportFileNameBase(fileNameBase || 'codex_accounts', format),
    format,
  );
}

function exportSeparateFileNameBase(format: CodexExportFormat, index: number) {
  return `${exportFormatFileNameBase(format)}_${String(index + 1).padStart(2, '0')}`;
}

function maskStringValue(value: string) {
  const length = value.length;
  if (length <= 0) return value;
  if (length <= 2) return '*'.repeat(length);
  if (length === 3) return `${value.slice(0, 1)}*${value.slice(-1)}`;
  if (length === 4) return `${value.slice(0, 1)}**${value.slice(-1)}`;
  return `${value.slice(0, 2)}***${value.slice(-2)}`;
}

function maskJsonValues(value: unknown): unknown {
  if (typeof value === 'string') return maskStringValue(value);
  if (Array.isArray(value)) return value.map((item) => maskJsonValues(item));
  if (value && typeof value === 'object') {
    const result: Record<string, unknown> = {};
    for (const [key, item] of Object.entries(value as Record<string, unknown>)) {
      result[key] = maskJsonValues(item);
    }
    return result;
  }
  return value;
}

function maskJsonPreviewContent(jsonContent: string) {
  if (!jsonContent) return '';
  try {
    return JSON.stringify(maskJsonValues(JSON.parse(jsonContent) as unknown), null, 2);
  } catch {
    return jsonContent.replace(/[^\s]/g, '*');
  }
}

function planLabel(account: CodexAccount) {
  const raw = account.plan_type?.trim();
  if (!raw) return isApiKeyAccount(account) ? 'API KEY' : 'FREE';
  const upper = raw.toUpperCase();
  if (upper.includes('TEAM')) return 'TEAM';
  if (upper.includes('ENTERPRISE')) return 'ENTERPRISE';
  if (upper.includes('PLUS')) return 'PLUS';
  if (upper.includes('PRO')) return 'PRO';
  return upper;
}

function planClass(account: CodexAccount) {
  const label = planLabel(account).toLowerCase();
  if (label.includes('api')) return 'api';
  if (label.includes('pro')) return 'pro';
  if (label.includes('plus')) return 'plus';
  if (label.includes('team') || label.includes('enterprise')) return 'team';
  return 'free';
}

function quotaClass(percentage: number) {
  if (percentage >= 80) return 'high';
  if (percentage >= 40) return 'medium';
  if (percentage >= 10) return 'low';
  return 'critical';
}

function quotaMetrics(account: CodexAccount): QuotaMetric[] {
  const quota = account.quota;
  if (!quota) return [];
  const metrics: QuotaMetric[] = [];
  if (quota.hourly_window_present !== false) {
    metrics.push({
      key: 'hourly',
      label: quota.hourly_window_minutes ? `${Math.ceil(quota.hourly_window_minutes / 60)}h` : '5h',
      percentage: Math.max(0, Math.min(100, Math.round(quota.hourly_percentage ?? 0))),
      resetTime: quota.hourly_reset_time,
    });
  }
  if (quota.weekly_window_present !== false) {
    metrics.push({
      key: 'weekly',
      label: 'Weekly',
      percentage: Math.max(0, Math.min(100, Math.round(quota.weekly_percentage ?? 0))),
      resetTime: quota.weekly_reset_time,
    });
  }
  return metrics;
}

function formatResetTime(timestamp?: number) {
  if (!timestamp) return '';
  const diff = timestamp - Math.floor(Date.now() / 1000);
  const date = new Date(timestamp * 1000);
  const pad = (value: number) => String(value).padStart(2, '0');
  const absolute = `${pad(date.getMonth() + 1)}/${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}`;
  if (diff <= 0) return `已重置 (${absolute})`;
  const minutes = Math.floor(diff / 60);
  const days = Math.floor(minutes / 1440);
  const hours = Math.floor((minutes % 1440) / 60);
  const mins = minutes % 60;
  const parts = [
    days > 0 ? `${days}d` : '',
    hours > 0 ? `${hours}h` : '',
    mins > 0 ? `${mins}m` : '',
  ].filter(Boolean);
  return `${parts.join(' ') || '<1m'} (${absolute})`;
}

type SubscriptionPresentation = {
  tone: 'active' | 'warning' | 'expired' | 'missing';
  valueText: string;
  detailText: string;
  titleText: string;
};

function parseSubscriptionDate(value?: string) {
  const trimmed = value?.trim();
  if (!trimmed) return null;
  if (/^\d+$/.test(trimmed)) {
    let timestamp = Number(trimmed);
    if (!Number.isFinite(timestamp)) return null;
    if (timestamp < 1_000_000_000_000) timestamp *= 1000;
    const date = new Date(timestamp);
    return Number.isNaN(date.getTime()) ? null : date;
  }
  const date = new Date(trimmed);
  return Number.isNaN(date.getTime()) ? null : date;
}

function formatSubscriptionDate(date: Date) {
  const pad = (value: number) => String(value).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

function subscriptionPresentation(value?: string): SubscriptionPresentation {
  const date = parseSubscriptionDate(value);
  if (!date) {
    return {
      tone: 'missing',
      valueText: '未获得订阅信息',
      detailText: '',
      titleText: '未获得订阅信息',
    };
  }

  const detailText = formatSubscriptionDate(date);
  const diffMs = date.getTime() - Date.now();
  if (diffMs <= 0) {
    return {
      tone: 'expired',
      valueText: '已过期',
      detailText,
      titleText: `订阅有效至：${detailText}`,
    };
  }

  const hourMs = 60 * 60 * 1000;
  const dayMs = 24 * hourMs;
  if (diffMs < dayMs) {
    return {
      tone: 'warning',
      valueText: `${Math.max(1, Math.ceil(diffMs / hourMs))}小时`,
      detailText,
      titleText: `订阅有效至：${detailText}`,
    };
  }

  const days = Math.ceil(diffMs / dayMs);
  return {
    tone: days <= 7 ? 'warning' : 'active',
    valueText: days > 99 ? '99+天' : `${days}天`,
    detailText,
    titleText: `订阅有效至：${detailText}`,
  };
}

function formatDate(seconds?: number) {
  const parts = formatDateParts(seconds);
  return parts.time ? `${parts.date} ${parts.time}` : parts.date;
}

function formatDateParts(seconds?: number) {
  if (!seconds) return { date: '从未', time: '' };
  const date = new Date(seconds * 1000);
  if (Number.isNaN(date.getTime())) return { date: '未知', time: '' };
  const pad = (value: number) => String(value).padStart(2, '0');
  return {
    date: `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`,
    time: `${pad(date.getHours())}:${pad(date.getMinutes())}`,
  };
}

function normalizeUrl(value: string) {
  return value.trim().replace(/\/+$/, '');
}

function normalizeHttpBaseUrl(value: string) {
  const normalized = normalizeUrl(value);
  if (!normalized) return '';
  try {
    const url = new URL(normalized);
    if (url.protocol !== 'http:' && url.protocol !== 'https:') return '';
    return normalized;
  } catch {
    return '';
  }
}

function isOpenAIBaseUrl(value: string) {
  return normalizeUrl(value).toLowerCase() === OPENAI_BASE_URL.toLowerCase();
}

function searchText(account: CodexAccount) {
  return [
    account.email,
    account.account_name,
    account.plan_type,
    account.account_note,
    account.api_base_url,
    account.api_provider_name,
    ...(account.tags ?? []),
  ]
    .filter(Boolean)
    .join(' ')
    .toLowerCase();
}

function isFreeAccount(account: CodexAccount) {
  return planLabel(account).toLowerCase().includes('free');
}

function localAccessBaseUrl(state: CodexLocalAccessState | null) {
  return state?.baseUrl || state?.apiPortUrl || (state?.collection ? `http://localhost:${state.collection.port}/v1` : '');
}

function localAccessApiKey(state: CodexLocalAccessState | null) {
  const collection = state?.collection;
  if (!collection) return '';
  return collection.apiKeys.find((item) => item.enabled)?.key || collection.apiKeys[0]?.key || collection.apiKey || '';
}

function isCloudProxyApiConfig(config: CodexExternalApiServiceConfig | null | undefined) {
  return config?.source === 'cloud';
}

function hasProxyApiConfig(config: CodexExternalApiServiceConfig | null | undefined) {
  if (!config?.hasApiKey) return false;
  return isCloudProxyApiConfig(config) || Boolean(config.baseUrl);
}

function proxyApiConfigTitle(config: CodexExternalApiServiceConfig | null | undefined) {
  if (!config) return '代理上游';
  if (isCloudProxyApiConfig(config)) return '云端默认';
  try {
    const host = new URL(config.baseUrl).host;
    if (host) return host;
  } catch {
    // Fall through to the saved value when an older config has a non-standard URL.
  }
  return config.baseUrl.trim() || '代理上游';
}

function proxyProfileTitle(profile: CodexExternalApiServiceProfileConfig) {
  return profile.name?.trim() || profile.baseUrl.trim() || '未命名代理配置';
}

function proxyModelFamilyLabel(models: string[] | null | undefined, defaultModel?: string | null) {
  const values = [...(models ?? []), defaultModel ?? '']
    .map((value) => value.trim().toLowerCase())
    .filter(Boolean);
  if (values.some((value) => value.startsWith('grok-'))) return 'Grok';
  if (values.some((value) => value.includes('deepseek'))) return 'DeepSeek';
  if (values.some((value) => {
    const model = value.split('/').pop() || value;
    return model === 'gemini' || model.startsWith('gemini-');
  })) return 'Gemini';
  if (values.some((value) => value === 'claude' || value.startsWith('claude-'))) return 'Claude';
  if (values.some((value) => value === 'glm' || value.startsWith('glm-') || value.includes('chatglm') || value.includes('zhipu'))) return 'GLM';
  if (values.some((value) => value.includes('kimi') || value.includes('moonshot'))) return 'Kimi';
  if (values.some((value) => value.includes('jimeng') || value.includes('seedream') || value.includes('seedance'))) return '即梦';
  if (values.some((value) => value.startsWith('gpt-') || value.includes('codex'))) return 'GPT';
  return values.length > 0 ? '其他' : '待检测';
}

function maskProxyApiKey(apiKey: string | null | undefined) {
  const value = apiKey?.trim() ?? '';
  if (!value) return '未保存 Key';
  if (value.length <= 10) return '••••••••';
  return `${value.slice(0, 4)}••••••••${value.slice(-4)}`;
}

function getActiveApiServiceMode(
  state: CodexLocalAccessState | null,
  externalConfig: CodexExternalApiServiceConfig | null,
): ApiServiceAddressMode | null {
  if (externalConfig?.active) return 'external-api';
  const collection = state?.collection ?? null;
  if (state?.running || collection?.enabled) {
    return 'localhost';
  }
  return null;
}

function isApiServiceTargetActive(
  state: CodexLocalAccessState | null,
  externalConfig: CodexExternalApiServiceConfig | null,
  targetMode: ApiServiceAddressMode,
  targetProxyProfileId = '',
) {
  if (getActiveApiServiceMode(state, externalConfig) !== targetMode) return false;
  if (targetMode !== 'external-api') return true;
  return (externalConfig?.profileId?.trim() || '') === targetProxyProfileId.trim();
}

function formatLocalAccessUsage(state: CodexLocalAccessState | null) {
  const usage = state?.stats?.totals;
  if (!usage) return '0 请求 / 0 tokens';
  return `${usage.requestCount || 0} 请求 / ${usage.totalTokens || 0} tokens`;
}

function readStoredPageSize(storageKey: string, options: readonly number[], fallback: number) {
  const normalizedFallback = options.includes(fallback) ? fallback : options[0] ?? fallback;
  try {
    const value = Number.parseInt(localStorage.getItem(storageKey) || '', 10);
    return options.includes(value) ? value : normalizedFallback;
  } catch {
    return normalizedFallback;
  }
}

function writeStoredPageSize(storageKey: string, value: number) {
  try {
    localStorage.setItem(storageKey, String(value));
  } catch {
    // localStorage is best-effort only.
  }
}

function useDebouncedValue<TValue>(value: TValue, delayMs: number) {
  const [debounced, setDebounced] = useState(value);

  useEffect(() => {
    const timer = window.setTimeout(() => setDebounced(value), delayMs);
    return () => window.clearTimeout(timer);
  }, [delayMs, value]);

  return debounced;
}

function usePagination<TItem>({
  items,
  storageKey,
  pageSizeOptions,
  defaultPageSize,
}: {
  items: readonly TItem[];
  storageKey: string;
  pageSizeOptions: readonly number[];
  defaultPageSize: number;
}) {
  const [pageSize, setPageSizeState] = useState(() =>
    readStoredPageSize(storageKey, pageSizeOptions, defaultPageSize),
  );
  const [currentPage, setCurrentPageState] = useState(1);
  const totalItems = items.length;
  const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));

  useEffect(() => {
    setPageSizeState((current) => (pageSizeOptions.includes(current) ? current : defaultPageSize));
  }, [defaultPageSize, pageSizeOptions]);

  useEffect(() => {
    writeStoredPageSize(storageKey, pageSize);
  }, [pageSize, storageKey]);

  useEffect(() => {
    setCurrentPageState((current) => Math.min(current, totalPages));
  }, [totalPages]);

  const pageItems = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return items.slice(start, start + pageSize);
  }, [currentPage, items, pageSize]);

  const setCurrentPage = useCallback(
    (page: number) => {
      if (!Number.isFinite(page)) return;
      setCurrentPageState(Math.max(1, Math.min(totalPages, Math.floor(page))));
    },
    [totalPages],
  );

  const setPageSize = useCallback(
    (nextPageSize: number) => {
      const normalized = pageSizeOptions.includes(nextPageSize) ? nextPageSize : defaultPageSize;
      setCurrentPageState((current) =>
        Math.max(1, Math.floor(((current - 1) * pageSize) / normalized) + 1),
      );
      setPageSizeState(normalized);
    },
    [defaultPageSize, pageSize, pageSizeOptions],
  );

  const rangeStart = totalItems === 0 ? 0 : (currentPage - 1) * pageSize + 1;
  const rangeEnd = totalItems === 0 ? 0 : Math.min(totalItems, currentPage * pageSize);

  return {
    pageItems,
    totalItems,
    currentPage,
    totalPages,
    pageSize,
    pageSizeOptions,
    rangeStart,
    rangeEnd,
    canGoPrevious: currentPage > 1,
    canGoNext: currentPage < totalPages,
    setCurrentPage,
    setPageSize,
    goToPreviousPage: () => setCurrentPage(currentPage - 1),
    goToNextPage: () => setCurrentPage(currentPage + 1),
  };
}

function PaginationControls({
  totalItems,
  currentPage,
  totalPages,
  pageSize,
  pageSizeOptions,
  rangeStart,
  rangeEnd,
  canGoPrevious,
  canGoNext,
  onPageSizeChange,
  onPreviousPage,
  onNextPage,
}: {
  totalItems: number;
  currentPage: number;
  totalPages: number;
  pageSize: number;
  pageSizeOptions: readonly number[];
  rangeStart: number;
  rangeEnd: number;
  canGoPrevious: boolean;
  canGoNext: boolean;
  onPageSizeChange: (pageSize: number) => void;
  onPreviousPage: () => void;
  onNextPage: () => void;
}) {
  if (totalItems === 0) return null;

  return (
    <div className="pagination-container">
      <span className="pagination-info">
        显示 {rangeStart} - {rangeEnd} / {totalItems}
      </span>
      <div className="pagination-controls">
        <select value={String(pageSize)} onChange={(event) => onPageSizeChange(Number(event.target.value))}>
          {pageSizeOptions.map((option) => (
            <option key={option} value={option}>{option} / 页</option>
          ))}
        </select>
        <button type="button" className="icon-btn" onClick={onPreviousPage} disabled={!canGoPrevious} aria-label="上一页">
          <ChevronLeft size={15} />
        </button>
        <span className="pagination-page">{currentPage} / {totalPages}</span>
        <button type="button" className="icon-btn" onClick={onNextPage} disabled={!canGoNext} aria-label="下一页">
          <ChevronRight size={15} />
        </button>
      </div>
    </div>
  );
}

function StatusMessage({ message, onClose }: { message: Message; onClose: () => void }) {
  if (!message) return null;
  const titleByTone: Record<MessageTone, string> = {
    info: '提示',
    success: '操作成功',
    warning: '需要注意',
    error: '操作失败',
  };
  return (
    <div className="toast-viewport" aria-live={message.tone === 'error' ? 'assertive' : 'polite'}>
      <div className={`toast ${message.tone}`} role={message.tone === 'error' ? 'alert' : 'status'}>
        <div className="toast-icon">
          {message.tone === 'error' || message.tone === 'warning' ? (
            <AlertTriangle size={17} />
          ) : (
            <Check size={17} />
          )}
        </div>
        <div className="toast-body">
          <strong>{titleByTone[message.tone]}</strong>
          <span>{message.text}</span>
        </div>
        <button type="button" onClick={onClose} aria-label="关闭提示">
          <X size={14} />
        </button>
      </div>
    </div>
  );
}

function SpeedSelect({
  value,
  busy = false,
  disabled = false,
  onChange,
}: {
  value?: CodexAppSpeed | null;
  busy?: boolean;
  disabled?: boolean;
  onChange: (speed: CodexAppSpeed) => void;
}) {
  const current = value ?? 'standard';
  const options: { value: CodexAppSpeed; label: string; title: string }[] = [
    { value: 'standard', label: '标准', title: '默认速度，常规用量' },
    { value: 'fast', label: '快速', title: '1.5 倍速，用量增加' },
  ];
  const currentOption = options.find((option) => option.value === current) ?? options[0];

  return (
    <label className="speed-select" title={currentOption.title}>
      <select
        value={current}
        disabled={disabled || busy}
        aria-label="Codex 速度"
        onChange={(event) => onChange(event.target.value as CodexAppSpeed)}
      >
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </label>
  );
}

function AccountCard({
  account,
  current,
  busy,
  onSwitch,
  onExport,
  onRefresh,
  onEdit,
  onDelete,
  onSpeedChange,
  selected,
  masked,
  onToggleSelect,
  inApiService,
  apiServiceRestricted,
  onToggleApiService,
}: {
  account: CodexAccount;
  current: boolean;
  busy: BusyAction | null;
  onSwitch: (account: CodexAccount) => void;
  onExport: (account: CodexAccount) => void;
  onRefresh: (account: CodexAccount) => void;
  onEdit: (account: CodexAccount) => void;
  onDelete: (account: CodexAccount) => void;
  onSpeedChange: (account: CodexAccount, speed: CodexAppSpeed) => void;
  selected: boolean;
  masked: boolean;
  onToggleSelect: (account: CodexAccount) => void;
  inApiService: boolean;
  apiServiceRestricted: boolean;
  onToggleApiService: (account: CodexAccount) => void;
}) {
  const metrics = quotaMetrics(account);
  const refreshing = busy === `refresh:${account.id}`;
  const switching = busy === `switch:${account.id}`;
  const exporting = busy === `export:${account.id}`;
  const deleting = busy === `delete:${account.id}`;
  const updatingApiService = busy === `api-service-membership:${account.id}`;
  const exportable = !isCloudImportedAccount(account);
  const subscriptionInfo = subscriptionPresentation(account.subscription_active_until);
  const lastUsed = formatDateParts(account.last_used);
  const lastUsedDaySeparator = lastUsed.time ? lastUsed.date.lastIndexOf('-') : -1;
  const lastUsedDatePrefix = lastUsedDaySeparator >= 0
    ? lastUsed.date.slice(0, lastUsedDaySeparator)
    : lastUsed.date;
  const lastUsedDay = lastUsedDaySeparator >= 0
    ? lastUsed.date.slice(lastUsedDaySeparator)
    : '';

  return (
    <article className={`account-card${current ? ' current' : ''}${selected ? ' selected' : ''}`}>
      <header className="account-head">
        <div className="account-title">
          <div className="account-title-main">
            <label className="account-select" title="选择账号">
              <input
                type="checkbox"
                checked={selected}
                disabled={Boolean(busy)}
                onChange={() => onToggleSelect(account)}
              />
            </label>
            <div>
              <h2 title={masked ? '*****' : displayName(account)}>{masked ? '*****' : displayName(account)}</h2>
              <p title={masked ? '*****' : account.email}>{masked ? '*****' : account.email}</p>
            </div>
          </div>
          {current ? (
            <span className="current-pill">
              <UserCheck size={13} />
              当前
            </span>
          ) : null}
        </div>
        <div className="badges">
          <span className={`plan ${planClass(account)}`}>{planLabel(account)}</span>
          <span>{accountAuthModeLabel(account)}</span>
          {!isApiKeyAccount(account) && !isAgentIdentityAccount(account) ? <span className="auth-method-chip">{loginMethodText(account)}</span> : null}
          <button
            type="button"
            className={`api-service-membership${inApiService ? ' joined' : ''}`}
            onClick={() => onToggleApiService(account)}
            disabled={Boolean(busy) || (!inApiService && apiServiceRestricted)}
            title={apiServiceRestricted && !inApiService
              ? '已开启排除 FREE，当前账号不可加入'
              : inApiService
                ? '点击移出 API 服务'
                : '点击加入 API 服务'}
          >
            {updatingApiService ? <Loader2 size={12} className="spin" /> : null}
            {inApiService ? '已加入 API 服务' : '未加入 API 服务'}
          </button>
        </div>
      </header>

      {account.requires_reauth ? (
        <div className="inline-alert">
          <AlertTriangle size={15} />
          <span>{account.reauth_reason || '需要重新授权'}</span>
        </div>
      ) : null}

      {account.quota_error?.message ? (
        <div className="inline-alert danger">
          <AlertTriangle size={15} />
          <span>{account.quota_error.message}</span>
        </div>
      ) : null}

      {metrics.length > 0 ? (
        <div className="quota-grid">
          {metrics.map((metric) => {
            const tone = quotaClass(metric.percentage);
            return (
              <div className="quota-item" key={metric.key}>
                <div className="quota-top">
                  <span className="quota-name">
                    {metric.key === 'weekly' ? <Calendar size={15} /> : <Clock size={15} />}
                    {metric.label}
                  </span>
                  <strong className={tone}>{metric.percentage}%</strong>
                </div>
                <div className="quota-track">
                  <span className={tone} style={{ width: `${metric.percentage}%` }} />
                </div>
                {metric.resetTime ? (
                  <small>{formatResetTime(metric.resetTime)}</small>
                ) : null}
              </div>
            );
          })}
        </div>
      ) : (
        <div className="quota-empty">暂无配额数据</div>
      )}

      {!isApiKeyAccount(account) ? (
        <div
          className={`subscription-status ${subscriptionInfo.tone}`}
          title={subscriptionInfo.titleText}
        >
          <div className="subscription-status-main">
            <Calendar size={16} />
            {subscriptionInfo.tone === 'missing' ? null : <span>有效期</span>}
            <strong>{subscriptionInfo.valueText}</strong>
          </div>
          {subscriptionInfo.detailText ? (
            <span className="subscription-status-date">{subscriptionInfo.detailText}</span>
          ) : null}
        </div>
      ) : null}

      {isApiKeyAccount(account) ? (
        <div className="meta-line">
          <span>Base URL</span>
          <strong title={masked ? '*****' : account.api_base_url || OPENAI_BASE_URL}>
            {masked ? '*****' : account.api_base_url || OPENAI_BASE_URL}
          </strong>
        </div>
      ) : null}

      {account.account_note?.trim() ? <p className="note">{account.account_note.trim()}</p> : null}

      {account.tags?.length ? (
        <div className="tags">
          {account.tags.slice(0, 5).map((tag) => (
            <span key={tag}>{tag}</span>
          ))}
          {account.tags.length > 5 ? <span>+{account.tags.length - 5}</span> : null}
        </div>
      ) : null}

      <footer className="account-foot single-account-foot">
        <span className="last-used-stack" title={`最近使用：${formatDate(account.last_used)}`}>
          <span className="last-used-date">最近使用：{lastUsedDatePrefix}</span>
          {lastUsed.time ? (
            <span className="last-used-time">{lastUsedDay} {lastUsed.time}</span>
          ) : null}
        </span>
        <div className="card-actions">
          <SpeedSelect
            value={account.app_speed}
            busy={busy === `speed:${account.id}`}
            disabled={Boolean(busy)}
            onChange={(speed) => onSpeedChange(account, speed)}
          />
          <button type="button" className="icon-btn" onClick={() => onEdit(account)} disabled={Boolean(busy)} title="编辑账号" aria-label="编辑账号">
            <Edit3 size={15} />
          </button>
          <button type="button" className="icon-btn" onClick={() => onRefresh(account)} disabled={Boolean(busy)} title="刷新配额" aria-label="刷新配额">
            {refreshing ? <Loader2 size={15} className="spin" /> : <RefreshCw size={15} />}
          </button>
          {exportable ? (
            <button type="button" className="icon-btn" onClick={() => onExport(account)} disabled={Boolean(busy)} title="导出此账号" aria-label="导出此账号">
              {exporting ? <Loader2 size={15} className="spin" /> : <Download size={15} />}
            </button>
          ) : null}
          <button type="button" className="primary small" onClick={() => onSwitch(account)} disabled={Boolean(busy)} title="切换账号" aria-label="切换账号">
            {switching ? <Loader2 size={15} className="spin" /> : <UserCheck size={15} />}
          </button>
          <button type="button" className="danger-btn" onClick={() => onDelete(account)} disabled={Boolean(busy)} title="删除账号" aria-label="删除账号">
            {deleting ? <Loader2 size={15} className="spin" /> : <Trash2 size={15} />}
          </button>
        </div>
      </footer>
    </article>
  );
}

function ApiServiceCard({
  state,
  externalConfig,
  apiMode,
  selectedProxyProfileId,
  busy,
  appSpeed,
  selected,
  masked,
  onSpeedChange,
  onOpen,
  onOpenAccounts,
  onToggle,
  onModeChange,
  onProxyProfileChange,
  onToggleSelect,
}: {
  state: CodexLocalAccessState | null;
  externalConfig: CodexExternalApiServiceConfig | null;
  apiMode: ApiServiceAddressMode;
  selectedProxyProfileId: string;
  busy: BusyAction | null;
  appSpeed: CodexAppSpeed;
  selected: boolean;
  masked: boolean;
  onSpeedChange: (speed: CodexAppSpeed) => void;
  onOpen: () => void;
  onOpenAccounts: () => void;
  onToggle: () => void;
  onModeChange: (mode: ApiServiceAddressMode) => void;
  onProxyProfileChange: (profileId: string) => void;
  onToggleSelect: () => void;
}) {
  const collection = state?.collection ?? null;
  const running = Boolean(state?.running);
  const enabled = Boolean(collection?.enabled);
  const externalActive = Boolean(externalConfig?.active);
  const hasProxyConfig = hasProxyApiConfig(externalConfig);
  const proxyCardMode = apiMode === 'external-api';
  const activeMode = getActiveApiServiceMode(state, externalConfig);
  const serviceActive = Boolean(activeMode);
  const serviceRunning = activeMode === 'external-api' ? externalActive : running;
  const targetIsActive = isApiServiceTargetActive(
    state,
    externalConfig,
    apiMode,
    selectedProxyProfileId,
  );
  const pendingSwitch = serviceActive && !targetIsActive;
  const memberCount = collection?.accountIds.length ?? 0;
  const proxyProfiles = externalConfig?.profiles ?? [];
  const selectedProxyProfile = proxyProfiles.find((profile) => profile.id === selectedProxyProfileId) ?? null;
  const selectedProxyBaseUrl = selectedProxyProfile?.baseUrl.trim() || '';
  const baseUrl = proxyCardMode
    ? selectedProxyProfileId
      ? selectedProxyBaseUrl
      : '云端默认配置'
    : localAccessBaseUrl(state);
  const selectedServiceTarget = proxyCardMode
    ? selectedProxyProfileId
      ? `profile:${selectedProxyProfileId}`
      : 'cloud'
    : 'localhost';
  const statusText = pendingSwitch
    ? '待切换'
    : proxyCardMode
    ? externalActive
      ? '代理已启用'
      : hasProxyConfig
      ? '代理已保存'
      : '代理未配置'
    : running
    ? '运行中'
    : enabled
    ? '待恢复'
    : collection
    ? '未启用'
    : '未配置';
  const toggleStopsService = serviceActive && targetIsActive;
  const targetModeLabel = apiServiceModeLabel(apiMode);
  const activeModeLabel = activeMode ? apiServiceModeLabel(activeMode) : '';
  const toggleActionLabel = toggleStopsService
    ? proxyCardMode
      ? '停用代理 API 服务'
      : '停用 API 服务'
    : pendingSwitch
    ? `切换到 ${targetModeLabel}`
    : proxyCardMode
    ? hasProxyConfig
      ? '启动代理 API 服务'
      : '读取云端代理 API 服务'
    : '启动 API 服务';
  const changeServiceTarget = (value: string) => {
    if (value === 'localhost') {
      onModeChange('localhost');
      return;
    }
    onProxyProfileChange(value.startsWith('profile:') ? value.slice('profile:'.length) : '');
    onModeChange('external-api');
  };

  return (
    <article className={`account-card api-service-account-card${serviceRunning ? ' running' : ''}${selected ? ' selected' : ''}`}>
      <header className="account-head">
        <div className="account-title">
          <div className="account-title-main">
            <label className="account-select" title="选择 API 服务卡片">
              <input
                type="checkbox"
                checked={selected}
                disabled={Boolean(busy)}
                onChange={onToggleSelect}
              />
            </label>
            <div>
              <h2>API 服务</h2>
              <p>{proxyCardMode ? '代理 API 服务配置' : '本地 Codex 多账号服务'}</p>
            </div>
          </div>
          <span className={`current-pill api-service-status${!pendingSwitch && serviceRunning ? ' running' : ''}`}>
            <Server size={13} />
            {statusText}
          </span>
        </div>
        <div className="badges">
          <span className="api-service-badge">{proxyCardMode ? '代理 API 服务' : 'API 服务'}</span>
          {!proxyCardMode ? (
            <>
              <span>{`${memberCount} 个服务账号`}</span>
              <span>{formatLocalAccessUsage(state)}</span>
            </>
          ) : null}
        </div>
      </header>

      {!proxyCardMode && state?.lastError ? (
        <div className="inline-alert danger">
          <AlertTriangle size={15} />
          <span>{state.lastError}</span>
        </div>
      ) : null}

      <div className="meta-line api-service-mode-select">
        <span>Base URL</span>
        <select
          value={selectedServiceTarget}
          onChange={(event) => changeServiceTarget(event.target.value)}
          disabled={Boolean(busy)}
          title={masked ? '*****' : baseUrl || (proxyCardMode ? '留空后启动时从云端读取' : '保存账号集合后生成')}
          aria-label="切换 API 服务配置"
        >
          <option value="localhost">本地代理</option>
          <option value="cloud">云端默认</option>
          {proxyProfiles.map((profile) => (
            <option key={profile.id} value={`profile:${profile.id}`}>
              {`${proxyProfileTitle(profile)} · ${masked ? '*****' : profile.baseUrl}`}
            </option>
          ))}
        </select>
      </div>

      <p className="note">
        {pendingSwitch
          ? `点击启动会切换到 ${targetModeLabel}。`
          : proxyCardMode
          ? externalActive
            ? isCloudProxyApiConfig(externalConfig)
              ? '当前 Codex 调用云端默认代理 API 配置。'
              : '当前 Codex 调用代理 API 地址和 API Key。'
            : selectedProxyProfile
            ? '点击启动会启用已选择的代理 API 服务配置。'
            : hasProxyConfig
            ? '点击启动即可启用已保存的代理 API 服务。'
            : '点击启动会从云端读取默认代理 API 服务配置。'
          : memberCount > 0
          ? '点击启动后会把 Codex 切换到本地 API 服务。'
          : '先管理服务账号并保存集合，再启动 API 服务。'}
      </p>

      <footer className="account-foot">
        <span>
          {pendingSwitch
            ? `当前：${activeModeLabel}`
            : proxyCardMode
            ? externalActive
              ? '代理服务已启用'
              : '代理服务未启用'
            : enabled
            ? '已配置为可用服务'
            : '未启用服务'}
        </span>
        <div className="card-actions">
          <SpeedSelect
            value={appSpeed}
            busy={busy === 'api-service-speed'}
            disabled={Boolean(busy)}
            onChange={onSpeedChange}
          />
          {!proxyCardMode ? (
            <button type="button" className="secondary small" onClick={onOpenAccounts} disabled={Boolean(busy)} title="服务账号" aria-label="服务账号">
              <UserCheck size={14} />
            </button>
          ) : null}
          <button type="button" className="secondary small" onClick={onOpen} disabled={Boolean(busy)} title="管理 API 服务" aria-label="管理 API 服务">
            <Settings size={14} />
          </button>
          <button
            type="button"
            className={`${toggleStopsService ? 'danger-btn' : 'primary'} small api-service-toggle`}
            onClick={onToggle}
            disabled={Boolean(busy)}
            title={toggleActionLabel}
            aria-label={toggleActionLabel}
          >
            {busy === 'api-service-activate' || busy === 'api-service-disable' ? <Loader2 size={14} className="spin" /> : <Power size={14} />}
          </button>
        </div>
      </footer>
    </article>
  );
}

function AddPanel({
  mode,
  onModeChange,
  onClose,
  onAccountsImported,
  setMessage,
}: {
  mode: AddMode;
  onModeChange: (mode: AddMode) => void;
  onClose: () => void;
  onAccountsImported: (accounts: CodexAccount[]) => void;
  setMessage: (message: Message) => void;
}) {
  const [busy, setBusy] = useState(false);
  const [jsonInput, setJsonInput] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [apiBaseUrl, setApiBaseUrl] = useState(OPENAI_BASE_URL);
  const [apiName, setApiName] = useState('');
  const [apiWireApi, setApiWireApi] = useState<CodexProviderWireApi>('responses');
  const [oauthUrl, setOauthUrl] = useState('');
  const [oauthLoginId, setOauthLoginId] = useState('');
  const [oauthCallback, setOauthCallback] = useState('');
  const [oauthCompleting, setOauthCompleting] = useState(false);
  const [copied, setCopied] = useState(false);
  const loginIdRef = useRef('');
  const completingRef = useRef(false);
  const oauthPreparedRef = useRef(false);

  const resetOAuth = useCallback((options?: { keepPrepared?: boolean }) => {
    if (!options?.keepPrepared) {
      oauthPreparedRef.current = false;
    }
    loginIdRef.current = '';
    setOauthLoginId('');
    setOauthUrl('');
    setOauthCallback('');
    setOauthCompleting(false);
    setCopied(false);
  }, []);

  const completeOAuth = useCallback(
    async (loginId: string) => {
      if (!loginId || completingRef.current) return;
      completingRef.current = true;
      setOauthCompleting(true);
      setBusy(true);
      try {
        const account = await api.completeCodexOAuthLogin(loginId);
        onAccountsImported([account]);
        setMessage({ tone: 'success', text: `OAuth 授权成功：${account.email}，点击账号卡片上的“切换”即可启用为 Codex 登录。` });
        resetOAuth();
        onClose();
      } catch (error) {
        setMessage({ tone: 'error', text: `OAuth 完成失败：${stripError(error)}` });
      } finally {
        completingRef.current = false;
        setOauthCompleting(false);
        setBusy(false);
      }
    },
    [onAccountsImported, onClose, resetOAuth, setMessage],
  );

  useEffect(() => {
    let disposed = false;
    let unlistenCompleted: UnlistenFn | undefined;
    let unlistenTimeout: UnlistenFn | undefined;

    listen<{ loginId?: string }>('codex-oauth-login-completed', async (event) => {
      const loginId = event.payload?.loginId || '';
      if (!loginId) return;
      if (loginIdRef.current && loginIdRef.current !== loginId) return;
      await completeOAuth(loginId);
    }).then((unlisten) => {
      if (disposed) unlisten();
      else unlistenCompleted = unlisten;
    });

    listen<{ loginId?: string }>('codex-oauth-login-timeout', (event) => {
      const loginId = event.payload?.loginId || '';
      if (loginIdRef.current && loginId && loginIdRef.current !== loginId) return;
      setBusy(false);
      setOauthCompleting(false);
      setMessage({
        tone: 'warning',
        text: 'OAuth 本地回调等待超时，可以粘贴浏览器最终回调 URL 后继续。',
      });
    }).then((unlisten) => {
      if (disposed) unlisten();
      else unlistenTimeout = unlisten;
    });

    return () => {
      disposed = true;
      unlistenCompleted?.();
      unlistenTimeout?.();
    };
  }, [completeOAuth, setMessage]);

  useEffect(
    () => () => {
      if (loginIdRef.current) {
        api.cancelCodexOAuthLogin(loginIdRef.current).catch(() => {});
      }
    },
    [],
  );

  const startOAuth = useCallback(async () => {
    if (busy) return;
    oauthPreparedRef.current = true;
    setBusy(true);
    setMessage(null);
    try {
      if (loginIdRef.current) {
        await api.cancelCodexOAuthLogin(loginIdRef.current).catch(() => {});
      }
      resetOAuth({ keepPrepared: true });
      setOauthCompleting(false);
      const response = await api.startCodexOAuthLogin();
      loginIdRef.current = response.loginId;
      setOauthLoginId(response.loginId);
      setOauthUrl(response.authUrl);
    } catch (error) {
      setMessage({ tone: 'error', text: `OAuth 准备失败：${stripError(error)}` });
    } finally {
      setBusy(false);
    }
  }, [busy, resetOAuth, setMessage]);

  useEffect(() => {
    if (mode !== 'oauth') return;
    if (oauthPreparedRef.current || oauthUrl || oauthLoginId || busy) return;
    void startOAuth();
  }, [busy, mode, oauthLoginId, oauthUrl, startOAuth]);

  useEffect(() => {
    if (mode === 'oauth') return;
    const loginId = loginIdRef.current;
    if (loginId) {
      api.cancelCodexOAuthLogin(loginId).catch(() => {});
    }
    resetOAuth();
  }, [mode, resetOAuth]);

  const submitOAuthCallback = async () => {
    const loginId = loginIdRef.current || oauthLoginId;
    const callbackUrl = oauthCallback.trim();
    if (!loginId || !callbackUrl) return;
    setBusy(true);
    setMessage(null);
    try {
      await api.submitCodexOAuthCallbackUrl(loginId, callbackUrl);
      await completeOAuth(loginId);
    } catch (error) {
      setMessage({ tone: 'error', text: `提交回调失败：${stripError(error)}` });
    } finally {
      setBusy(false);
    }
  };

  const addApiKey = async () => {
    const key = apiKey.trim();
    const baseUrl = apiBaseUrl.trim() || OPENAI_BASE_URL;
    if (!key) return;
    if (/^https?:\/\//i.test(key)) {
      setMessage({ tone: 'error', text: 'API Key 看起来像 URL，请检查是否填反。' });
      return;
    }
    setBusy(true);
    setMessage(null);
    try {
      const official = isOpenAIBaseUrl(baseUrl);
      const account = await api.addCodexAccountWithApiKey({
        apiKey: key,
        apiBaseUrl: baseUrl,
        apiProviderMode: official ? 'openai_builtin' : 'custom',
        apiProviderId: official ? 'openai_official' : 'custom',
        apiProviderName: official ? 'OpenAI Official' : apiName.trim() || 'Custom API',
        accountName: apiName.trim() || undefined,
        apiWireApi,
      });
      onAccountsImported([account]);
      setMessage({ tone: 'success', text: `已添加 API Key 账号：${account.email}，点击账号卡片上的“切换”即可启用。` });
      onClose();
    } catch (error) {
      setMessage({ tone: 'error', text: `添加失败：${stripError(error)}` });
    } finally {
      setBusy(false);
    }
  };

  const importJson = async () => {
    const content = normalizeJsonImportInput(jsonInput);
    if (!content) return;
    setBusy(true);
    setMessage(null);
    try {
      const accounts = await api.importCodexFromJson(content);
      onAccountsImported(accounts);
      setMessage({ tone: 'success', text: `已导入 ${accounts.length} 个账号，点击账号卡片上的“切换”即可启用为 Codex 登录。` });
      onClose();
    } catch (error) {
      setMessage({ tone: 'error', text: `JSON 导入失败：${stripError(error)}` });
    } finally {
      setBusy(false);
    }
  };

  const copyOAuthUrl = async () => {
    if (!oauthUrl) return;
    await navigator.clipboard.writeText(oauthUrl).catch(() => {});
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1200);
  };

  const openOAuthUrl = async () => {
    if (!oauthUrl) return;
    try {
      await openUrl(oauthUrl);
    } catch {
      await navigator.clipboard.writeText(oauthUrl).catch(() => {});
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1200);
      setMessage({ tone: 'warning', text: '打开浏览器失败，授权链接已复制。' });
    }
  };

  return (
    <aside className="side-panel">
      <header className="panel-head">
        <div>
          <span>添加账号</span>
          <strong>{mode === 'oauth' ? 'OAuth 授权' : mode === 'api-key' ? 'API Key' : 'JSON 导入'}</strong>
        </div>
        <button type="button" onClick={onClose} aria-label="关闭">
          <X size={16} />
        </button>
      </header>

      <div className="tabs">
        <button type="button" className={mode === 'oauth' ? 'active' : ''} onClick={() => onModeChange('oauth')}>OAuth</button>
        <button type="button" className={mode === 'api-key' ? 'active' : ''} onClick={() => onModeChange('api-key')}>API Key</button>
        <button type="button" className={mode === 'json' ? 'active' : ''} onClick={() => onModeChange('json')}>JSON</button>
      </div>

      {mode === 'oauth' ? (
        <div className="form">
          <p>生成 OpenAI OAuth 授权链接，完成授权后账号会保存到 Codex 账号库。</p>
          {oauthUrl ? (
            <>
              <label>
                授权链接
                <div className="input-action">
                  <input value={oauthUrl} readOnly />
                  <button type="button" onClick={copyOAuthUrl}>{copied ? <Check size={14} /> : <Copy size={14} />}</button>
                </div>
              </label>
              <button type="button" className="primary" onClick={openOAuthUrl} disabled={busy || oauthCompleting}>
                {oauthCompleting ? <Loader2 size={15} className="spin" /> : <ExternalLink size={15} />}
                {oauthCompleting ? '正在完成授权' : '打开授权链接'}
              </button>
            </>
          ) : (
            <button type="button" className="primary" onClick={startOAuth} disabled={busy}>
              {busy ? <Loader2 size={15} className="spin" /> : <RefreshCw size={15} />}
              {busy ? '正在生成授权链接' : '生成授权链接'}
            </button>
          )}
          {oauthLoginId ? (
            <label>
              手动回调 URL
              <textarea
                rows={3}
                value={oauthCallback}
                onChange={(event) => setOauthCallback(event.target.value)}
                placeholder="如果本地回调没自动完成，把浏览器最终跳转的 URL 粘贴到这里"
              />
              <button type="button" className="secondary" onClick={submitOAuthCallback} disabled={busy || oauthCompleting || !oauthCallback.trim()}>
                {oauthCompleting ? <Loader2 size={15} className="spin" /> : null}
                {oauthCompleting ? '正在完成授权' : '继续导入'}
              </button>
            </label>
          ) : null}
        </div>
      ) : null}

      {mode === 'api-key' ? (
        <div className="form">
          <label>
            账号名称
            <input value={apiName} onChange={(event) => setApiName(event.target.value)} placeholder="OpenAI 官方 / 自建中转" />
          </label>
          <label>
            Base URL
            <input value={apiBaseUrl} onChange={(event) => setApiBaseUrl(event.target.value)} />
          </label>
          <label>
            API Key
            <input type="password" value={apiKey} onChange={(event) => setApiKey(event.target.value)} placeholder="sk-..." />
          </label>
          <label>
            Wire API
            <select value={apiWireApi} onChange={(event) => setApiWireApi(event.target.value as CodexProviderWireApi)}>
              <option value="responses">Responses</option>
              <option value="chat_completions">Chat Completions</option>
              <option value="anthropic">Anthropic Messages</option>
              <option value="gemini">Gemini</option>
            </select>
          </label>
          <button type="button" className="primary" onClick={addApiKey} disabled={busy || !apiKey.trim()}>
            {busy ? <Loader2 size={15} className="spin" /> : <KeyRound size={15} />}
            添加 API Key 账号
          </button>
        </div>
      ) : null}

      {mode === 'json' ? (
        <div className="form">
          <p>支持粘贴 session JSON、OAuth/Agent Identity auth.json、账号 JSON、Sub2API JSON、accessToken 或 refresh_token；数组内的全部账号会一起导入。</p>
          <textarea
            rows={12}
            value={jsonInput}
            onChange={(event) => setJsonInput(event.target.value)}
            placeholder='{"auth_mode":"agentIdentity","agent_identity":{"agent_runtime_id":"...","agent_private_key":"..."}}'
          />
          <button type="button" className="primary" onClick={importJson} disabled={busy || !jsonInput.trim()}>
            {busy ? <Loader2 size={15} className="spin" /> : <FileJson size={15} />}
            导入 JSON
          </button>
        </div>
      ) : null}
    </aside>
  );
}

function EditModal({
  draft,
  onClose,
  onAccountUpdated,
  setMessage,
}: {
  draft: EditDraft;
  onClose: () => void;
  onAccountUpdated: (account: CodexAccount) => void;
  setMessage: (message: Message) => void;
}) {
  const [form, setForm] = useState(draft);
  const [busy, setBusy] = useState(false);
  const isApi = isApiKeyAccount(draft.account);

  const updateForm = (patch: Partial<EditDraft>) => setForm((current) => ({ ...current, ...patch }));

  const save = async () => {
    setBusy(true);
    setMessage(null);
    try {
      let updatedAccount = draft.account;
      const name = form.name.trim();
      if (name !== (draft.account.account_name || '').trim()) {
        updatedAccount = await api.updateCodexAccountName(draft.account.id, name);
      }
      const note = form.note.trim();
      if (note !== (draft.account.account_note || '').trim()) {
        updatedAccount = await api.updateCodexAccountNote(draft.account.id, note);
      }
      const tags = form.tags.split(',').map((tag) => tag.trim()).filter(Boolean);
      if (tags.join('\n') !== (draft.account.tags ?? []).join('\n')) {
        updatedAccount = await api.updateCodexAccountTags(draft.account.id, tags);
      }
      if (isApi && form.apiKey.trim()) {
        const baseUrl = form.apiBaseUrl.trim() || OPENAI_BASE_URL;
        const official = isOpenAIBaseUrl(baseUrl);
        updatedAccount = await api.updateCodexApiKeyCredentials(draft.account.id, {
          apiKey: form.apiKey.trim(),
          apiBaseUrl: baseUrl,
          apiProviderMode: official ? 'openai_builtin' : 'custom',
          apiProviderId: official ? 'openai_official' : 'custom',
          apiProviderName: official ? 'OpenAI Official' : name || 'Custom API',
          apiWireApi: form.apiWireApi,
        });
      }
      onAccountUpdated(updatedAccount);
      setMessage({ tone: 'success', text: '账号信息已保存。' });
      onClose();
    } catch (error) {
      setMessage({ tone: 'error', text: `保存失败：${stripError(error)}` });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="modal-backdrop">
      <div className="modal">
        <header className="panel-head">
          <div>
            <span>编辑账号</span>
            <strong>{displayName(draft.account)}</strong>
          </div>
          <button type="button" onClick={onClose} disabled={busy} aria-label="关闭">
            <X size={16} />
          </button>
        </header>
        <div className="form">
          <label>
            账号名称
            <input value={form.name} onChange={(event) => updateForm({ name: event.target.value })} />
          </label>
          <label>
            备注
            <textarea rows={3} value={form.note} onChange={(event) => updateForm({ note: event.target.value })} />
          </label>
          <label>
            标签
            <input value={form.tags} onChange={(event) => updateForm({ tags: event.target.value })} placeholder="多个标签用英文逗号分隔" />
          </label>
          {isApi ? (
            <div className="api-edit-block">
              <strong>API Key 凭据</strong>
              <label>
                Base URL
                <input value={form.apiBaseUrl} onChange={(event) => updateForm({ apiBaseUrl: event.target.value })} />
              </label>
              <label>
                新 API Key
                <input type="password" value={form.apiKey} onChange={(event) => updateForm({ apiKey: event.target.value })} placeholder="留空则不修改" />
              </label>
              <label>
                Wire API
                <select value={form.apiWireApi} onChange={(event) => updateForm({ apiWireApi: event.target.value as CodexProviderWireApi })}>
                  <option value="responses">Responses</option>
                  <option value="chat_completions">Chat Completions</option>
                  <option value="anthropic">Anthropic Messages</option>
                  <option value="gemini">Gemini</option>
                </select>
              </label>
            </div>
          ) : null}
        </div>
        <footer className="modal-foot">
          <button type="button" className="secondary" onClick={onClose} disabled={busy}>取消</button>
          <button type="button" className="primary" onClick={save} disabled={busy}>
            {busy ? <Loader2 size={15} className="spin" /> : <Check size={15} />}
            保存
          </button>
        </footer>
      </div>
    </div>
  );
}

function CloudImportModal({
  preview,
  importing,
  progress,
  onClose,
  onConfirm,
}: {
  preview: CodexBatchImportPreview;
  importing: boolean;
  progress: CloudImportProgress;
  onClose: () => void;
  onConfirm: () => void;
}) {
  const selectableItems = preview.items.filter((item) => item.selectable);
  const validCount = selectableItems.length;
  const existingCount = selectableItems.filter((item) => item.existing).length;
  const invalidCount = preview.items.filter((item) => !item.selectable && !item.duplicate).length;
  const progressTotal = progress?.total || validCount;
  const progressImported = progress?.imported ?? 0;
  const progressPercent = progressTotal > 0 ? Math.min(100, Math.round((progressImported / progressTotal) * 100)) : 0;

  return (
    <div className="modal-backdrop">
      <div className="modal cloud-import-modal">
        <header className="panel-head">
          <div>
            <span>从云端导入</span>
            <strong>识别到 {validCount} 个账号</strong>
          </div>
          <button type="button" onClick={onClose} aria-label="关闭">
            <X size={16} />
          </button>
        </header>

        <div className="api-accounts-count">
          <span>识别到 {validCount} 个账号</span>
          {existingCount > 0 ? <span>已存在 {existingCount} 个</span> : null}
          {invalidCount > 0 ? <span>未识别 {invalidCount} 个</span> : null}
        </div>

        {importing ? (
          <div className="cloud-import-summary">
            <strong>{progressImported}/{progressTotal}</strong>
            <span>正在处理并导入账号。</span>
            <div className="cloud-import-progress-track" aria-label="从云端导入进度">
              <span style={{ width: `${progressPercent}%` }} />
            </div>
            <small>
              已导入 {progressImported}/{progressTotal}
            </small>
          </div>
        ) : (
          <div className="cloud-import-summary">
            <strong>{validCount}</strong>
            <span>确认后会导入全部已识别账号。</span>
          </div>
        )}

        <footer className="modal-foot">
          <button type="button" className="secondary" onClick={onClose}>取消</button>
          <button type="button" className="primary" onClick={onConfirm} disabled={importing || validCount === 0}>
            {importing ? <Loader2 size={15} className="spin" /> : <Upload size={15} />}
            从云端导入
          </button>
        </footer>
      </div>
    </div>
  );
}

function ApiServiceAccountsModal({
  accounts,
  memberIds,
  restrictFreeInitial,
  busy,
  onClose,
  onSave,
  onRemove,
}: {
  accounts: CodexAccount[];
  memberIds: string[];
  restrictFreeInitial: boolean;
  busy: BusyAction | null;
  onClose: () => void;
  onSave: (ids: string[], restrictFree: boolean) => Promise<boolean>;
  onRemove: (account: CodexAccount) => Promise<void>;
}) {
  const [selectedIds, setSelectedIds] = useState<string[]>(memberIds);
  const [restrictFree, setRestrictFree] = useState(restrictFreeInitial);
  const [query, setQuery] = useState('');
  const debouncedQuery = useDebouncedValue(query, 140);
  const memberIdsKey = memberIds.join('\n');
  const accountById = useMemo(() => new Map(accounts.map((account) => [account.id, account])), [accounts]);
  const accountSearchIndex = useMemo(
    () => new Map(accounts.map((account) => [account.id, searchText(account)])),
    [accounts],
  );
  const selectedSet = useMemo(() => new Set(selectedIds), [selectedIds]);
  const savedSet = useMemo(() => new Set(memberIds), [memberIds]);
  const filteredAccounts = useMemo(() => {
    const text = debouncedQuery.trim().toLowerCase();
    return accounts.filter((account) => !text || (accountSearchIndex.get(account.id) ?? '').includes(text));
  }, [accountSearchIndex, accounts, debouncedQuery]);
  const memberPagination = usePagination({
    items: filteredAccounts,
    storageKey: API_SERVICE_MEMBER_PAGE_SIZE_STORAGE_KEY,
    pageSizeOptions: API_SERVICE_MEMBER_PAGE_SIZE_OPTIONS,
    defaultPageSize: API_SERVICE_MEMBER_PAGE_SIZE_OPTIONS[0],
  });
  const paginatedAccounts = memberPagination.pageItems;
  const selectableFilteredIds = useMemo(
    () =>
      filteredAccounts
        .filter((account) => !restrictFree || !isFreeAccount(account))
        .map((account) => account.id),
    [filteredAccounts, restrictFree],
  );
  const allFilteredSelected =
    selectableFilteredIds.length > 0 && selectableFilteredIds.every((id) => selectedSet.has(id));
  const selectableIds = selectedIds.filter((id) => {
    const account = accountById.get(id);
    return account && (!restrictFree || !isFreeAccount(account));
  });

  useEffect(() => {
    setSelectedIds(memberIds);
  }, [memberIdsKey]);

  useEffect(() => {
    setRestrictFree(restrictFreeInitial);
  }, [restrictFreeInitial]);

  useEffect(() => {
    memberPagination.setCurrentPage(1);
  }, [debouncedQuery, memberPagination.setCurrentPage, restrictFree]);

  const toggleSelected = (account: CodexAccount) => {
    if (restrictFree && isFreeAccount(account)) return;
    setSelectedIds((current) =>
      current.includes(account.id)
        ? current.filter((id) => id !== account.id)
        : [...current, account.id],
    );
  };

  const toggleAllFiltered = () => {
    const targetIds = new Set(selectableFilteredIds);
    if (targetIds.size === 0) return;
    setSelectedIds((current) => {
      const currentSet = new Set(current);
      const shouldClear = selectableFilteredIds.every((id) => currentSet.has(id));
      if (shouldClear) {
        return current.filter((id) => !targetIds.has(id));
      }
      for (const id of selectableFilteredIds) {
        currentSet.add(id);
      }
      return Array.from(currentSet);
    });
  };

  const updateRestrictFree = (next: boolean) => {
    setRestrictFree(next);
    if (next) {
      setSelectedIds((current) =>
        current.filter((id) => {
          const account = accountById.get(id);
          return !account || !isFreeAccount(account);
        }),
      );
    }
  };

  const save = async () => {
    const saved = await onSave(selectableIds, restrictFree);
    if (saved) onClose();
  };

  const removeSaved = async (account: CodexAccount) => {
    setSelectedIds((current) => current.filter((id) => id !== account.id));
    await onRemove(account);
  };

  return (
    <div className="modal-backdrop">
      <div className="modal api-accounts-modal">
        <header className="panel-head">
          <div>
            <span>API 服务</span>
            <strong>服务账号</strong>
          </div>
          <button type="button" onClick={onClose} disabled={Boolean(busy)} aria-label="关闭">
            <X size={16} />
          </button>
        </header>

        <div className="api-accounts-tools">
          <div className="search">
            <Search size={16} />
            <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="搜索服务账号" />
          </div>
          <div className="api-accounts-actions">
            <button
              type="button"
              className="secondary small"
              onClick={toggleAllFiltered}
              disabled={Boolean(busy) || selectableFilteredIds.length === 0}
            >
              {allFilteredSelected ? <X size={14} /> : <Check size={14} />}
              {allFilteredSelected ? '取消全选' : '全选'}
            </button>
            <label>
              <input
                type="checkbox"
                checked={restrictFree}
                onChange={(event) => updateRestrictFree(event.target.checked)}
              />
              排除 FREE
            </label>
          </div>
        </div>

        <div className="api-accounts-count">
          <span>已选择 {selectableIds.length} 个</span>
          <span>已保存 {memberIds.length} 个</span>
          <span>匹配 {filteredAccounts.length} / {accounts.length}</span>
        </div>

        <div className="member-list api-accounts-list">
          {paginatedAccounts.map((account) => {
            const disabled = restrictFree && isFreeAccount(account);
            const removing = busy === `api-service-remove:${account.id}`;
            return (
              <label className={`member-item${savedSet.has(account.id) ? ' saved' : ''}${disabled ? ' disabled' : ''}`} key={account.id}>
                <input
                  type="checkbox"
                  checked={selectedSet.has(account.id) && !disabled}
                  disabled={Boolean(busy) || disabled}
                  onChange={() => toggleSelected(account)}
                />
                <span title={displayName(account)}>{displayName(account)}</span>
                <em>{planLabel(account)}</em>
                {savedSet.has(account.id) ? (
                  <button type="button" onClick={(event) => { event.preventDefault(); void removeSaved(account); }} disabled={Boolean(busy)}>
                    {removing ? <Loader2 size={13} className="spin" /> : <X size={13} />}
                  </button>
                ) : null}
              </label>
            );
          })}
        </div>
        <PaginationControls
          totalItems={memberPagination.totalItems}
          currentPage={memberPagination.currentPage}
          totalPages={memberPagination.totalPages}
          pageSize={memberPagination.pageSize}
          pageSizeOptions={memberPagination.pageSizeOptions}
          rangeStart={memberPagination.rangeStart}
          rangeEnd={memberPagination.rangeEnd}
          canGoPrevious={memberPagination.canGoPrevious}
          canGoNext={memberPagination.canGoNext}
          onPageSizeChange={memberPagination.setPageSize}
          onPreviousPage={memberPagination.goToPreviousPage}
          onNextPage={memberPagination.goToNextPage}
        />

        <footer className="modal-foot">
          <button type="button" className="secondary" onClick={onClose} disabled={Boolean(busy)}>取消</button>
          <button type="button" className="primary" onClick={save} disabled={Boolean(busy)}>
            {busy === 'api-service-save' ? <Loader2 size={15} className="spin" /> : <Check size={15} />}
            保存集合
          </button>
        </footer>
      </div>
    </div>
  );
}

function ApiServicePanel({
  accounts,
  state,
  externalConfig,
  apiMode,
  selectedProxyProfileId,
  busy,
  cardVisible,
  appSpeed,
  onClose,
  onApiModeChange,
  onCardVisibleChange,
  onSpeedChange,
  onExternalConfigChange,
  onSelectedProxyProfileChange,
  onCurrentAccountChange,
  onOpenAccounts,
  onToggle,
  setLocalAccessState,
  runBusy,
  setMessage,
}: {
  accounts: CodexAccount[];
  state: CodexLocalAccessState | null;
  externalConfig: CodexExternalApiServiceConfig | null;
  apiMode: ApiServiceAddressMode;
  selectedProxyProfileId: string;
  busy: BusyAction | null;
  cardVisible: boolean;
  appSpeed: CodexAppSpeed;
  onClose: () => void;
  onApiModeChange: (mode: ApiServiceAddressMode) => void;
  onCardVisibleChange: (visible: boolean) => void;
  onSpeedChange: (speed: CodexAppSpeed) => void;
  onExternalConfigChange: (config: CodexExternalApiServiceConfig | null) => void;
  onSelectedProxyProfileChange: (profileId: string) => void;
  onCurrentAccountChange: (account: CodexAccount | null) => void;
  onOpenAccounts: () => void;
  onToggle: () => void;
  setLocalAccessState: (state: CodexLocalAccessState) => void;
  runBusy: (action: BusyAction, task: () => Promise<void>) => Promise<void>;
  setMessage: (message: Message) => void;
}) {
  const collection = state?.collection ?? null;
  const [portText, setPortText] = useState('');
  const [externalBaseUrl, setExternalBaseUrl] = useState('');
  const [externalApiKey, setExternalApiKey] = useState('');
  const [externalProfileName, setExternalProfileName] = useState('');
  const [externalProviderName, setExternalProviderName] = useState('');
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [visibleProxyKeyIds, setVisibleProxyKeyIds] = useState<string[]>([]);
  const baseUrl = localAccessBaseUrl(state);
  const apiKey = localAccessApiKey(state);
  const memberIds = collection?.accountIds ?? [];
  const externalActive = Boolean(externalConfig?.active);
  const inExternalMode = apiMode === 'external-api';
  const activeMode = getActiveApiServiceMode(state, externalConfig);
  const targetIsActive = isApiServiceTargetActive(
    state,
    externalConfig,
    apiMode,
    selectedProxyProfileId,
  );
  const pendingSwitch = Boolean(activeMode && !targetIsActive);
  const cloudProxyConfig = isCloudProxyApiConfig(externalConfig);
  const savedProxyConfig = hasProxyApiConfig(externalConfig);
  const proxyProfiles = externalConfig?.profiles ?? [];
  const activeProxyProfile = proxyProfiles.find((profile) => profile.id === externalConfig?.profileId) ?? null;
  const memberNames = memberIds
    .map((id) => accounts.find((account) => account.id === id))
    .filter(Boolean)
    .map((account) => displayName(account as CodexAccount));
  const localServiceEnabled = Boolean(collection?.enabled || state?.running);
  const toggleStopsService = Boolean(activeMode && targetIsActive);
  const statusText = pendingSwitch
    ? '待切换'
    : inExternalMode
    ? externalActive
      ? '代理已启用'
      : savedProxyConfig
      ? '代理已保存'
      : '代理未配置'
    : state?.running
    ? '运行中'
    : collection?.enabled
    ? '待恢复'
    : '未启用';
  const statusTone = pendingSwitch
    ? 'warn'
    : inExternalMode
    ? externalActive
      ? 'ok'
      : savedProxyConfig
      ? 'warn'
      : ''
    : state?.running
    ? 'ok'
    : collection?.enabled
    ? 'warn'
    : '';
  const summaryMiddleLabel = inExternalMode ? '上游' : '成员';
  const summaryMiddleValue = inExternalMode ? proxyApiConfigTitle(externalConfig) : String(memberIds.length);
  const summaryRightLabel = inExternalMode ? '模型' : '统计';
  const summaryRightValue = inExternalMode
    ? proxyModelFamilyLabel(externalConfig?.models, externalConfig?.defaultModel)
    : formatLocalAccessUsage(state);
  const localActionLabel = toggleStopsService
    ? inExternalMode
      ? '停用代理'
      : '停用服务'
    : pendingSwitch
    ? `切换到 ${apiServiceModeLabel(apiMode)}`
    : inExternalMode
    ? savedProxyConfig
      ? '启动代理'
      : '读取云端'
    : localServiceEnabled
    ? '启动并切换'
    : '启动并切换';

  useEffect(() => {
    setPortText(collection?.port ? String(collection.port) : '');
    setExternalBaseUrl(cloudProxyConfig ? '' : externalConfig?.baseUrl ?? '');
    setExternalProfileName(cloudProxyConfig ? '' : activeProxyProfile?.name?.trim() || '');
    setExternalProviderName(externalConfig?.providerName?.trim() || '');
    setExternalApiKey('');
  }, [
    collection?.port,
    collection?.updatedAt,
    externalConfig?.baseUrl,
    externalConfig?.profileId,
    externalConfig?.providerName,
    externalConfig?.source,
    externalConfig?.updatedAt,
    cloudProxyConfig,
    activeProxyProfile?.name,
  ]);

  const copyValue = async (field: string, value: string) => {
    if (!value) return;
    await navigator.clipboard.writeText(value).catch(() => {});
    setCopiedField(field);
    window.setTimeout(() => setCopiedField(null), 1200);
  };

  const rotateKey = async () => {
    if (!window.confirm('重置后当前 API 服务密钥会立即失效，确认继续？')) return;
    await runBusy('api-service-key', async () => {
      const next = await api.rotateCodexLocalAccessApiKey();
      setLocalAccessState(next);
      setMessage({ tone: 'success', text: 'API 服务密钥已重置。' });
    }).catch((error) => setMessage({ tone: 'error', text: `重置 API 服务密钥失败：${stripError(error)}` }));
  };

  const updatePort = async () => {
    const port = Number(portText);
    if (!Number.isInteger(port) || port < 1 || port > 65535) {
      setMessage({ tone: 'warning', text: '端口需为 1-65535 的整数。' });
      return;
    }
    await runBusy('api-service-port', async () => {
      const next = await api.updateCodexLocalAccessPort(port);
      setLocalAccessState(next);
      setMessage({ tone: 'success', text: 'API 服务端口已更新。' });
    }).catch((error) => setMessage({ tone: 'error', text: `更新端口失败：${stripError(error)}` }));
  };

  const updateAddressMode = (nextMode: ApiServiceAddressMode) => {
    onApiModeChange(nextMode);
  };

  const saveExternalApiService = async () => {
    const normalizedBaseUrl = externalBaseUrl.trim() ? normalizeHttpBaseUrl(externalBaseUrl) : '';
    const upstreamApiKey = externalApiKey.trim();
    const profileName = externalProfileName.trim();
    if (externalBaseUrl.trim() && !normalizedBaseUrl) {
      setMessage({ tone: 'warning', text: '代理 API 服务地址需为完整的 http:// 或 https:// Base URL。' });
      return;
    }
    if (!normalizedBaseUrl && upstreamApiKey && !externalConfig?.baseUrl) {
      setMessage({ tone: 'warning', text: '只填写 API Key 时需要已有代理 Base URL，或同时填写 Base URL。' });
      return;
    }
    if (normalizedBaseUrl && !upstreamApiKey && cloudProxyConfig) {
      setMessage({ tone: 'warning', text: '从云端默认配置改为手动代理时，请同时填写代理 API Key。' });
      return;
    }
    if (!normalizedBaseUrl && !upstreamApiKey && externalConfig?.baseUrl && !externalConfig?.hasApiKey) {
      setMessage({ tone: 'warning', text: '请输入代理 API 服务的 API Key。' });
      return;
    }
    if (upstreamApiKey && /^https?:\/\//i.test(upstreamApiKey)) {
      setMessage({ tone: 'error', text: 'API Key 看起来像 URL，请检查是否填反。' });
      return;
    }
    if (upstreamApiKey && normalizeUrl(upstreamApiKey) === normalizedBaseUrl) {
      setMessage({ tone: 'error', text: 'API Key 不能与 Base URL 相同。' });
      return;
    }
    if ((normalizedBaseUrl || upstreamApiKey) && !profileName) {
      setMessage({ tone: 'warning', text: '请填写配置名称，便于区分相同地址下的不同 API Key。' });
      return;
    }

    await runBusy('api-service-external', async () => {
      const result = await api.activateCodexExternalApiService({
        profileId: null,
        profileName: profileName || null,
        apiKey: upstreamApiKey || null,
        apiBaseUrl: normalizedBaseUrl,
        apiProviderName: externalProviderName.trim() || undefined,
        refreshCloudDefault: !normalizedBaseUrl && !upstreamApiKey,
      });
      setLocalAccessState(result.state);
      onExternalConfigChange(result.config);
      onSelectedProxyProfileChange(result.config.profileId ?? '');
      onCurrentAccountChange(null);
      setExternalApiKey('');
      onApiModeChange('external-api');
      let restartError = '';
      try {
        await api.restartCodexDefaultApp();
      } catch (error) {
        restartError = stripError(error);
      }
      if (restartError) {
        setMessage({ tone: 'warning', text: `已切换到代理 API 服务，但自动重启失败：${restartError}。请手动重启 Codex。` });
      } else {
        setMessage({ tone: 'success', text: normalizedBaseUrl || upstreamApiKey ? '已切换到代理 API 服务。' : '已从云端读取配置并切换到代理 API 服务。' });
      }
    }).catch((error) => setMessage({ tone: 'error', text: `保存代理 API 服务失败：${stripError(error)}` }));
  };

  const useExternalApiServiceProfile = async (profile: CodexExternalApiServiceProfileConfig) => {
    await runBusy('api-service-external', async () => {
      const result = await api.activateCodexExternalApiService({
        profileId: profile.id,
        profileName: profile.name || null,
        apiKey: null,
        apiBaseUrl: '',
        apiProviderName: profile.providerName ?? undefined,
        refreshCloudDefault: false,
      });
      setLocalAccessState(result.state);
      onExternalConfigChange(result.config);
      onSelectedProxyProfileChange(result.config.profileId ?? '');
      onCurrentAccountChange(null);
      setExternalApiKey('');
      setExternalBaseUrl(profile.baseUrl);
      setExternalProfileName(profile.name || '');
      setExternalProviderName(profile.providerName?.trim() || '');
      onApiModeChange('external-api');
      let restartError = '';
      try {
        await api.restartCodexDefaultApp();
      } catch (error) {
        restartError = stripError(error);
      }
      if (restartError) {
        setMessage({ tone: 'warning', text: `已切换到代理 API 服务，但自动重启失败：${restartError}。请手动重启 Codex。` });
      } else {
        setMessage({ tone: 'success', text: '已切换到保存的代理 API 服务。' });
      }
    }).catch((error) => setMessage({ tone: 'error', text: `切换代理 API 服务失败：${stripError(error)}` }));
  };

  const deleteExternalApiServiceProfile = async (profile: CodexExternalApiServiceProfileConfig) => {
    if (!window.confirm(`确定删除代理配置 ${proxyProfileTitle(profile)}？`)) return;
    await runBusy('api-service-external', async () => {
      const result = await api.deleteCodexExternalApiServiceProfile(profile.id);
      setLocalAccessState(result.state);
      onExternalConfigChange(result.config);
      onSelectedProxyProfileChange(result.config.profileId ?? '');
      setVisibleProxyKeyIds((current) => current.filter((id) => id !== profile.id));
      if (result.config.active) {
        setMessage({ tone: 'success', text: '代理 API 服务配置已删除。' });
        return;
      }
      setMessage({ tone: 'success', text: '代理 API 服务配置已删除，当前代理已停用。' });
    }).catch((error) => setMessage({ tone: 'error', text: `删除代理配置失败：${stripError(error)}` }));
  };

  const toggleProxyKeyVisible = (profileId: string) => {
    setVisibleProxyKeyIds((current) =>
      current.includes(profileId)
        ? current.filter((id) => id !== profileId)
        : [...current, profileId],
    );
  };

  const killPort = async () => {
    await runBusy('api-service-port', async () => {
      const result = await api.killCodexLocalAccessPort();
      setLocalAccessState(result.state);
      setMessage({ tone: 'success', text: `API 服务端口已清理：${result.killedCount} 个进程。` });
    }).catch((error) => setMessage({ tone: 'error', text: `清理端口失败：${stripError(error)}` }));
  };

  return (
    <aside className="side-panel api-service-panel">
      <header className="panel-head">
        <div>
          <span>API 服务</span>
          <strong>{inExternalMode ? '代理 API 服务' : '本地 API 服务'}</strong>
        </div>
        <button type="button" onClick={onClose} aria-label="关闭">
          <X size={16} />
        </button>
      </header>

      <div className="api-service-scroll">
        <div className="api-service-summary">
          <div>
            <span>状态</span>
            <strong className={statusTone}>{statusText}</strong>
          </div>
          <div>
            <span>{summaryMiddleLabel}</span>
            <strong>{summaryMiddleValue}</strong>
          </div>
          <div>
            <span>{summaryRightLabel}</span>
            <strong>{summaryRightValue}</strong>
          </div>
        </div>

        {!inExternalMode && state?.lastError ? (
          <div className="inline-alert danger">
            <AlertTriangle size={15} />
            <span>{state.lastError}</span>
          </div>
        ) : null}

        <label className="api-service-card-visibility">
          <div>
            <span>前端卡片</span>
            <strong>{cardVisible ? '显示' : '隐藏'}</strong>
          </div>
          <input
            type="checkbox"
            checked={cardVisible}
            onChange={(event) => onCardVisibleChange(event.target.checked)}
          />
        </label>

        <div className="api-service-speed-card">
          <div>
            <span>服务速度</span>
            <strong>{appSpeed === 'fast' ? '快速' : '标准'}</strong>
          </div>
          <SpeedSelect
            value={appSpeed}
            busy={busy === 'api-service-speed'}
            disabled={Boolean(busy)}
            onChange={onSpeedChange}
          />
        </div>

        <div className="api-service-config">
          <label>
            API 模式
            <select value={apiMode} onChange={(event) => updateAddressMode(event.target.value as ApiServiceAddressMode)} disabled={Boolean(busy)}>
              {API_SERVICE_MODE_OPTIONS.map((option) => (
                <option key={option.value} value={option.value}>{option.label}</option>
              ))}
            </select>
          </label>
          {inExternalMode ? (
            <div className="api-service-external-config">
              <label>
                配置名称
                <input
                  value={externalProfileName}
                  onChange={(event) => setExternalProfileName(event.target.value)}
                  placeholder="例如：Grok 主线路"
                  maxLength={80}
                />
              </label>
              <label>
                代理 Base URL
                <input
                  value={externalBaseUrl}
                  onChange={(event) => setExternalBaseUrl(event.target.value)}
                  placeholder={cloudProxyConfig ? '当前使用云端默认配置' : '留空则从云端读取'}
                />
              </label>
              <label>
                代理 API Key
                <input
                  type="password"
                  value={externalApiKey}
                  onChange={(event) => setExternalApiKey(event.target.value)}
                  placeholder={cloudProxyConfig ? '当前使用云端默认 Key' : externalConfig?.hasApiKey ? '留空沿用已保存 Key' : '留空则从云端读取'}
                />
              </label>
              <button
                type="button"
                className="primary"
                onClick={saveExternalApiService}
                disabled={Boolean(busy)}
              >
                {busy === 'api-service-external' ? <Loader2 size={15} className="spin" /> : <Server size={15} />}
                保存并切换
              </button>
              {proxyProfiles.length > 0 ? (
                <div className="proxy-profile-list">
                  <div className="proxy-profile-list-head">
                    <span>保存的代理配置</span>
                    <strong>{proxyProfiles.length}</strong>
                  </div>
                  {proxyProfiles.map((profile) => {
                    const keyVisible = visibleProxyKeyIds.includes(profile.id);
                    return (
                      <div key={profile.id} className={`proxy-profile-card${profile.active ? ' active' : ''}`}>
                        <div className="proxy-profile-main">
                          <div>
                            <strong>{proxyProfileTitle(profile)}</strong>
                            <span title={profile.baseUrl}>{profile.baseUrl}</span>
                            {profile.defaultModel ? (
                              <span title={profile.defaultModel}>
                                模型：{proxyModelFamilyLabel(profile.models, profile.defaultModel)}
                              </span>
                            ) : null}
                          </div>
                          {profile.active ? <em>当前</em> : null}
                        </div>
                        <div className="proxy-profile-key">
                          <input
                            value={keyVisible ? profile.apiKey || '' : maskProxyApiKey(profile.apiKey)}
                            readOnly
                            type={keyVisible ? 'text' : 'password'}
                          />
                          <button
                            type="button"
                            className="secondary small"
                            onClick={() => toggleProxyKeyVisible(profile.id)}
                            disabled={!profile.apiKey}
                            title={keyVisible ? '隐藏 Key' : '查看 Key'}
                            aria-label={keyVisible ? '隐藏 Key' : '查看 Key'}
                          >
                            {keyVisible ? <EyeOff size={14} /> : <Eye size={14} />}
                          </button>
                        </div>
                        <div className="proxy-profile-actions">
                          <button type="button" className="secondary small" onClick={() => useExternalApiServiceProfile(profile)} disabled={Boolean(busy)}>
                            使用
                          </button>
                          <button type="button" className="danger-btn small" onClick={() => deleteExternalApiServiceProfile(profile)} disabled={Boolean(busy)}>
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <p className="note">手动填写代理 Base URL 和 Key 并保存后，会出现在这里，方便下次切换。</p>
              )}
            </div>
          ) : (
            <>
              <label>
                Base URL
                <div className="input-action">
                  <input value={baseUrl || '保存账号集合后生成'} readOnly />
                  <button type="button" onClick={() => copyValue('baseUrl', baseUrl)} disabled={!baseUrl}>
                    {copiedField === 'baseUrl' ? <Check size={14} /> : <Copy size={14} />}
                  </button>
                </div>
              </label>
              <label>
                API Key
                <div className="input-action">
                  <input value={apiKey || '保存账号集合后生成'} readOnly type={apiKey ? 'password' : 'text'} />
                  <button type="button" onClick={() => copyValue('apiKey', apiKey)} disabled={!apiKey}>
                    {copiedField === 'apiKey' ? <Check size={14} /> : <Copy size={14} />}
                  </button>
                </div>
              </label>
              <div className="api-service-row">
                <label>
                  服务端口
                  <input value={portText} onChange={(event) => setPortText(event.target.value)} placeholder="14998" />
                </label>
                <button type="button" className="secondary" onClick={updatePort} disabled={Boolean(busy) || !collection}>
                  {busy === 'api-service-port' ? <Loader2 size={15} className="spin" /> : <Settings size={15} />}
                  保存
                </button>
              </div>
            </>
          )}
        </div>

        {!inExternalMode ? (
          <>
            <div className="api-service-members-card">
              <div>
                <span>服务账号</span>
                <strong>{memberNames.length > 0 ? `${memberNames.length} 个账号` : '未选择账号'}</strong>
              </div>
              <button type="button" className="secondary small" onClick={onOpenAccounts} disabled={Boolean(busy)}>
                <UserCheck size={14} />
                管理
              </button>
            </div>

            {memberNames.length > 0 ? (
              <div className="api-service-member-chips">
                {memberNames.slice(0, 8).map((name) => (
                  <span key={name} title={name}>{name}</span>
                ))}
                {memberNames.length > 8 ? <span>+{memberNames.length - 8}</span> : null}
              </div>
            ) : (
              <p className="note">先管理服务账号并保存集合，再启动 API 服务。</p>
            )}
          </>
        ) : null}
      </div>

      {!inExternalMode || externalActive ? (
        <div className="api-service-actions">
          <button type="button" className={toggleStopsService ? 'danger-btn' : 'primary'} onClick={onToggle} disabled={Boolean(busy)}>
            {busy === 'api-service-activate' || busy === 'api-service-disable' ? <Loader2 size={15} className="spin" /> : <Power size={15} />}
            {localActionLabel}
          </button>
          {!inExternalMode ? (
            <>
              <button type="button" className="secondary" onClick={rotateKey} disabled={Boolean(busy) || !collection}>
                {busy === 'api-service-key' ? <Loader2 size={15} className="spin" /> : <KeyRound size={15} />}
                重置 Key
              </button>
              <button type="button" className="secondary" onClick={killPort} disabled={Boolean(busy) || !collection}>
                清理端口
              </button>
            </>
          ) : null}
        </div>
      ) : null}

    </aside>
  );
}

export default function App() {
  const [accounts, setAccounts] = useState<CodexAccount[]>([]);
  const [currentAccount, setCurrentAccount] = useState<CodexAccount | null>(null);
  const [busy, setBusy] = useState<BusyAction | null>('initial');
  const [message, setMessage] = useState<Message>(null);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<FilterMode>('all');
  const [addMode, setAddMode] = useState<AddMode | null>(null);
  const [editing, setEditing] = useState<EditDraft | null>(null);
  const [exportText, setExportText] = useState('');
  const [exportTitle, setExportTitle] = useState('');
  const [exportFileNameBase, setExportFileNameBase] = useState('codex_accounts');
  const [exportFormat, setExportFormat] = useState<CodexExportFormat>(readExportFormat);
  const [exportOutputMode, setExportOutputMode] = useState<ExportOutputMode>(readExportOutputMode);
  const [exportTimestamp, setExportTimestamp] = useState('');
  const [exportAccountCount, setExportAccountCount] = useState(0);
  const [exportCopied, setExportCopied] = useState(false);
  const [exportSaving, setExportSaving] = useState(false);
  const [exportJsonHidden, setExportJsonHidden] = useState(true);
  const [exportSavedPath, setExportSavedPath] = useState('');
  const [exportSavedPathIsDirectory, setExportSavedPathIsDirectory] = useState(false);
  const [exportPathCopied, setExportPathCopied] = useState(false);
  const [exportSavingDocumentId, setExportSavingDocumentId] = useState<string | null>(null);
  const [cloudImportPreview, setCloudImportPreview] = useState<CodexBatchImportPreview | null>(null);
  const [apiServiceOpen, setApiServiceOpen] = useState(false);
  const [apiServiceAccountsOpen, setApiServiceAccountsOpen] = useState(false);
  const [localAccessState, setLocalAccessState] = useState<CodexLocalAccessState | null>(null);
  const [externalApiServiceConfig, setExternalApiServiceConfig] = useState<CodexExternalApiServiceConfig | null>(null);
  const [initialApiServiceAddressMode] = useState(() => readApiServiceAddressMode());
  const [apiServiceAddressMode, setApiServiceAddressMode] = useState<ApiServiceAddressMode>(
    initialApiServiceAddressMode ?? 'localhost',
  );
  const [selectedProxyProfileId, setSelectedProxyProfileId] = useState('');
  const [apiServiceAppSpeed, setApiServiceAppSpeed] = useState<CodexAppSpeed>('standard');
  const [apiServiceCardVisible, setApiServiceCardVisible] = useState(readApiServiceCardVisible);
  const [selectedAccountIds, setSelectedAccountIds] = useState<string[]>([]);
  const [maskedAccountIds, setMaskedAccountIds] = useState<string[]>([]);
  const [apiServiceCardSelected, setApiServiceCardSelected] = useState(false);
  const [apiServiceCardMasked, setApiServiceCardMasked] = useState(false);
  const [autoRefreshMinutes, setAutoRefreshMinutes] = useState<AutoRefreshMinutes>(() =>
    parseAutoRefreshMinutes(localStorage.getItem(AUTO_REFRESH_STORAGE_KEY)),
  );
  const [autoRefreshRunning, setAutoRefreshRunning] = useState(false);
  const [autoRefreshStatus, setAutoRefreshStatus] = useState('等待下一次自动刷新');
  const [autoRefreshStatusTone, setAutoRefreshStatusTone] = useState<'normal' | 'error'>('normal');
  const [fileImportProgress, setFileImportProgress] = useState<FileImportProgress>(null);
  const [serverUpdate, setServerUpdate] = useState<ServerUpdateState>(DEFAULT_SERVER_UPDATE_STATE);
  const [cloudImportSubmittingSessionId, setCloudImportSubmittingSessionId] = useState<string | null>(null);
  const [cloudImportProgress, setCloudImportProgress] = useState<CloudImportProgress>(null);
  const busyRef = useRef<BusyAction | null>('initial');
  const accountsCountRef = useRef(0);
  const autoRefreshRunningRef = useRef(false);
  const modalOpenRef = useRef(false);
  const manualOperationVersionRef = useRef(0);
  const cloudImportCancelledSessionsRef = useRef(new Set<string>());
  const cloudImportSubmittingSessionIdRef = useRef<string | null>(null);
  const apiServiceAddressModeTouchedRef = useRef(Boolean(initialApiServiceAddressMode));

  const reload = useCallback(async () => {
    const [nextAccounts, nextCurrent] = await Promise.all([
      api.listCodexAccounts(),
      api.getCurrentCodexAccount(),
    ]);
    setAccounts(nextAccounts);
    setCurrentAccount(nextCurrent);
  }, []);

  const reloadLocalAccess = useCallback(async () => {
    const nextState = await api.getCodexLocalAccessStateLight();
    setLocalAccessState(nextState);
    return nextState;
  }, []);

  const reloadApiServiceAppSpeed = useCallback(async () => {
    const config = await api.getCodexApiServiceAppSpeedConfig();
    setApiServiceAppSpeed(config.speed);
    return config;
  }, []);

  const reloadExternalApiServiceConfig = useCallback(async () => {
    const config = await api.getCodexExternalApiServiceConfig();
    setExternalApiServiceConfig(config);
    return config;
  }, []);

  const changeApiServiceAddressMode = useCallback((mode: ApiServiceAddressMode) => {
    apiServiceAddressModeTouchedRef.current = true;
    saveApiServiceAddressMode(mode);
    setApiServiceAddressMode(mode);
  }, []);

  const changeSelectedProxyProfile = useCallback((profileId: string) => {
    setSelectedProxyProfileId(profileId);
    setMessage({ tone: 'success', text: profileId ? '代理配置已选择，点击启动后切换。' : '代理配置已切回云端默认。' });
  }, []);

  const upsertAccounts = useCallback((incoming: CodexAccount[]) => {
    if (incoming.length === 0) return;
    setAccounts((current) => {
      const incomingById = new Map(incoming.map((account) => [account.id, account]));
      const existingIds = new Set(current.map((account) => account.id));
      const seen = new Set<string>();
      const merged = current.map((account) => {
        const next = incomingById.get(account.id);
        if (next) {
          seen.add(account.id);
          return next;
        }
        return account;
      });
      for (const account of incoming) {
        if (!seen.has(account.id) && !existingIds.has(account.id)) {
          merged.push(account);
        }
      }
      return merged;
    });
    setCurrentAccount((current) => {
      if (!current) return current;
      return incoming.find((account) => account.id === current.id) ?? current;
    });
  }, []);

  const removeAccountsFromState = useCallback((accountIds: string[]) => {
    const removed = new Set(accountIds);
    setAccounts((current) => current.filter((account) => !removed.has(account.id)));
    setCurrentAccount((current) => (current && removed.has(current.id) ? null : current));
    setSelectedAccountIds((current) => current.filter((id) => !removed.has(id)));
    setMaskedAccountIds((current) => current.filter((id) => !removed.has(id)));
  }, []);

  useEffect(() => {
    busyRef.current = busy;
  }, [busy]);

  useEffect(() => {
    cloudImportSubmittingSessionIdRef.current = cloudImportSubmittingSessionId;
  }, [cloudImportSubmittingSessionId]);

  useEffect(() => {
    accountsCountRef.current = accounts.length;
  }, [accounts.length]);

  useEffect(() => {
    const existingIds = new Set(accounts.map((account) => account.id));
    setSelectedAccountIds((current) => current.filter((id) => existingIds.has(id)));
    setMaskedAccountIds((current) => current.filter((id) => existingIds.has(id)));
  }, [accounts]);

  useEffect(() => {
    modalOpenRef.current = Boolean(addMode || editing || exportText || apiServiceOpen || apiServiceAccountsOpen || cloudImportPreview);
  }, [addMode, apiServiceAccountsOpen, apiServiceOpen, cloudImportPreview, editing, exportText]);

  useEffect(() => {
    if (!message) return undefined;
    const duration = message.tone === 'error' ? 7600 : message.tone === 'warning' ? 6200 : 3600;
    const timer = window.setTimeout(() => setMessage(null), duration);
    return () => window.clearTimeout(timer);
  }, [message]);

  useEffect(() => {
    if (serverUpdate.phase !== 'up-to-date') return undefined;
    const timer = window.setTimeout(() => {
      setServerUpdate((current) =>
        current.phase === 'up-to-date' ? DEFAULT_SERVER_UPDATE_STATE : current,
      );
    }, 3200);
    return () => window.clearTimeout(timer);
  }, [serverUpdate.phase]);

  useEffect(() => {
    let disposed = false;
    const localAccessRestoreTimers: number[] = [];
    const clearLocalAccessRestoreTimers = () => {
      while (localAccessRestoreTimers.length > 0) {
        const timer = localAccessRestoreTimers.pop();
        if (timer !== undefined) {
          window.clearTimeout(timer);
        }
      }
    };
    const scheduleLocalAccessRestoreRefresh = (state: CodexLocalAccessState | null) => {
      if (!state?.collection?.enabled || state.running) return;
      for (const delay of [800, 1800, 3200, 5200]) {
        const timer = window.setTimeout(() => {
          if (disposed) return;
          api.getCodexLocalAccessStateLight()
            .then((nextState) => {
              if (disposed) return;
              setLocalAccessState(nextState);
              if (nextState.running || !nextState.collection?.enabled) {
                clearLocalAccessRestoreTimers();
              }
            })
            .catch((error) => {
              console.warn('Refresh Codex API service restore state failed', error);
            });
        }, delay);
        localAccessRestoreTimers.push(timer);
      }
    };

    reload()
      .catch((error) => setMessage({ tone: 'error', text: `加载失败：${stripError(error)}` }))
      .finally(() => setBusy(null));
    reloadLocalAccess()
      .then((state) => {
        if (!disposed) {
          scheduleLocalAccessRestoreRefresh(state);
        }
      })
      .catch((error) => {
        console.warn('Load Codex API service state failed', error);
      });
    reloadApiServiceAppSpeed().catch((error) => {
      console.warn('Load Codex API service speed failed', error);
    });
    reloadExternalApiServiceConfig().catch((error) => {
      console.warn('Load Codex external API service config failed', error);
    });

    return () => {
      disposed = true;
      clearLocalAccessRestoreTimers();
    };
  }, [reload, reloadApiServiceAppSpeed, reloadExternalApiServiceConfig, reloadLocalAccess]);

  useEffect(() => {
    if (apiServiceAddressModeTouchedRef.current) return;
    setApiServiceAddressMode(
      externalApiServiceConfig?.active
        ? 'external-api'
        : 'localhost',
    );
  }, [externalApiServiceConfig?.active]);

  useEffect(() => {
    const profileId = externalApiServiceConfig?.profileId ?? '';
    const profiles = externalApiServiceConfig?.profiles ?? [];
    setSelectedProxyProfileId((current) => {
      if (current && profiles.some((profile) => profile.id === current)) {
        return current;
      }
      return profileId && profiles.some((profile) => profile.id === profileId) ? profileId : '';
    });
  }, [externalApiServiceConfig?.profileId, externalApiServiceConfig?.profiles]);

  useEffect(() => {
    let disposed = false;
    const timer = window.setTimeout(() => {
      api.checkServerUpdate(APP_VERSION)
        .then((info) => {
          if (disposed) return;
          if (info.hasUpdate && info.download) {
            setServerUpdate({
              phase: 'available',
              info,
              packagePath: '',
              error: '',
            });
          }
        })
        .catch((error) => {
          console.warn('Silent server update check failed', error);
        });
    }, 2400);
    return () => {
      disposed = true;
      window.clearTimeout(timer);
    };
  }, []);

  useEffect(() => {
    if (!apiServiceOpen) return;
    reloadLocalAccess().catch((error) => {
      setMessage({ tone: 'error', text: `加载 API 服务失败：${stripError(error)}` });
    });
  }, [apiServiceOpen, reloadLocalAccess]);

  useEffect(() => {
    let disposed = false;
    let unlistenProgress: UnlistenFn | undefined;
    let unlistenCloudProgress: UnlistenFn | undefined;
    let unlistenCloudRefreshed: UnlistenFn | undefined;

    listen<NonNullable<FileImportProgress>>('codex:file-import-progress', (event) => {
      if (disposed) return;
      setFileImportProgress(event.payload);
    }).then((unlisten) => {
      if (disposed) unlisten();
      else unlistenProgress = unlisten;
    });

    listen<NonNullable<CloudImportProgress>>('codex:cloud-import-progress', (event) => {
      if (disposed) return;
      if (cloudImportSubmittingSessionIdRef.current !== event.payload.sessionId) return;
      setCloudImportProgress({
        ...event.payload,
        account: null,
      });
    }).then((unlisten) => {
      if (disposed) unlisten();
      else unlistenCloudProgress = unlisten;
    });

    listen<CodexAccount[]>('codex:cloud-import-accounts-refreshed', (event) => {
      if (disposed) return;
      upsertAccounts(event.payload.map(markCloudImportedAccount));
    }).then((unlisten) => {
      if (disposed) unlisten();
      else unlistenCloudRefreshed = unlisten;
    });

    return () => {
      disposed = true;
      unlistenProgress?.();
      unlistenCloudProgress?.();
      unlistenCloudRefreshed?.();
    };
  }, [upsertAccounts]);

  const runAutoRefresh = useCallback(async () => {
    if (
      autoRefreshRunningRef.current
      || busyRef.current
      || modalOpenRef.current
      || accountsCountRef.current === 0
    ) {
      return;
    }
    autoRefreshRunningRef.current = true;
    setAutoRefreshRunning(true);
    setAutoRefreshStatusTone('normal');
    const startedAtManualVersion = manualOperationVersionRef.current;
    try {
      const count = await api.refreshAllCodexQuotas();
      if (
        manualOperationVersionRef.current !== startedAtManualVersion
        || busyRef.current
        || modalOpenRef.current
      ) {
        setAutoRefreshStatus('已让路给手动操作');
        return;
      }
      await reload();
      setAutoRefreshStatus(`上次 ${formatAutoRefreshClock()}，成功 ${count} 个账号`);
    } catch (error) {
      setAutoRefreshStatusTone('error');
      setAutoRefreshStatus(`上次自动刷新失败：${stripError(error)}`);
    } finally {
      autoRefreshRunningRef.current = false;
      setAutoRefreshRunning(false);
    }
  }, [reload]);

  useEffect(() => {
    if (autoRefreshMinutes <= 0) {
      setAutoRefreshRunning(false);
      setAutoRefreshStatusTone('normal');
      setAutoRefreshStatus('自动刷新已关闭');
      return undefined;
    }

    if (accounts.length === 0) {
      setAutoRefreshStatusTone('normal');
      setAutoRefreshStatus('等待导入账号');
      return undefined;
    }

    setAutoRefreshStatusTone('normal');
    setAutoRefreshStatus((current) =>
      current === '自动刷新已关闭' || current === '等待导入账号'
        ? '等待下一次自动刷新'
        : current,
    );

    const startupTimer = window.setTimeout(() => {
      void runAutoRefresh();
    }, 1200);
    const intervalTimer = window.setInterval(() => {
      void runAutoRefresh();
    }, autoRefreshMinutes * 60_000);

    return () => {
      window.clearTimeout(startupTimer);
      window.clearInterval(intervalTimer);
    };
  }, [accounts.length, autoRefreshMinutes, runAutoRefresh]);

  const runBusy = async (action: BusyAction, task: () => Promise<void>) => {
    if (busy) return;
    manualOperationVersionRef.current += 1;
    setBusy(action);
    setMessage(null);
    try {
      await task();
    } finally {
      setBusy(null);
    }
  };

  const saveApiServiceMembers = async (ids: string[], restrictFree: boolean) => {
    if (ids.length === 0) {
      setMessage({ tone: 'warning', text: '请先选择要加入 API 服务的账号。' });
      return false;
    }
    try {
      await runBusy('api-service-save', async () => {
        const next = await api.saveCodexLocalAccessAccounts(ids, restrictFree);
        setLocalAccessState(next);
        setMessage({ tone: 'success', text: `API 服务集合已保存：${next.memberCount} 个账号。` });
      });
      return true;
    } catch (error) {
      setMessage({ tone: 'error', text: `保存 API 服务集合失败：${stripError(error)}` });
      return false;
    }
  };

  const removeApiServiceMember = async (account: CodexAccount) => {
    await runBusy(`api-service-remove:${account.id}`, async () => {
      const next = await api.removeCodexLocalAccessAccount(account.id);
      setLocalAccessState(next);
      setMessage({ tone: 'success', text: `${displayName(account)} 已移出 API 服务。` });
    }).catch((error) => setMessage({ tone: 'error', text: `移出账号失败：${stripError(error)}` }));
  };

  const toggleApiServiceMembership = async (account: CodexAccount) => {
    const memberIds = localAccessState?.collection?.accountIds ?? [];
    const joined = memberIds.includes(account.id);
    const restrictFree = localAccessState?.collection?.restrictFreeAccounts ?? true;
    if (!joined && restrictFree && isFreeAccount(account)) {
      return;
    }

    await runBusy(`api-service-membership:${account.id}`, async () => {
      const next = joined
        ? await api.removeCodexLocalAccessAccount(account.id)
        : await api.saveCodexLocalAccessAccounts([...memberIds, account.id], restrictFree);
      setLocalAccessState(next);
      setMessage({
        tone: 'success',
        text: joined
          ? `${displayName(account)} 已移出 API 服务。`
          : `${displayName(account)} 已加入 API 服务。`,
      });
    }).catch((error) => setMessage({
      tone: 'error',
      text: `${joined ? '移出' : '加入'} API 服务失败：${stripError(error)}`,
    }));
  };

  const debouncedSearch = useDebouncedValue(search, 140);
  const accountSearchIndex = useMemo(
    () => new Map(accounts.map((account) => [account.id, searchText(account)])),
    [accounts],
  );
  const filteredAccounts = useMemo(() => {
    const query = debouncedSearch.trim().toLowerCase();
    return accounts.filter((account) => {
      if (filter === 'oauth' && isApiKeyAccount(account)) return false;
      if (filter === 'oauth' && isAgentIdentityAccount(account)) return false;
      if (filter === 'agent-identity' && !isAgentIdentityAccount(account)) return false;
      if (filter === 'api-key' && !isApiKeyAccount(account)) return false;
      if (filter === 'current' && account.id !== currentAccount?.id) return false;
      if (filter === 'attention' && !isAttentionAccount(account)) return false;
      return !query || (accountSearchIndex.get(account.id) ?? '').includes(query);
    });
  }, [accountSearchIndex, accounts, currentAccount?.id, debouncedSearch, filter]);
  const accountPagination = usePagination({
    items: filteredAccounts,
    storageKey: ACCOUNT_PAGE_SIZE_STORAGE_KEY,
    pageSizeOptions: ACCOUNT_PAGE_SIZE_OPTIONS,
    defaultPageSize: ACCOUNT_PAGE_SIZE_OPTIONS[0],
  });
  const paginatedAccounts = accountPagination.pageItems;
  const selectedAccountSet = useMemo(() => new Set(selectedAccountIds), [selectedAccountIds]);
  const maskedAccountSet = useMemo(() => new Set(maskedAccountIds), [maskedAccountIds]);
  const filteredAccountIds = useMemo(
    () => filteredAccounts.map((account) => account.id),
    [filteredAccounts],
  );
  const paginatedAccountIds = useMemo(
    () => paginatedAccounts.map((account) => account.id),
    [paginatedAccounts],
  );
  const allPaginatedAccountsSelected =
    paginatedAccountIds.length > 0 && paginatedAccountIds.every((id) => selectedAccountSet.has(id));
  const allFilteredAccountsSelected =
    filteredAccountIds.length > 0
    && filteredAccountIds.every((id) => selectedAccountSet.has(id));
  const canToggleAllFilteredAccounts = filteredAccountIds.length > paginatedAccountIds.length;

  useEffect(() => {
    accountPagination.setCurrentPage(1);
  }, [accountPagination.setCurrentPage, debouncedSearch, filter]);

  const apiServiceAccountSet = useMemo(
    () => new Set(localAccessState?.collection?.accountIds ?? []),
    [localAccessState?.collection?.accountIds],
  );
  const hasSavedProxyApiService = Boolean(externalApiServiceConfig?.baseUrl && externalApiServiceConfig.hasApiKey);
  const apiServiceQueryText = 'api 服务 api service 本地 codex 多账号服务 local access 代理 proxy';
  const searchQuery = debouncedSearch.trim().toLowerCase();
  const showApiServiceCard =
    apiServiceCardVisible
    && (accounts.length > 0 || Boolean(localAccessState?.collection) || hasSavedProxyApiService)
    && (filter === 'all' || (filter === 'current' && (Boolean(localAccessState?.collection?.enabled) || Boolean(externalApiServiceConfig?.active))))
    && (!searchQuery || apiServiceQueryText.includes(searchQuery));
  const selectedCardCount = selectedAccountIds.length + (apiServiceCardSelected ? 1 : 0);
  const allSelectedCardsMasked =
    selectedCardCount > 0
    && selectedAccountIds.every((id) => maskedAccountSet.has(id))
    && (!apiServiceCardSelected || apiServiceCardMasked);

  const oauthCount = accounts.filter((account) => !isApiKeyAccount(account) && !isAgentIdentityAccount(account)).length;
  const agentIdentityCount = accounts.filter(isAgentIdentityAccount).length;
  const apiKeyCount = accounts.filter(isApiKeyAccount).length;
  const attentionAccounts = useMemo(
    () => accounts.filter(isAttentionAccount),
    [accounts],
  );
  const attentionCount = attentionAccounts.length;
  const exportableAccounts = useMemo(
    () => accounts.filter((account) => !isCloudImportedAccount(account)),
    [accounts],
  );
  const selectedExportableAccounts = useMemo(
    () => exportableAccounts.filter((account) => selectedAccountSet.has(account.id)),
    [exportableAccounts, selectedAccountSet],
  );
  const workLocked = Boolean(busy);
  const canExportSeparateFiles = exportAccountCount > 1;
  const exportContainsApiKey = useMemo(() => {
    if (!exportText) return false;
    try {
      return parseCockpitToolsCodexExport(exportText).some(isApiKeyAccount);
    } catch {
      return false;
    }
  }, [exportText]);
  const exportContainsAgentIdentity = useMemo(() => {
    if (!exportText) return false;
    try {
      return parseCockpitToolsCodexExport(exportText).some(isAgentIdentityAccount);
    } catch {
      return false;
    }
  }, [exportText]);
  const formattedExportContent = useMemo<FormattedExportContent>(() => {
    const baseName = exportFileNameBase || 'codex_accounts';
    if (!exportText) {
      return {
        type: 'single',
        fileNameBase: buildExportDefaultFileNameBase(baseName, exportFormat),
        jsonContent: '',
      };
    }
    try {
      if (exportOutputMode === 'separate' && canExportSeparateFiles) {
        const sourceAccounts = parseCockpitToolsCodexExport(exportText);
        return {
          type: 'multiple',
          fileNameBase: buildExportDefaultFileNameBase(baseName, exportFormat),
          documents: sourceAccounts.map((account, index) => {
            const fileNameBase = exportSeparateFileNameBase(exportFormat, index);
            const content = buildCodexExportContent(JSON.stringify([account]), exportFormat, fileNameBase);
            return {
              id: `${account.id || account.email || 'codex_account'}_${index}`,
              label: displayName(account),
              fileNameBase: content.fileNameBase,
              jsonContent: content.jsonContent,
            };
          }),
        };
      }
      return {
        type: 'single',
        ...buildCodexExportContent(exportText, exportFormat, baseName),
      };
    } catch (error) {
      console.warn('Build Codex export content failed', error);
      return {
        type: 'single',
        fileNameBase: baseName,
        jsonContent: exportText,
      };
    }
  }, [canExportSeparateFiles, exportFileNameBase, exportFormat, exportOutputMode, exportText]);
  const formattedExportJsonContent =
    formattedExportContent.type === 'single' ? formattedExportContent.jsonContent : '';
  const formattedExportDocuments =
    formattedExportContent.type === 'multiple' ? formattedExportContent.documents : [];
  const exportDefaultFileName =
    exportText && formattedExportContent.type === 'single'
      ? exportFileName(formattedExportContent.fileNameBase, exportTimestamp || formatExportTimestamp())
      : '';
  const exportTargetText =
    formattedExportDocuments.length > 0
      ? `选择文件夹后保存 ${formattedExportDocuments.length} 个文件`
      : exportDefaultFileName;
  const buildCurrentExportContent = useCallback(() => {
    if (!exportText || formattedExportContent.type !== 'single') return null;
    return {
      fileNameBase: formattedExportContent.fileNameBase,
      jsonContent: formattedExportContent.jsonContent,
    };
  }, [exportText, formattedExportContent]);

  const toggleAccountSelection = useCallback((account: CodexAccount) => {
    setSelectedAccountIds((current) =>
      current.includes(account.id)
        ? current.filter((id) => id !== account.id)
        : [...current, account.id],
    );
  }, []);

  const togglePaginatedAccountSelection = useCallback(() => {
    if (paginatedAccountIds.length === 0) return;
    setSelectedAccountIds((current) => {
      const next = new Set(current);
      const shouldClear = paginatedAccountIds.every((id) => next.has(id));
      if (shouldClear) {
        for (const id of paginatedAccountIds) next.delete(id);
      } else {
        for (const id of paginatedAccountIds) next.add(id);
      }
      return Array.from(next);
    });
  }, [paginatedAccountIds]);

  const toggleFilteredAccountSelection = useCallback(() => {
    if (filteredAccountIds.length === 0) return;
    setSelectedAccountIds((current) => {
      const next = new Set(current);
      const shouldClear = filteredAccountIds.every((id) => next.has(id));
      if (shouldClear) {
        for (const id of filteredAccountIds) next.delete(id);
      } else {
        for (const id of filteredAccountIds) next.add(id);
      }
      return Array.from(next);
    });
  }, [filteredAccountIds]);

  const clearAccountSelection = useCallback(() => {
    setSelectedAccountIds([]);
    setApiServiceCardSelected(false);
  }, []);

  const toggleSelectedCardMasking = useCallback(() => {
    const shouldMask = !allSelectedCardsMasked;
    setMaskedAccountIds((current) => {
      const next = new Set(current);
      for (const id of selectedAccountIds) {
        if (shouldMask) next.add(id);
        else next.delete(id);
      }
      return Array.from(next);
    });
    if (apiServiceCardSelected) setApiServiceCardMasked(shouldMask);
  }, [allSelectedCardsMasked, apiServiceCardSelected, selectedAccountIds]);

  const markApiServicesInactive = useCallback(() => {
    setLocalAccessState((current) => {
      if (!current?.collection) return current;
      return {
        ...current,
        running: false,
        collection: {
          ...current.collection,
          enabled: false,
        },
      };
    });
    setExternalApiServiceConfig((current) => (current ? { ...current, active: false } : current));
  }, []);

  const switchAccount = (account: CodexAccount) => {
    void runBusy(`switch:${account.id}`, async () => {
      const next = await api.switchCodexAccount(account.id);
      upsertAccounts([next]);
      setCurrentAccount(next);
      markApiServicesInactive();
      setMessage({ tone: 'success', text: `已切换 Codex 登录到 ${displayName(next)}。` });
    }).catch((error) => setMessage({ tone: 'error', text: `切换失败：${stripError(error)}` }));
  };

  const refreshAccount = (account: CodexAccount) => {
    void runBusy(`refresh:${account.id}`, async () => {
      const quota = await api.refreshCodexQuota(account.id);
      const next = { ...account, quota, quota_error: undefined };
      upsertAccounts([next]);
      setMessage({ tone: 'success', text: `已刷新 ${displayName(account)}。` });
    }).catch((error) => setMessage({ tone: 'error', text: `刷新失败：${stripError(error)}` }));
  };

  const saveAccountSpeed = (account: CodexAccount, speed: CodexAppSpeed) => {
    if ((account.app_speed ?? 'standard') === speed) return;
    void runBusy(`speed:${account.id}`, async () => {
      const next = await api.updateCodexAccountAppSpeed(account.id, speed);
      upsertAccounts([next]);
      setMessage({ tone: 'success', text: `已将 ${displayName(next)} 设置为${speed === 'fast' ? '快速' : '标准'}。` });
    }).catch((error) => setMessage({ tone: 'error', text: `保存速度失败：${stripError(error)}` }));
  };

  const saveApiServiceSpeed = (speed: CodexAppSpeed) => {
    if (apiServiceAppSpeed === speed) return;
    const previousSpeed = apiServiceAppSpeed;
    setApiServiceAppSpeed(speed);
    void runBusy('api-service-speed', async () => {
      const saved = await api.saveCodexApiServiceAppSpeed(speed);
      setApiServiceAppSpeed(saved.speed);
      setMessage({ tone: 'success', text: `API 服务已设置为${saved.speed === 'fast' ? '快速' : '标准'}。` });
    }).catch((error) => {
      setApiServiceAppSpeed(previousSpeed);
      setMessage({ tone: 'error', text: `保存 API 服务速度失败：${stripError(error)}` });
    });
  };

  const deleteAccount = (account: CodexAccount) => {
    if (!window.confirm(`确定删除 ${displayName(account)}？`)) return;
    void runBusy(`delete:${account.id}`, async () => {
      const wasApiServiceMember = apiServiceAccountSet.has(account.id);
      await api.deleteCodexAccount(account.id);
      removeAccountsFromState([account.id]);
      let localAccessRefreshError = '';
      if (wasApiServiceMember) {
        await reloadLocalAccess().catch((error) => {
          localAccessRefreshError = stripError(error);
        });
      }
      setMessage(
        localAccessRefreshError
          ? { tone: 'warning', text: `账号已删除，但刷新 API 服务状态失败：${localAccessRefreshError}` }
          : { tone: 'success', text: '账号已删除。' },
      );
    }).catch((error) => setMessage({ tone: 'error', text: `删除失败：${stripError(error)}` }));
  };

  const deleteSelectedAccounts = () => {
    const existingIds = new Set(accounts.map((account) => account.id));
    const ids = selectedAccountIds.filter((id) => existingIds.has(id));
    const hidesApiServiceCard = apiServiceCardSelected && apiServiceCardVisible;
    if (ids.length === 0 && !hidesApiServiceCard) return;
    const idsSet = new Set(ids);
    const deletingAllFiltered =
      filteredAccountIds.length > 0
      && ids.length === filteredAccountIds.length
      && filteredAccountIds.every((id) => idsSet.has(id));
    const apiCardNotice = hidesApiServiceCard ? '，并隐藏 API 服务卡片（不会删除服务配置）' : '';
    const confirmText = ids.length === 0
      ? '确定隐藏 API 服务卡片？服务配置不会被删除，可在设置中重新显示。'
      : deletingAllFiltered
      ? `将删除当前筛选条件下的 ${ids.length} 个 Codex 账号${apiCardNotice}。此操作不会只删除当前页，确认继续？`
      : `确定删除已选择的 ${ids.length} 个 Codex 账号${apiCardNotice}？`;
    if (!window.confirm(confirmText)) return;
    void runBusy('delete-selected', async () => {
      const hadApiServiceMembers = ids.some((id) => apiServiceAccountSet.has(id));
      if (ids.length > 0) {
        await api.deleteCodexAccounts(ids);
        removeAccountsFromState(ids);
      }
      if (hidesApiServiceCard) {
        localStorage.setItem(API_SERVICE_CARD_STORAGE_KEY, 'false');
        setApiServiceCardVisible(false);
        setApiServiceCardSelected(false);
        setApiServiceCardMasked(false);
      }
      let localAccessRefreshError = '';
      if (hadApiServiceMembers) {
        await reloadLocalAccess().catch((error) => {
          localAccessRefreshError = stripError(error);
        });
      }
      const completedText = ids.length > 0
        ? `已删除 ${ids.length} 个账号${hidesApiServiceCard ? '，并隐藏 API 服务卡片' : ''}。`
        : 'API 服务卡片已隐藏，服务配置未删除。';
      setMessage(localAccessRefreshError
        ? { tone: 'warning', text: `${completedText} 刷新 API 服务状态失败：${localAccessRefreshError}` }
        : { tone: 'success', text: completedText });
    }).catch((error) => setMessage({ tone: 'error', text: `批量删除失败：${stripError(error)}` }));
  };

  const deleteAttentionAccounts = () => {
    const ids = attentionAccounts.map((account) => account.id);
    if (ids.length === 0) {
      setMessage({ tone: 'info', text: '没有异常账号。' });
      return;
    }
    if (!window.confirm(`将删除 ${ids.length} 个异常 Codex 账号，包括授权异常或配额刷新失败的账号。确认继续？`)) return;
    void runBusy('delete-errors', async () => {
      const hadApiServiceMembers = ids.some((id) => apiServiceAccountSet.has(id));
      await api.deleteCodexAccounts(ids);
      removeAccountsFromState(ids);
      let localAccessRefreshError = '';
      if (hadApiServiceMembers) {
        await reloadLocalAccess().catch((error) => {
          localAccessRefreshError = stripError(error);
        });
      }
      setFilter((current) => (current === 'attention' ? 'all' : current));
      setMessage(
        localAccessRefreshError
          ? { tone: 'warning', text: `已删除 ${ids.length} 个异常账号，但刷新 API 服务状态失败：${localAccessRefreshError}` }
          : { tone: 'success', text: `已删除 ${ids.length} 个异常账号。` },
      );
    }).catch((error) => setMessage({ tone: 'error', text: `删除异常账号失败：${stripError(error)}` }));
  };

  const refreshAll = () => {
    void runBusy('refresh-all', async () => {
      const count = await api.refreshAllCodexQuotas();
      await reload();
      setMessage({ tone: 'success', text: `已刷新 ${count} 个账号。` });
    }).catch((error) => setMessage({ tone: 'error', text: `批量刷新失败：${stripError(error)}` }));
  };

  const importFiles = () => {
    void runBusy('import-files', async () => {
      const selected = await openFileDialog({
        multiple: true,
        filters: [{ name: 'Codex JSON', extensions: ['json', 'txt'] }],
      });
      const paths = Array.isArray(selected) ? selected : selected ? [selected] : [];
      if (paths.length === 0) return;
      setFileImportProgress({ current: 0, total: paths.length });
      const result = await api.importCodexFromFiles(paths);
      upsertAccounts(result.imported);
      const failedText = result.failed.length > 0 ? `，${result.failed.length} 个失败` : '';
      setMessage({
        tone: result.failed.length > 0 ? 'warning' : 'success',
        text: `已导入 ${result.imported.length} 个账号${failedText}，点击账号卡片上的“切换”即可启用为 Codex 登录。`,
      });
      window.setTimeout(() => setFileImportProgress(null), 1200);
    }).catch((error) => {
      setFileImportProgress(null);
      setMessage({ tone: 'error', text: `文件导入失败：${stripError(error)}` });
    });
  };

  const previewCloudImport = () => {
    void runBusy('cloud-preview', async () => {
      const preview = await api.previewCodexCloudImport();
      const selectableIds = preview.items
        .filter((item) => item.selectable)
        .map((item) => item.itemId);
      setCloudImportPreview(preview);
      if (selectableIds.length === 0) {
        setMessage({ tone: 'warning', text: '云端没有识别到可导入的账号。' });
      } else {
        setCloudImportProgress(null);
        setMessage({ tone: 'success', text: `已从云端识别到 ${selectableIds.length} 个账号，请确认后导入。` });
      }
    }).catch((error) => setMessage({ tone: 'error', text: `云端导入失败：${stripError(error)}` }));
  };

  const closeCloudImportPreview = () => {
    if (cloudImportPreview) {
      cloudImportCancelledSessionsRef.current.add(cloudImportPreview.sessionId);
      void api.cancelCodexCloudImport(cloudImportPreview.sessionId).catch(() => undefined);
      if (cloudImportSubmittingSessionIdRef.current === cloudImportPreview.sessionId) {
        cloudImportSubmittingSessionIdRef.current = null;
        setCloudImportSubmittingSessionId(null);
      }
    }
    setCloudImportProgress(null);
    setCloudImportPreview(null);
  };

  const confirmCloudImport = () => {
    const preview = cloudImportPreview;
    if (!preview) return;
    const sessionId = preview.sessionId;
    const itemIds = preview.items
      .filter((item) => item.selectable)
      .map((item) => item.itemId);
    if (itemIds.length === 0) {
      setMessage({ tone: 'warning', text: '云端没有可导入的账号。' });
      return;
    }
    if (cloudImportSubmittingSessionIdRef.current) return;
    cloudImportCancelledSessionsRef.current.delete(sessionId);
    cloudImportSubmittingSessionIdRef.current = sessionId;
    setCloudImportSubmittingSessionId(sessionId);
    setCloudImportProgress({
      sessionId,
      current: 0,
      total: itemIds.length,
      imported: 0,
      failed: 0,
      currentLabel: null,
      cancelled: false,
      done: false,
    });
    setMessage(null);
    void (async () => {
      const result = await api.confirmCodexCloudImport(
        sessionId,
        itemIds,
      );
      const wasCancelled = cloudImportCancelledSessionsRef.current.delete(sessionId);
      upsertAccounts(result.imported.map(markCloudImportedAccount));
      const failedText = result.failed.length > 0 ? `，${result.failed.length} 个失败` : '';
      setCloudImportPreview(null);
      setCloudImportProgress(null);
      setMessage({
        tone: wasCancelled || result.failed.length > 0 ? 'warning' : 'success',
        text: wasCancelled
          ? `已停止从云端导入，已导入 ${result.imported.length} 个账号${failedText}。`
          : `已从云端导入 ${result.imported.length} 个账号${failedText}，点击账号卡片上的“切换”即可启用为 Codex 登录。`,
      });
    })().catch((error) => {
      if (cloudImportCancelledSessionsRef.current.delete(sessionId)) {
        return;
      }
      setMessage({ tone: 'error', text: `从云端导入失败：${stripError(error)}` });
    }).finally(() => {
      if (cloudImportSubmittingSessionIdRef.current === sessionId) {
        cloudImportSubmittingSessionIdRef.current = null;
        setCloudImportSubmittingSessionId(null);
      }
      setCloudImportProgress((current) => (current?.sessionId === sessionId ? null : current));
    });
  };

  const exportAccounts = (targetAccounts: CodexAccount[], title: string) => {
    if (targetAccounts.length === 0) {
      setMessage({ tone: 'warning', text: '没有可导出的账号。' });
      return;
    }
    const action: BusyAction = targetAccounts.length === 1 ? `export:${targetAccounts[0].id}` : 'export';
    void runBusy(action, async () => {
      const content = await api.exportCodexAccounts(targetAccounts.map((account) => account.id));
      const containsApiKey = targetAccounts.some(isApiKeyAccount);
      const containsAgentIdentity = targetAccounts.some(isAgentIdentityAccount);
      const requiresStandardFormat =
        (containsApiKey && exportFormat !== 'cockpit_tools')
        || (containsAgentIdentity && exportFormat === 'cpa');
      if (requiresStandardFormat) {
        localStorage.setItem(EXPORT_FORMAT_STORAGE_KEY, 'cockpit_tools');
        setExportFormat('cockpit_tools');
      }
      const baseName = targetAccounts.length === 1 ? displayName(targetAccounts[0]) : 'codex_accounts';
      const fileNameBase = sanitizeFileNameSegment(baseName, 'codex_accounts');
      const timestamp = formatExportTimestamp();
      setExportText(content);
      setExportTitle(title);
      setExportFileNameBase(fileNameBase);
      setExportTimestamp(timestamp);
      setExportAccountCount(targetAccounts.length);
      setExportCopied(false);
      setExportJsonHidden(true);
      setExportSavedPath('');
      setExportSavedPathIsDirectory(false);
      setExportPathCopied(false);
      setExportSavingDocumentId(null);
      setMessage({
        tone: requiresStandardFormat ? 'warning' : 'success',
        text: requiresStandardFormat
          ? '当前账号不兼容所选格式，已自动切换为标准 JSON。'
          : '导出内容已准备好，可选择格式后复制或保存。',
      });
    }).catch((error) => setMessage({ tone: 'error', text: `导出失败：${stripError(error)}` }));
  };

  const exportSelected = () => {
    if (selectedExportableAccounts.length === 0) {
      setMessage({ tone: 'warning', text: '请先勾选要导出的账号。' });
      return;
    }
    exportAccounts(selectedExportableAccounts, `${selectedExportableAccounts.length} 个所选 Codex 账号`);
  };

  const exportAccount = (account: CodexAccount) => {
    if (isCloudImportedAccount(account)) {
      setMessage({ tone: 'warning', text: '云端导入的账号不能导出。' });
      return;
    }
    exportAccounts([account], displayName(account));
  };

  const openConfig = () => {
    void runBusy('config', async () => {
      const path = await api.getCodexConfigTomlPath();
      await openPath(path);
    }).catch((error) => setMessage({ tone: 'error', text: `打开配置失败：${stripError(error)}` }));
  };

  const activateApiService = () => {
    const memberIds = localAccessState?.collection?.accountIds ?? [];
    if (memberIds.length === 0) {
      setApiServiceOpen(true);
      setMessage({ tone: 'warning', text: '请先选择要加入 API 服务的账号。' });
      return;
    }
    void runBusy('api-service-activate', async () => {
      if (apiServiceAddressMode !== 'external-api' && localAccessState?.collection?.clientBaseUrlHost !== apiServiceAddressMode) {
        const next = await api.updateCodexLocalAccessClientBaseUrlHost(apiServiceAddressMode);
        setLocalAccessState(next);
      }
      const activated = await api.activateCodexLocalAccess();
      setLocalAccessState(activated);
      changeApiServiceAddressMode('localhost');
      setExternalApiServiceConfig((current) => (current ? { ...current, active: false } : current));
      setCurrentAccount(null);
      let restartError = '';
      try {
        await api.restartCodexDefaultApp();
      } catch (error) {
        restartError = stripError(error);
      }
      if (restartError) {
        setMessage({ tone: 'warning', text: `已保存并切换到 API 服务，但自动重启失败：${restartError}。请手动重启 Codex。` });
      } else {
        setMessage({ tone: 'success', text: '已保存并切换到 API 服务。' });
      }
    }).catch((error) => setMessage({ tone: 'error', text: `启动 API 服务失败：${stripError(error)}` }));
  };

  const activateProxyApiService = () => {
    const config = externalApiServiceConfig;
    const selectedProfile = config?.profiles?.find((profile) => profile.id === selectedProxyProfileId) ?? null;
    void runBusy('api-service-activate', async () => {
      const result = await api.activateCodexExternalApiService({
        profileId: selectedProfile?.id ?? null,
        apiKey: null,
        apiBaseUrl: '',
        apiProviderName: selectedProfile?.providerName ?? undefined,
        refreshCloudDefault: !selectedProfile,
      });
      setLocalAccessState(result.state);
      setExternalApiServiceConfig(result.config);
      setSelectedProxyProfileId(result.config.profileId ?? '');
      changeApiServiceAddressMode('external-api');
      setCurrentAccount(null);
      let restartError = '';
      try {
        await api.restartCodexDefaultApp();
      } catch (error) {
        restartError = stripError(error);
      }
      if (restartError) {
        setMessage({ tone: 'warning', text: `已启动代理 API 服务，但自动重启失败：${restartError}。请手动重启 Codex。` });
      } else {
        setMessage({ tone: 'success', text: '已启动代理 API 服务。' });
      }
    }).catch((error) => setMessage({ tone: 'error', text: `启动代理 API 服务失败：${stripError(error)}` }));
  };

  const disableApiService = () => {
    void runBusy('api-service-disable', async () => {
      const next = await api.setCodexLocalAccessEnabled(false);
      setLocalAccessState(next);
      setMessage({ tone: 'success', text: 'API 服务已停用。' });
    }).catch((error) => setMessage({ tone: 'error', text: `停用 API 服务失败：${stripError(error)}` }));
  };

  const disableProxyApiService = () => {
    void runBusy('api-service-disable', async () => {
      const result = await api.deactivateCodexExternalApiService();
      setLocalAccessState(result.state);
      setExternalApiServiceConfig(result.config);
      setCurrentAccount(null);
      let restartError = '';
      try {
        await api.restartCodexDefaultApp();
      } catch (error) {
        restartError = stripError(error);
      }
      if (restartError) {
        setMessage({ tone: 'warning', text: `代理 API 服务已停用，但自动重启失败：${restartError}。请手动重启 Codex。` });
      } else {
        setMessage({ tone: 'success', text: '代理 API 服务已停用。' });
      }
    }).catch((error) => setMessage({ tone: 'error', text: `停用代理 API 服务失败：${stripError(error)}` }));
  };

  const selectApiServiceMode = (mode: ApiServiceAddressMode) => {
    if (mode === apiServiceAddressMode) return;
    changeApiServiceAddressMode(mode);
    setMessage({ tone: 'success', text: `API 模式已保存为 ${apiServiceModeLabel(mode)}。` });
  };

  const toggleApiService = () => {
    const targetIsActive = isApiServiceTargetActive(
      localAccessState,
      externalApiServiceConfig,
      apiServiceAddressMode,
      selectedProxyProfileId,
    );
    if (apiServiceAddressMode === 'external-api') {
      if (targetIsActive) {
        disableProxyApiService();
      } else {
        activateProxyApiService();
      }
      return;
    }
    if (targetIsActive) {
      disableApiService();
    } else {
      activateApiService();
    }
  };

  const editAccount = (account: CodexAccount) => {
    setEditing({
      account,
      name: account.account_name || '',
      note: account.account_note || '',
      tags: (account.tags ?? []).join(', '),
      apiKey: '',
      apiBaseUrl: account.api_base_url || OPENAI_BASE_URL,
      apiWireApi: account.api_wire_api || 'responses',
    });
  };

  const copyExport = async () => {
    if (formattedExportDocuments.length > 0) return;
    const content = buildCurrentExportContent();
    if (!content) return;
    try {
      await navigator.clipboard.writeText(content.jsonContent);
      setExportCopied(true);
      window.setTimeout(() => setExportCopied(false), 1200);
    } catch (error) {
      setExportCopied(false);
      setMessage({ tone: 'error', text: `复制失败：${stripError(error)}` });
    }
  };

  const closeExport = () => {
    setExportText('');
    setExportTitle('');
    setExportFileNameBase('codex_accounts');
    setExportTimestamp('');
    setExportAccountCount(0);
    setExportCopied(false);
    setExportSaving(false);
    setExportJsonHidden(true);
    setExportSavedPath('');
    setExportSavedPathIsDirectory(false);
    setExportPathCopied(false);
    setExportSavingDocumentId(null);
  };

  const onExportFormatChange = (event: ChangeEvent<HTMLSelectElement>) => {
    const next = event.target.value as CodexExportFormat;
    if (exportContainsApiKey && next !== 'cockpit_tools') {
      setMessage({ tone: 'warning', text: 'API Key 账号仅支持导出为标准 JSON。' });
      return;
    }
    if (exportContainsAgentIdentity && next === 'cpa') {
      setMessage({ tone: 'warning', text: 'Agent Identity 账号不支持 CPA 格式，可选择标准 JSON 或 Sub2API。' });
      return;
    }
    localStorage.setItem(EXPORT_FORMAT_STORAGE_KEY, next);
    setExportFormat(next);
    setExportCopied(false);
    setExportSavedPath('');
    setExportSavedPathIsDirectory(false);
    setExportPathCopied(false);
  };

  const onExportOutputModeChange = (event: ChangeEvent<HTMLSelectElement>) => {
    const next = event.target.value as ExportOutputMode;
    localStorage.setItem(EXPORT_OUTPUT_MODE_STORAGE_KEY, next);
    setExportOutputMode(next);
    setExportCopied(false);
    setExportSavedPath('');
    setExportSavedPathIsDirectory(false);
    setExportPathCopied(false);
  };

  const toggleExportJsonHidden = () => setExportJsonHidden((current) => !current);

  const saveExport = async () => {
    if (!exportText || exportSaving) return;
    setExportSaving(true);
    try {
      if (formattedExportDocuments.length > 0) {
        const directoryPath = await openFileDialog({
          directory: true,
          multiple: false,
        });
        if (!directoryPath || Array.isArray(directoryPath)) return;
        const timestamp = exportTimestamp || formatExportTimestamp();
        const files = formattedExportDocuments.map((document) => ({
          fileName: exportFileName(document.fileNameBase, timestamp),
          content: document.jsonContent,
        }));
        await api.saveCodexExportFiles(directoryPath, files);
        setExportSavedPath(directoryPath);
        setExportSavedPathIsDirectory(true);
        setExportPathCopied(false);
        setMessage({ tone: 'success', text: `已保存 ${files.length} 个${exportFormatLabel(exportFormat)}文件。` });
        return;
      }

      const filePath = await saveFileDialog({
        defaultPath: exportDefaultFileName || exportFileName('codex_accounts_standard_json', formatExportTimestamp()),
        filters: [{ name: 'JSON', extensions: ['json'] }],
      });
      if (!filePath) return;
      const content = buildCurrentExportContent();
      if (!content) return;
      await api.saveCodexExportFile(filePath, content.jsonContent);
      setExportSavedPath(filePath);
      setExportSavedPathIsDirectory(false);
      setExportPathCopied(false);
      setMessage({ tone: 'success', text: `${exportFormatLabel(exportFormat)}已保存为文件。` });
    } catch (error) {
      setMessage({ tone: 'error', text: `保存导出文件失败：${stripError(error)}` });
    } finally {
      setExportSaving(false);
    }
  };

  const saveExportDocument = async (document: ExportDocument) => {
    if (exportSavingDocumentId) return;
    setExportSavingDocumentId(document.id);
    try {
      const timestamp = exportTimestamp || formatExportTimestamp();
      const filePath = await saveFileDialog({
        defaultPath: exportFileName(document.fileNameBase, timestamp),
        filters: [{ name: 'JSON', extensions: ['json'] }],
      });
      if (!filePath) return;
      await api.saveCodexExportFile(filePath, document.jsonContent);
      setExportSavedPath(filePath);
      setExportSavedPathIsDirectory(false);
      setExportPathCopied(false);
      setMessage({ tone: 'success', text: `${document.label} 已保存为文件。` });
    } catch (error) {
      setMessage({ tone: 'error', text: `保存导出文件失败：${stripError(error)}` });
    } finally {
      setExportSavingDocumentId(null);
    }
  };

  const openExportSavedPath = async () => {
    if (!exportSavedPath) return;
    const targetPath = exportSavedPathIsDirectory ? exportSavedPath : getDirectoryPath(exportSavedPath);
    await openPath(targetPath).catch((error) => {
      setMessage({ tone: 'error', text: `打开保存位置失败：${stripError(error)}` });
    });
  };

  const copyExportSavedPath = async () => {
    if (!exportSavedPath) return;
    await navigator.clipboard.writeText(exportSavedPath).catch(() => {});
    setExportPathCopied(true);
    window.setTimeout(() => setExportPathCopied(false), 1200);
  };

  const onSearch = (event: ChangeEvent<HTMLInputElement>) => setSearch(event.target.value);
  const onAutoRefreshChange = (event: ChangeEvent<HTMLSelectElement>) => {
    const next = parseAutoRefreshMinutes(event.target.value);
    localStorage.setItem(AUTO_REFRESH_STORAGE_KEY, String(next));
    setAutoRefreshMinutes(next);
    setAutoRefreshStatusTone('normal');
    setAutoRefreshStatus(next > 0 ? '等待下一次自动刷新' : '自动刷新已关闭');
  };
  const onApiServiceCardVisibleChange = (visible: boolean) => {
    localStorage.setItem(API_SERVICE_CARD_STORAGE_KEY, String(visible));
    setApiServiceCardVisible(visible);
    if (!visible) {
      setApiServiceCardSelected(false);
      setApiServiceCardMasked(false);
    }
  };
  const downloadServerUpdate = useCallback(async (info: CodexServerUpdateInfo) => {
    const download = info.download;
    if (!download) {
      setServerUpdate({
        phase: 'error',
        info,
        packagePath: '',
        error: '当前平台没有匹配的安装包',
      });
      setMessage({ tone: 'error', text: '当前平台没有匹配的安装包。' });
      return;
    }
    setServerUpdate({
      phase: 'downloading',
      info,
      packagePath: '',
      error: '',
    });
    try {
      const packagePath = await api.downloadServerUpdate(download.url, download.name);
      const notes = compactUpdateNotes(info.notes);
      setServerUpdate({
        phase: 'downloaded',
        info,
        packagePath,
        error: '',
      });
      setMessage({
        tone: 'success',
        text: notes
          ? `更新 ${info.latestVersion} 已下载。更新内容：${notes}。点击“重启安装”完成更新。`
          : `更新 ${info.latestVersion} 已下载，点击“重启安装”完成更新。`,
      });
    } catch (error) {
      setServerUpdate({
        phase: 'error',
        info,
        packagePath: '',
        error: stripError(error),
      });
      setMessage({ tone: 'error', text: `更新下载失败：${stripError(error)}` });
    }
  }, []);
  const checkForServerUpdate = useCallback(async (downloadWhenFound = false) => {
    if (['checking', 'downloading', 'installing'].includes(serverUpdate.phase)) return;
    setServerUpdate((current) => ({
      phase: 'checking',
      info: current.info,
      packagePath: current.packagePath,
      error: '',
    }));
    try {
      const info = await api.checkServerUpdate(APP_VERSION);
      if (!info.hasUpdate || !info.download) {
        setServerUpdate({
          phase: 'up-to-date',
          info,
          packagePath: '',
          error: '',
        });
        setMessage({ tone: 'success', text: '当前已是最新版本。' });
        return;
      }
      setServerUpdate({
        phase: 'available',
        info,
        packagePath: '',
        error: '',
      });
      if (downloadWhenFound) {
        await downloadServerUpdate(info);
      } else {
        const notes = compactUpdateNotes(info.notes);
        setMessage({
          tone: 'info',
          text: notes
            ? `发现新版本 ${info.latestVersion}。更新内容：${notes}`
            : `发现新版本 ${info.latestVersion}。`,
        });
      }
    } catch (error) {
      setServerUpdate({
        phase: 'error',
        info: null,
        packagePath: '',
        error: stripError(error),
      });
      setMessage({ tone: 'error', text: `检查更新失败：${stripError(error)}` });
    }
  }, [downloadServerUpdate, serverUpdate.phase]);
  const installServerUpdate = useCallback(async () => {
    if (!serverUpdate.packagePath || !serverUpdate.info?.download) {
      setMessage({ tone: 'warning', text: '请先下载更新安装包。' });
      return;
    }
    setServerUpdate((current) => ({
      ...current,
      phase: 'installing',
      error: '',
    }));
    try {
      await api.installServerUpdate(serverUpdate.packagePath, serverUpdate.info.download.kind);
    } catch (error) {
      setServerUpdate((current) => ({
        ...current,
        phase: 'downloaded',
        error: stripError(error),
      }));
      setMessage({ tone: 'error', text: `启动更新安装失败：${stripError(error)}` });
    }
  }, [serverUpdate.info, serverUpdate.packagePath]);
  const handleServerUpdateAction = useCallback(() => {
    if (serverUpdate.phase === 'downloaded') {
      void installServerUpdate();
      return;
    }
    if (serverUpdate.phase === 'available' && serverUpdate.info) {
      void downloadServerUpdate(serverUpdate.info);
      return;
    }
    if (serverUpdate.phase === 'error' && serverUpdate.info?.hasUpdate && serverUpdate.info.download) {
      void downloadServerUpdate(serverUpdate.info);
      return;
    }
    void checkForServerUpdate(false);
  }, [checkForServerUpdate, downloadServerUpdate, installServerUpdate, serverUpdate]);
  const openApiServiceAccounts = () => {
    setApiServiceAccountsOpen(true);
    reloadLocalAccess().catch((error) => {
      console.warn('Load Codex API service state failed', error);
    });
  };
  const handleWindowDragStart = useCallback((event: ReactMouseEvent<HTMLDivElement>) => {
    if (event.button !== 0) return;
    if (event.detail >= 2) return;
    void getCurrentWindow().startDragging().catch((error) => {
      console.warn('Start dragging failed', error);
    });
  }, []);
  const serverUpdateBusy = ['checking', 'downloading', 'installing'].includes(serverUpdate.phase);
  const showTitleUpdateReminder = ['available', 'downloading', 'downloaded', 'installing'].includes(serverUpdate.phase);
  const serverUpdateVersion = serverUpdate.info?.latestVersion || '';
  const serverUpdateLabel = serverUpdateButtonLabel(serverUpdate.phase);
  const serverUpdateNotes = compactUpdateNotes(serverUpdate.info?.notes);
  const serverUpdateTitle = serverUpdateVersion
    ? `更新到 ${serverUpdateVersion}${serverUpdateNotes ? `\n\n更新内容：${serverUpdateNotes}` : ''}`
    : '检查更新';

  return (
    <main className="shell">
      <div
        className="drag-region"
        data-tauri-drag-region
        onMouseDown={handleWindowDragStart}
      />
      <section className="hero" data-tauri-drag-region onMouseDown={handleWindowDragStart}>
        <div className="hero-main" data-tauri-drag-region>
          <div className="logo" data-tauri-drag-region><img src={appIcon} alt="" data-tauri-drag-region /></div>
          <div data-tauri-drag-region>
            <div className="title-row" data-tauri-drag-region>
              <h1 data-tauri-drag-region>Codex 账号管理工具</h1>
              {showTitleUpdateReminder ? (
                <button
                  type="button"
                  className={`title-update-pill ${serverUpdate.phase}`}
                  onMouseDown={(event) => event.stopPropagation()}
                  onClick={handleServerUpdateAction}
                  disabled={serverUpdateBusy}
                  title={serverUpdateTitle}
                >
                  {serverUpdateBusy ? <Loader2 size={13} className="spin" /> : serverUpdate.phase === 'downloaded' ? <RefreshCw size={13} /> : <Download size={13} />}
                  {serverUpdate.phase === 'available' && serverUpdateVersion ? `有更新 ${serverUpdateVersion}` : serverUpdateLabel}
                </button>
              ) : null}
            </div>
            {showTitleUpdateReminder && serverUpdateNotes ? (
              <div className="title-update-notes" data-tauri-drag-region>
                更新内容：{serverUpdateNotes}
              </div>
            ) : null}
          </div>
        </div>
        <div className="current-card" data-tauri-drag-region>
          <span data-tauri-drag-region>当前账号</span>
          <strong title={currentAccount ? displayName(currentAccount) : '未启用'} data-tauri-drag-region>
            {currentAccount ? displayName(currentAccount) : '未启用'}
          </strong>
        </div>
      </section>

      <StatusMessage message={message} onClose={() => setMessage(null)} />

      <section className="layout">
        <aside className="sidebar">
          <div className="stats">
            <div><span>全部</span><strong>{accounts.length}</strong></div>
            <div><span>OAuth</span><strong>{oauthCount}</strong></div>
            <div><span>Agent</span><strong>{agentIdentityCount}</strong></div>
            <div><span>API Key</span><strong>{apiKeyCount}</strong></div>
            <div><span>需关注</span><strong>{attentionCount}</strong></div>
          </div>

          <div className="action-group">
            <button type="button" className="primary" onClick={() => setAddMode('oauth')} disabled={workLocked}><LogIn size={15} />OAuth 授权</button>
            <button type="button" className="secondary" onClick={() => setAddMode('api-key')} disabled={workLocked}><KeyRound size={15} />添加 API Key</button>
            <button type="button" className="secondary" onClick={() => setAddMode('json')} disabled={workLocked}><FileJson size={15} />粘贴 JSON</button>
            <button type="button" className="secondary" onClick={importFiles} disabled={workLocked}>
              {busy === 'import-files' ? <Loader2 size={15} className="spin" /> : <Upload size={15} />}
              从文件导入
            </button>
            <button type="button" className="secondary" onClick={previewCloudImport} disabled={workLocked}>
              {busy === 'cloud-preview' ? <Loader2 size={15} className="spin" /> : <Download size={15} />}
              从云端导入
            </button>
          </div>
            {fileImportProgress ? (
              <div className="import-progress-card">
                <div>
                  <span>正在导入文件</span>
                  <strong>
                    {fileImportProgress.current}/{fileImportProgress.total}
                  </strong>
                </div>
                <div className="import-progress-track">
                  <span
                    style={{
                      width: `${Math.min(
                        100,
                        fileImportProgress.total > 0
                          ? Math.round((fileImportProgress.current / fileImportProgress.total) * 100)
                          : 0,
                      )}%`,
                    }}
                  />
                </div>
                {fileImportProgress.email ? <small title={fileImportProgress.email}>{fileImportProgress.email}</small> : null}
              </div>
            ) : null}

          <div className="action-group split">
            <button type="button" className="secondary" onClick={refreshAll} disabled={workLocked || accounts.length === 0}>
              {busy === 'refresh-all' || autoRefreshRunning ? <Loader2 size={15} className="spin" /> : <RefreshCw size={15} />}
              刷新全部配额
            </button>
            <button
              type="button"
              className="secondary"
              onClick={exportSelected}
              disabled={workLocked || selectedExportableAccounts.length === 0}
            >
              {busy === 'export' ? <Loader2 size={15} className="spin" /> : <Download size={15} />}
              导出所选账号
            </button>
            <button type="button" className="secondary" onClick={() => setApiServiceOpen(true)} disabled={workLocked}>
              {localAccessState?.running ? <Power size={15} /> : <Server size={15} />}
              API 服务
            </button>
            <button type="button" className="secondary" onClick={openConfig} disabled={workLocked}>
              {busy === 'config' ? <Loader2 size={15} className="spin" /> : <Settings size={15} />}
              打开 config.toml
            </button>
          </div>

          <div className="auto-refresh-box">
            <div className="auto-refresh-head">
              <span><Clock size={14} />自动刷新额度</span>
              {autoRefreshRunning ? <Loader2 size={14} className="spin" /> : null}
            </div>
            <label className="auto-refresh-row">
              <span>频率</span>
              <select value={String(autoRefreshMinutes)} onChange={onAutoRefreshChange}>
                <option value="-1">关闭</option>
                <option value="1">1 分钟</option>
                <option value="2">2 分钟</option>
                <option value="5">5 分钟</option>
                <option value="10">10 分钟</option>
              </select>
            </label>
            <small className={`auto-refresh-status ${autoRefreshStatusTone}`}>
              {autoRefreshRunning ? '正在自动刷新...' : autoRefreshStatus}
            </small>
          </div>

          <div className="sidebar-footer">
            <span>QQ交流群：472994812</span>
            <span className="version-line">
              v{APP_VERSION}
              <button
                type="button"
                className={`version-update-button ${serverUpdate.phase}`}
                onClick={handleServerUpdateAction}
                disabled={serverUpdateBusy}
              >
                {serverUpdateBusy ? <Loader2 size={12} className="spin" /> : serverUpdate.phase === 'downloaded' ? <RefreshCw size={12} /> : null}
                {serverUpdateLabel}
              </button>
            </span>
          </div>
        </aside>

        <section className="content">
          <div className="toolbar">
            <div className="search">
              <Search size={16} />
              <input value={search} onChange={onSearch} placeholder="搜索邮箱、名称、标签、计划或 Base URL" />
            </div>
            <div className="filters">
              {[
                ['all', '全部'],
                ['oauth', 'OAuth'],
                ['agent-identity', 'Agent'],
                ['api-key', 'API Key'],
                ['current', '当前'],
                ['attention', '需关注'],
              ].map(([value, label]) => (
                <button
                  key={value}
                  type="button"
                  className={filter === value ? 'active' : ''}
                  onClick={() => setFilter(value as FilterMode)}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {busy === 'initial' ? (
            <div className="empty">
              <Loader2 className="spin" size={22} />
              正在读取 Codex 账号...
            </div>
          ) : filteredAccounts.length > 0 || showApiServiceCard ? (
            <>
              <div className="account-list-summary">
                <div className="account-selection-left">
                  {selectedAccountIds.length > 0 && attentionCount > 0 ? (
                    <button
                      type="button"
                      className="danger-btn small"
                      onClick={deleteAttentionAccounts}
                      disabled={Boolean(busy)}
                    >
                      {busy === 'delete-errors' ? <Loader2 size={14} className="spin" /> : <Trash2 size={14} />}
                      删除异常账号 {attentionCount}
                    </button>
                  ) : null}
                  {selectedCardCount > 0 && paginatedAccountIds.length > 0 ? (
                    <button
                      type="button"
                      className="secondary small"
                      onClick={togglePaginatedAccountSelection}
                      disabled={Boolean(busy)}
                    >
                      {allPaginatedAccountsSelected ? <X size={14} /> : <Check size={14} />}
                      {allPaginatedAccountsSelected ? '取消当前页' : '全选当前页'}
                    </button>
                  ) : null}
                  {selectedCardCount > 0 && canToggleAllFilteredAccounts ? (
                    <button
                      type="button"
                      className="secondary small"
                      onClick={toggleFilteredAccountSelection}
                      disabled={Boolean(busy)}
                    >
                      {allFilteredAccountsSelected ? <X size={14} /> : <Check size={14} />}
                      {allFilteredAccountsSelected ? '取消全部页' : `全选全部页 ${filteredAccounts.length} 个`}
                    </button>
                  ) : null}
                </div>
                {selectedCardCount > 0 ? (
                  <div className="account-selection-actions">
                    <span>已选 {selectedCardCount}</span>
                    <button
                      type="button"
                      className="icon-btn account-privacy-toggle"
                      onClick={toggleSelectedCardMasking}
                      disabled={Boolean(busy)}
                      title={allSelectedCardsMasked ? '显示所选卡片信息' : '隐藏所选卡片信息'}
                      aria-label={allSelectedCardsMasked ? '显示所选卡片信息' : '隐藏所选卡片信息'}
                    >
                      {allSelectedCardsMasked ? <Eye size={14} /> : <EyeOff size={14} />}
                    </button>
                    <button type="button" className="secondary small" onClick={clearAccountSelection} disabled={Boolean(busy)}>
                      取消选择
                    </button>
                    <button type="button" className="danger-btn small" onClick={deleteSelectedAccounts} disabled={Boolean(busy)}>
                      {busy === 'delete-selected' ? <Loader2 size={14} className="spin" /> : <Trash2 size={14} />}
                      {selectedAccountIds.length > 0 ? '批量删除' : '隐藏卡片'}
                    </button>
                  </div>
                ) : null}
              </div>
              <div className="account-grid">
                {showApiServiceCard ? (
                  <ApiServiceCard
                    state={localAccessState}
                    externalConfig={externalApiServiceConfig}
                    apiMode={apiServiceAddressMode}
                    selectedProxyProfileId={selectedProxyProfileId}
                    busy={busy}
                    appSpeed={apiServiceAppSpeed}
                    selected={apiServiceCardSelected}
                    masked={apiServiceCardMasked}
                    onSpeedChange={saveApiServiceSpeed}
                    onOpen={() => setApiServiceOpen(true)}
                    onOpenAccounts={openApiServiceAccounts}
                    onToggle={toggleApiService}
                    onModeChange={selectApiServiceMode}
                    onProxyProfileChange={changeSelectedProxyProfile}
                    onToggleSelect={() => setApiServiceCardSelected((current) => !current)}
                  />
                ) : null}
                {paginatedAccounts.map((account) => (
                  <AccountCard
                    key={account.id}
                    account={account}
                    current={account.id === currentAccount?.id}
                    busy={busy}
                    onSwitch={switchAccount}
                    onExport={exportAccount}
                    onRefresh={refreshAccount}
                    onEdit={editAccount}
                    onDelete={deleteAccount}
                    onSpeedChange={saveAccountSpeed}
                    selected={selectedAccountSet.has(account.id)}
                    masked={maskedAccountSet.has(account.id)}
                    onToggleSelect={toggleAccountSelection}
                    inApiService={apiServiceAccountSet.has(account.id)}
                    apiServiceRestricted={Boolean(
                      (localAccessState?.collection?.restrictFreeAccounts ?? true)
                      && isFreeAccount(account)
                    )}
                    onToggleApiService={toggleApiServiceMembership}
                  />
                ))}
              </div>
              <PaginationControls
                totalItems={accountPagination.totalItems}
                currentPage={accountPagination.currentPage}
                totalPages={accountPagination.totalPages}
                pageSize={accountPagination.pageSize}
                pageSizeOptions={accountPagination.pageSizeOptions}
                rangeStart={accountPagination.rangeStart}
                rangeEnd={accountPagination.rangeEnd}
                canGoPrevious={accountPagination.canGoPrevious}
                canGoNext={accountPagination.canGoNext}
                onPageSizeChange={accountPagination.setPageSize}
                onPreviousPage={accountPagination.goToPreviousPage}
                onNextPage={accountPagination.goToNextPage}
              />
            </>
          ) : (
            <div className="empty">
              <img className="empty-icon" src={appIcon} alt="" />
              <h2>{accounts.length === 0 ? '还没有 Codex 账号' : '没有匹配的账号'}</h2>
              <p>{accounts.length === 0 ? '从 OAuth、JSON 文件或 API Key 开始导入。' : '换个关键词或筛选条件试试。'}</p>
            </div>
          )}
        </section>
      </section>

      {addMode ? (
        <AddPanel
          mode={addMode}
          onModeChange={setAddMode}
          onClose={() => setAddMode(null)}
          onAccountsImported={upsertAccounts}
          setMessage={setMessage}
        />
      ) : null}

      {apiServiceOpen ? (
        <ApiServicePanel
          accounts={accounts}
          state={localAccessState}
          externalConfig={externalApiServiceConfig}
          apiMode={apiServiceAddressMode}
          selectedProxyProfileId={selectedProxyProfileId}
          busy={busy}
          cardVisible={apiServiceCardVisible}
          appSpeed={apiServiceAppSpeed}
          onClose={() => setApiServiceOpen(false)}
          onApiModeChange={selectApiServiceMode}
          onCardVisibleChange={onApiServiceCardVisibleChange}
          onSpeedChange={saveApiServiceSpeed}
          onExternalConfigChange={setExternalApiServiceConfig}
          onSelectedProxyProfileChange={setSelectedProxyProfileId}
          onCurrentAccountChange={setCurrentAccount}
          onOpenAccounts={openApiServiceAccounts}
          onToggle={toggleApiService}
          setLocalAccessState={setLocalAccessState}
          runBusy={runBusy}
          setMessage={setMessage}
        />
      ) : null}

      {cloudImportPreview ? (
        <CloudImportModal
          preview={cloudImportPreview}
          importing={cloudImportSubmittingSessionId === cloudImportPreview.sessionId}
          progress={cloudImportProgress?.sessionId === cloudImportPreview.sessionId ? cloudImportProgress : null}
          onClose={closeCloudImportPreview}
          onConfirm={confirmCloudImport}
        />
      ) : null}

      {apiServiceAccountsOpen ? (
        <ApiServiceAccountsModal
          accounts={accounts}
          memberIds={localAccessState?.collection?.accountIds ?? []}
          restrictFreeInitial={localAccessState?.collection?.restrictFreeAccounts ?? true}
          busy={busy}
          onClose={() => setApiServiceAccountsOpen(false)}
          onSave={saveApiServiceMembers}
          onRemove={removeApiServiceMember}
        />
      ) : null}

      {editing ? (
        <EditModal
          draft={editing}
          onClose={() => setEditing(null)}
          onAccountUpdated={(account) => upsertAccounts([account])}
          setMessage={setMessage}
        />
      ) : null}

      {exportText ? (
        <div className="modal-backdrop">
          <div className="modal wide">
            <header className="panel-head">
              <div>
                <span>导出账号</span>
                <strong>{exportTitle || 'Codex 账号'}</strong>
              </div>
              <button type="button" onClick={closeExport} aria-label="关闭"><X size={16} /></button>
            </header>
            <div className="export-toolbar">
              <label>
                <span>导出格式</span>
                <select value={exportFormat} onChange={onExportFormatChange}>
                  {EXPORT_FORMAT_OPTIONS.map((option) => (
                    <option
                      key={option.value}
                      value={option.value}
                      disabled={
                        (exportContainsApiKey && option.value !== 'cockpit_tools')
                        || (exportContainsAgentIdentity && option.value === 'cpa')
                      }
                    >
                      {option.label}
                    </option>
                  ))}
                </select>
              </label>
              {canExportSeparateFiles ? (
                <label>
                  <span>导出方式</span>
                  <select value={exportOutputMode} onChange={onExportOutputModeChange}>
                    {EXPORT_OUTPUT_MODE_OPTIONS.map((option) => (
                      <option key={option.value} value={option.value}>{option.label}</option>
                    ))}
                  </select>
                </label>
              ) : null}
              <span className="export-file-name" title={exportTargetText}>{exportTargetText}</span>
            </div>
            {formattedExportDocuments.length > 0 ? (
              <>
                <div className="export-json-actions">
                  <button type="button" className="secondary small" onClick={toggleExportJsonHidden}>
                    {exportJsonHidden ? <Eye size={14} /> : <EyeOff size={14} />}
                    {exportJsonHidden ? '预览' : '关闭'}
                  </button>
                  <button type="button" className="primary small" onClick={saveExport} disabled={exportSaving}>
                    <Download size={14} />
                    {exportSaving ? '保存中...' : '一键下载全部'}
                  </button>
                </div>

                <div className="export-json-card-list">
                  {formattedExportDocuments.map((document, index) => (
                    <div key={document.id} className="export-json-card">
                      <div className="export-json-card-header">
                        <div className="export-json-card-heading">
                          <div className="export-json-card-title">账号 {index + 1}</div>
                          {!exportJsonHidden ? (
                            <div className="export-json-card-subtitle">{document.label}</div>
                          ) : null}
                        </div>
                        <div className="export-json-card-actions">
                          <button
                            type="button"
                            className="secondary small"
                            onClick={() => void saveExportDocument(document)}
                            disabled={Boolean(exportSavingDocumentId) || exportSaving}
                          >
                            <Download size={14} />
                            {exportSavingDocumentId === document.id ? '保存中...' : '下载'}
                          </button>
                        </div>
                      </div>
                      <textarea
                        className="export-json-textarea export-json-card-textarea"
                        readOnly
                        spellCheck={false}
                        value={exportJsonHidden ? maskJsonPreviewContent(document.jsonContent) : document.jsonContent}
                      />
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <>
                <div className="export-json-actions">
                  <button type="button" className="secondary small" onClick={toggleExportJsonHidden}>
                    {exportJsonHidden ? <Eye size={14} /> : <EyeOff size={14} />}
                    {exportJsonHidden ? '预览' : '关闭'}
                  </button>
                  <button type="button" className="secondary small" onClick={copyExport}>
                    {exportCopied ? <Check size={14} /> : <Copy size={14} />}
                    {exportCopied ? '成功' : '复制'}
                  </button>
                  <button type="button" className="primary small" onClick={saveExport} disabled={exportSaving}>
                    <Download size={14} />
                    {exportSaving ? '保存中...' : '下载'}
                  </button>
                </div>
                <textarea
                  className="export-json-textarea"
                  readOnly
                  spellCheck={false}
                  value={exportJsonHidden ? maskJsonPreviewContent(formattedExportJsonContent) : formattedExportJsonContent}
                />
              </>
            )}
            {exportSavedPath ? (
              <div className="export-json-path-box">
                <div className="export-json-path-title">
                  {exportSavedPathIsDirectory ? '保存目录' : '保存路径'}
                </div>
                <div className="export-json-path-value">{exportSavedPath}</div>
                <div className="export-json-path-actions">
                  <button type="button" className="secondary small" onClick={openExportSavedPath}>
                    <FolderOpen size={14} />
                    打开文件夹
                  </button>
                  <button type="button" className="secondary small" onClick={copyExportSavedPath}>
                    {exportPathCopied ? <Check size={14} /> : <Copy size={14} />}
                    {exportPathCopied ? '成功' : '复制'}
                  </button>
                </div>
              </div>
            ) : null}
            <footer className="modal-foot">
              <button type="button" className="secondary" onClick={closeExport}>关闭</button>
            </footer>
          </div>
        </div>
      ) : null}
    </main>
  );
}
