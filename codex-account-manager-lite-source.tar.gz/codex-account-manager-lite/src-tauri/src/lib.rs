use cockpit_core::models::codex::{
    CodexAccount, CodexApiProviderMode, CodexAppSpeed, CodexAppSpeedConfig, CodexQuota, CodexTokens,
};
use cockpit_core::models::codex_local_access::{
    CodexLocalAccessClientBaseUrlHost, CodexLocalAccessPortCleanupResult, CodexLocalAccessState,
};
use cockpit_core::models::InstanceLaunchMode;
use cockpit_core::modules::{
    codex_account, codex_config_format, codex_instance, codex_local_access, codex_model_injector,
    codex_oauth, codex_quota, codex_session_visibility, codex_speed, process,
};
use reqwest::Url;
use std::collections::{HashMap, HashSet};
use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;
use std::sync::Arc;
use std::time::{Duration, SystemTime, UNIX_EPOCH};
use tauri::{AppHandle, Emitter};

const CLOUD_IMPORT_URL: &str = "https://codex.zyxzy.top/manifest.php";
const MAX_CLOUD_IMPORT_FILE_BYTES: usize = 20 * 1024 * 1024;
const MAX_CLOUD_IMPORT_TOTAL_BYTES: usize = 80 * 1024 * 1024;
const MAX_CLOUD_IMPORT_FILES: usize = 50;
const CLOUD_IMPORT_TOKEN_SOURCE_MODE: &str = "cloud_import";
const SERVER_UPDATE_URL: &str = "https://codex.zyxzy.top/update.php";
const DEFAULT_EXTERNAL_API_SERVICE_URL: &str = "https://codex.zyxzy.top/api-service.php";
const MAX_SERVER_UPDATE_PACKAGE_BYTES: usize = 1024 * 1024 * 1024;
const EXTERNAL_API_SERVICE_CONFIG_FILE: &str = "codex_external_api_service.json";
const EXTERNAL_API_SERVICE_SOURCE_MANUAL: &str = "manual";
const EXTERNAL_API_SERVICE_SOURCE_CLOUD: &str = "cloud";
const API_SERVICE_PROVIDER_DISPLAY_NAME: &str = "API 服务";
const LITE_DATA_DIR_ENV: &str = "CODEX_ACCOUNT_MANAGER_LITE_DATA_DIR";
const CORE_DATA_DIR_ENV: &str = "COCKPIT_TOOLS_DATA_DIR";
const LITE_DATA_DIR_NAME: &str = "codex-account-manager-lite";

#[derive(serde::Deserialize)]
#[serde(rename_all = "camelCase")]
struct ExportFilePayload {
    file_name: String,
    content: String,
}

#[derive(serde::Serialize)]
#[serde(rename_all = "camelCase")]
struct CodexCloudImportFailure {
    error: String,
}

#[derive(serde::Serialize)]
#[serde(rename_all = "camelCase")]
struct CodexCloudImportResult {
    imported: Vec<CodexAccount>,
    failed: Vec<CodexCloudImportFailure>,
}

#[derive(Clone, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "camelCase")]
struct CodexExternalApiServiceProfile {
    #[serde(default)]
    id: String,
    #[serde(default)]
    name: String,
    provider_name: Option<String>,
    base_url: String,
    api_key: String,
    #[serde(default = "default_external_api_service_source")]
    source: String,
    #[serde(default)]
    updated_at: i64,
    #[serde(default)]
    last_used_at: Option<i64>,
    #[serde(default)]
    wire_api: String,
    #[serde(default)]
    models: Vec<String>,
    #[serde(default)]
    default_model: String,
    #[serde(default)]
    detected_at: i64,
    #[serde(default)]
    runtime_base_url: String,
}

#[derive(Clone, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "camelCase")]
struct CodexExternalApiServiceStore {
    #[serde(default)]
    profile_id: Option<String>,
    provider_name: Option<String>,
    base_url: String,
    api_key: String,
    #[serde(default = "default_external_api_service_source")]
    source: String,
    #[serde(default)]
    active: bool,
    updated_at: i64,
    #[serde(default)]
    profiles: Vec<CodexExternalApiServiceProfile>,
    #[serde(default)]
    wire_api: String,
    #[serde(default)]
    models: Vec<String>,
    #[serde(default)]
    default_model: String,
    #[serde(default)]
    detected_at: i64,
    #[serde(default)]
    gateway_active: bool,
    #[serde(default)]
    runtime_base_url: String,
}

#[derive(Clone, serde::Serialize)]
#[serde(rename_all = "camelCase")]
struct CodexExternalApiServiceProfileConfig {
    id: String,
    name: String,
    provider_name: Option<String>,
    base_url: String,
    api_key: Option<String>,
    has_api_key: bool,
    source: String,
    active: bool,
    updated_at: i64,
    last_used_at: Option<i64>,
    wire_api: Option<String>,
    models: Vec<String>,
    default_model: Option<String>,
    detected_at: Option<i64>,
}

#[derive(Clone, serde::Serialize)]
#[serde(rename_all = "camelCase")]
struct CodexExternalApiServiceConfig {
    profile_id: Option<String>,
    provider_name: Option<String>,
    base_url: String,
    has_api_key: bool,
    source: String,
    active: bool,
    updated_at: i64,
    profiles: Vec<CodexExternalApiServiceProfileConfig>,
    wire_api: Option<String>,
    models: Vec<String>,
    default_model: Option<String>,
    detected_at: Option<i64>,
}

#[derive(serde::Serialize)]
#[serde(rename_all = "camelCase")]
struct CodexExternalApiServiceActivationResult {
    config: CodexExternalApiServiceConfig,
    state: CodexLocalAccessState,
}

#[derive(Clone)]
struct CodexExternalApiServiceResolvedConfig {
    profile_id: Option<String>,
    profile_name: Option<String>,
    provider_name: Option<String>,
    base_url: String,
    runtime_base_url: String,
    api_key: String,
    source: String,
    wire_api: String,
    models: Vec<String>,
    default_model: String,
    detected_at: i64,
}

struct CodexExternalApiServiceDiscovery {
    runtime_base_url: String,
    wire_api: String,
    models: Vec<String>,
    default_model: String,
    detected_at: i64,
}

struct CloudImportDocument {
    content: String,
}

fn resolve_lite_data_dir() -> PathBuf {
    if let Ok(raw) = std::env::var(LITE_DATA_DIR_ENV) {
        let trimmed = raw.trim();
        if !trimmed.is_empty() {
            return PathBuf::from(trimmed);
        }
    }

    if let Some(data_dir) = dirs::data_dir() {
        return data_dir.join(LITE_DATA_DIR_NAME);
    }

    if let Some(home_dir) = dirs::home_dir() {
        return home_dir.join(".codex_account_manager_lite");
    }

    PathBuf::from(".codex_account_manager_lite")
}

fn configure_lite_data_dir() {
    let data_dir = resolve_lite_data_dir();
    if let Err(error) = fs::create_dir_all(&data_dir) {
        eprintln!(
            "failed to create Codex Account Manager Lite data dir {}: {}",
            data_dir.display(),
            error
        );
    }
    std::env::set_var(CORE_DATA_DIR_ENV, &data_dir);
}

#[derive(Clone, serde::Serialize)]
#[serde(rename_all = "camelCase")]
struct CodexServerUpdateFile {
    name: String,
    url: String,
    size: Option<u64>,
    sha256: Option<String>,
    platform: Option<String>,
    arch: Option<String>,
    kind: Option<String>,
}

#[derive(serde::Serialize)]
#[serde(rename_all = "camelCase")]
struct CodexServerUpdateInfo {
    current_version: String,
    latest_version: String,
    has_update: bool,
    notes: Option<String>,
    download: Option<CodexServerUpdateFile>,
    files: Vec<CodexServerUpdateFile>,
}

#[derive(serde::Deserialize)]
#[serde(rename_all = "camelCase")]
struct ServerUpdateManifest {
    version: Option<String>,
    latest_version: Option<String>,
    notes: Option<String>,
    files: Option<Vec<ServerUpdateFile>>,
}

#[derive(serde::Deserialize)]
#[serde(rename_all = "camelCase")]
struct ServerUpdateFile {
    name: Option<String>,
    url: String,
    size: Option<u64>,
    sha256: Option<String>,
    platform: Option<String>,
    arch: Option<String>,
    kind: Option<String>,
}

fn validate_cloud_import_url(url: &Url) -> Result<(), String> {
    match url.scheme() {
        "https" | "http" => Ok(()),
        scheme => Err(format!("云端导入地址不支持 {} 协议", scheme)),
    }
}

fn parse_cloud_import_url(raw: &str) -> Result<Url, String> {
    let url = Url::parse(raw.trim()).map_err(|error| format!("云端导入地址无效: {}", error))?;
    validate_cloud_import_url(&url)?;
    Ok(url)
}

fn resolve_cloud_import_url(base: &Url, raw: &str) -> Result<Url, String> {
    let trimmed = raw.trim();
    if trimmed.is_empty() {
        return Err("云端导入清单包含空地址".to_string());
    }
    let url = if let Ok(url) = Url::parse(trimmed) {
        url
    } else {
        let last_segment = base.path().rsplit('/').next().unwrap_or("");
        let use_directory_base = !base.path().ends_with('/') && !last_segment.contains('.');
        if use_directory_base {
            let mut directory_base = base.clone();
            directory_base.set_path(&format!("{}/", base.path()));
            directory_base.join(trimmed).or_else(|_| base.join(trimmed))
        } else {
            base.join(trimmed)
        }
        .map_err(|error| format!("云端导入清单地址无效: {}", error))?
    };
    validate_cloud_import_url(&url)?;
    Ok(url)
}

fn json_array_strings(value: &serde_json::Value) -> Option<Vec<String>> {
    let items = value.as_array()?;
    if items.is_empty() || !items.iter().all(|item| item.is_string()) {
        return None;
    }
    Some(
        items
            .iter()
            .filter_map(|item| item.as_str())
            .map(str::trim)
            .filter(|item| !item.is_empty())
            .map(str::to_string)
            .collect(),
    )
}

fn manifest_entries_from_json(text: &str) -> Option<Vec<String>> {
    let value: serde_json::Value = serde_json::from_str(text).ok()?;
    if let Some(entries) = json_array_strings(&value) {
        return Some(entries);
    }
    let object = value.as_object()?;
    for key in ["files", "urls", "jsonFiles", "sources"] {
        if let Some(entries) = object.get(key).and_then(json_array_strings) {
            return Some(entries);
        }
    }
    None
}

fn manifest_entries_from_text(text: &str) -> Option<Vec<String>> {
    let entries: Vec<String> = text
        .lines()
        .map(str::trim)
        .filter(|line| {
            !line.is_empty()
                && !line.starts_with('#')
                && (line.starts_with("http://")
                    || line.starts_with("https://")
                    || line.ends_with(".json")
                    || line.contains(".json?"))
        })
        .map(str::to_string)
        .collect();
    if entries.is_empty() {
        None
    } else {
        Some(entries)
    }
}

fn manifest_entries_from_html(text: &str) -> Option<Vec<String>> {
    let lower = text.to_lowercase();
    if !lower.contains("<html") && !lower.contains("href=") {
        return None;
    }
    let mut entries = Vec::new();
    for part in text.split("href=").skip(1) {
        let rest = part.trim_start();
        let Some(first) = rest.chars().next() else {
            continue;
        };
        let (raw, quoted) = if first == '"' || first == '\'' {
            let end = rest[1..].find(first).map(|index| index + 1);
            (end.map(|index| &rest[1..index]).unwrap_or(""), true)
        } else {
            let end = rest
                .find(|character: char| character.is_whitespace() || character == '>')
                .unwrap_or(rest.len());
            (&rest[..end], false)
        };
        let candidate = raw.trim();
        if candidate.is_empty() {
            continue;
        }
        let candidate_lower = candidate.to_lowercase();
        if candidate_lower.ends_with(".json") || candidate_lower.contains(".json?") {
            entries.push(candidate.to_string());
        } else if !quoted && candidate_lower.contains(".json") {
            entries.push(candidate.to_string());
        }
    }
    if entries.is_empty() {
        None
    } else {
        Some(entries)
    }
}

fn manifest_urls_from_text(base: &Url, text: &str) -> Result<Option<Vec<Url>>, String> {
    let entries = manifest_entries_from_json(text)
        .or_else(|| manifest_entries_from_html(text))
        .or_else(|| manifest_entries_from_text(text));
    let Some(entries) = entries else {
        return Ok(None);
    };
    let mut seen = HashSet::new();
    let mut urls = Vec::new();
    for entry in entries {
        let url = resolve_cloud_import_url(base, &entry)?;
        if seen.insert(url.as_str().to_string()) {
            urls.push(url);
        }
    }
    if urls.len() > MAX_CLOUD_IMPORT_FILES {
        return Err(format!(
            "云端 JSON 文件过多，最多支持 {} 个",
            MAX_CLOUD_IMPORT_FILES
        ));
    }
    Ok(Some(urls))
}

fn parse_version_numbers(value: &str) -> Vec<u64> {
    value
        .trim()
        .trim_start_matches('v')
        .split(|character: char| !character.is_ascii_digit())
        .filter(|part| !part.is_empty())
        .filter_map(|part| part.parse::<u64>().ok())
        .collect()
}

fn is_version_newer(latest: &str, current: &str) -> bool {
    let latest_parts = parse_version_numbers(latest);
    let current_parts = parse_version_numbers(current);
    if latest_parts.is_empty() || current_parts.is_empty() {
        return false;
    }
    let max_len = latest_parts.len().max(current_parts.len());
    for index in 0..max_len {
        let latest_value = latest_parts.get(index).copied().unwrap_or(0);
        let current_value = current_parts.get(index).copied().unwrap_or(0);
        if latest_value > current_value {
            return true;
        }
        if latest_value < current_value {
            return false;
        }
    }
    false
}

fn current_update_platform() -> &'static str {
    #[cfg(target_os = "macos")]
    {
        "macos"
    }
    #[cfg(target_os = "windows")]
    {
        "windows"
    }
    #[cfg(target_os = "linux")]
    {
        "linux"
    }
    #[cfg(not(any(target_os = "macos", target_os = "windows", target_os = "linux")))]
    {
        "unknown"
    }
}

fn current_update_arch() -> &'static str {
    match std::env::consts::ARCH {
        "aarch64" => "arm64",
        "x86_64" => "x86_64",
        other => other,
    }
}

fn normalize_update_platform(value: &str) -> Option<String> {
    let normalized = value.trim().to_ascii_lowercase();
    if normalized.is_empty() {
        return None;
    }
    if normalized.contains("darwin") || normalized.contains("mac") || normalized.ends_with(".dmg") {
        return Some("macos".to_string());
    }
    if normalized.contains("win") || normalized.ends_with(".msi") || normalized.ends_with(".exe") {
        return Some("windows".to_string());
    }
    if normalized.contains("linux")
        || normalized.ends_with(".deb")
        || normalized.ends_with(".appimage")
        || normalized.ends_with(".rpm")
    {
        return Some("linux".to_string());
    }
    None
}

fn normalize_update_arch(value: &str) -> Option<String> {
    let normalized = value.trim().to_ascii_lowercase();
    if normalized.is_empty() {
        return None;
    }
    if normalized.contains("universal") {
        return Some("universal".to_string());
    }
    if normalized.contains("aarch64") || normalized.contains("arm64") {
        return Some("arm64".to_string());
    }
    if normalized.contains("x86_64") || normalized.contains("x64") || normalized.contains("amd64") {
        return Some("x86_64".to_string());
    }
    None
}

fn update_file_kind(value: &str) -> Option<String> {
    let normalized = value.trim().to_ascii_lowercase();
    for (suffix, kind) in [
        (".appimage", "appimage"),
        (".dmg", "dmg"),
        (".msi", "msi"),
        (".exe", "exe"),
        (".deb", "deb"),
        (".rpm", "rpm"),
    ] {
        if normalized.ends_with(suffix) {
            return Some(kind.to_string());
        }
    }
    None
}

fn normalize_update_file(
    base: &Url,
    file: ServerUpdateFile,
) -> Result<CodexServerUpdateFile, String> {
    let url = resolve_cloud_import_url(base, &file.url)?;
    let name = file
        .name
        .or_else(|| {
            url.path_segments()
                .and_then(|mut segments| segments.next_back())
                .map(|value| value.to_string())
        })
        .unwrap_or_else(|| "codex-account-manager-update".to_string());
    let platform = file
        .platform
        .and_then(|value| normalize_update_platform(&value))
        .or_else(|| normalize_update_platform(&name));
    let arch = file
        .arch
        .and_then(|value| normalize_update_arch(&value))
        .or_else(|| normalize_update_arch(&name));
    let kind = file
        .kind
        .and_then(|value| update_file_kind(&value))
        .or_else(|| update_file_kind(&name));

    Ok(CodexServerUpdateFile {
        name,
        url: url.to_string(),
        size: file.size,
        sha256: file.sha256,
        platform,
        arch,
        kind,
    })
}

fn update_kind_score(platform: &str, kind: Option<&str>) -> i32 {
    match (platform, kind.unwrap_or_default()) {
        ("macos", "dmg") => 100,
        ("windows", "exe") => 100,
        ("windows", "msi") => 90,
        ("linux", "appimage") => 100,
        ("linux", "deb") => 90,
        ("linux", "rpm") => 80,
        _ => 0,
    }
}

fn update_arch_score(arch: Option<&str>, current_arch: &str) -> i32 {
    match arch.unwrap_or_default() {
        "universal" => 90,
        value if value == current_arch => 100,
        "" => 50,
        _ => -1000,
    }
}

fn select_update_file(files: &[CodexServerUpdateFile]) -> Option<CodexServerUpdateFile> {
    let platform = current_update_platform();
    let arch = current_update_arch();
    files
        .iter()
        .filter(|file| file.platform.as_deref().unwrap_or(platform) == platform)
        .filter_map(|file| {
            let arch_score = update_arch_score(file.arch.as_deref(), arch);
            if arch_score < 0 {
                return None;
            }
            let kind_score = update_kind_score(platform, file.kind.as_deref());
            Some((arch_score + kind_score, file.clone()))
        })
        .max_by_key(|(score, _)| *score)
        .map(|(_, file)| file)
}

fn safe_update_file_name(file_name: &str) -> String {
    let fallback = "codex-account-manager-update";
    let name = Path::new(file_name)
        .file_name()
        .and_then(|value| value.to_str())
        .unwrap_or(fallback)
        .trim();
    let sanitized: String = name
        .chars()
        .map(|character| {
            if character.is_ascii_alphanumeric()
                || matches!(character, '.' | '_' | '-' | ' ' | '(' | ')')
                || ('\u{4e00}'..='\u{9fff}').contains(&character)
            {
                character
            } else {
                '_'
            }
        })
        .collect();
    if sanitized.trim().is_empty() {
        fallback.to_string()
    } else {
        sanitized
    }
}

fn downloaded_update_dir() -> PathBuf {
    std::env::temp_dir().join("codex-account-manager-lite-updates")
}

fn update_manual_close_marker_path() -> PathBuf {
    downloaded_update_dir().join("manual-close-suppress-relaunch.txt")
}

fn now_unix_ms() -> i64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|duration| duration.as_millis().min(i64::MAX as u128) as i64)
        .unwrap_or(0)
}

fn default_external_api_service_source() -> String {
    EXTERNAL_API_SERVICE_SOURCE_MANUAL.to_string()
}

fn is_cloud_external_api_service_source(source: &str) -> bool {
    source == EXTERNAL_API_SERVICE_SOURCE_CLOUD
}

fn external_api_service_config_path() -> Result<PathBuf, String> {
    Ok(cockpit_core::modules::account::get_data_dir()?.join(EXTERNAL_API_SERVICE_CONFIG_FILE))
}

fn sync_codex_media_mcp_registration() -> Result<bool, String> {
    let external_config_path = external_api_service_config_path()?;
    codex_local_access::sync_media_mcp_registration(&external_config_path)
}

fn sync_codex_media_mcp_registration_with_log(reason: &str) {
    if let Err(error) = sync_codex_media_mcp_registration() {
        cockpit_core::modules::logger::log_warn(&format!(
            "同步 Codex 图片工具失败: reason={}, error={}",
            reason, error
        ));
    }
}

fn normalize_external_api_service_base_url(value: &str) -> Result<String, String> {
    let trimmed = value.trim();
    if trimmed.is_empty() {
        return Err("代理 API 服务缺少 Base URL".to_string());
    }
    let parsed = Url::parse(trimmed)
        .map_err(|_| "代理 API 服务地址需为完整的 http:// 或 https:// Base URL。".to_string())?;
    if parsed.scheme() != "http" && parsed.scheme() != "https" {
        return Err("代理 API 服务地址仅支持 http:// 或 https://。".to_string());
    }
    if parsed.host_str().is_none() {
        return Err("代理 API 服务地址缺少主机。".to_string());
    }
    if parsed.query().is_some() || parsed.fragment().is_some() {
        return Err("代理 API 服务地址不能包含 query 或 fragment。".to_string());
    }
    Ok(parsed.to_string().trim_end_matches('/').to_string())
}

fn external_api_endpoint_url(base_url: &str, endpoint: &str) -> Result<Url, String> {
    let mut url = Url::parse(base_url).map_err(|_| "代理 API 服务地址格式无效。".to_string())?;
    let mut segments: Vec<String> = url
        .path_segments()
        .map(|items| {
            items
                .filter(|item| !item.is_empty())
                .map(str::to_string)
                .collect()
        })
        .unwrap_or_default();
    if segments
        .last()
        .is_some_and(|item| item == "models" || item == "responses")
    {
        segments.pop();
    } else if segments.last().is_some_and(|item| item == "completions") {
        segments.pop();
        if segments.last().is_some_and(|item| item == "chat") {
            segments.pop();
        }
    }
    segments.extend(
        endpoint
            .split('/')
            .filter(|item| !item.is_empty())
            .map(str::to_string),
    );
    url.set_path(&format!("/{}", segments.join("/")));
    url.set_query(None);
    url.set_fragment(None);
    Ok(url)
}

fn external_api_base_url_from_models_url(mut models_url: Url) -> Url {
    let parent_path = models_url
        .path()
        .trim_end_matches('/')
        .strip_suffix("/models")
        .unwrap_or_default()
        .to_string();
    models_url.set_path(if parent_path.is_empty() {
        "/"
    } else {
        &parent_path
    });
    models_url
}

fn external_api_model_catalog_urls(base_url: &str) -> Result<Vec<Url>, String> {
    let normalized_base_url = normalize_external_api_service_base_url(base_url)?;
    let parsed =
        Url::parse(&normalized_base_url).map_err(|_| "代理 API 服务地址格式无效。".to_string())?;
    let mut urls = vec![external_api_endpoint_url(&normalized_base_url, "models")?];
    let trailing_version = parsed
        .path_segments()
        .and_then(|segments| segments.filter(|segment| !segment.is_empty()).last())
        .map(str::to_ascii_lowercase);
    if !trailing_version
        .as_deref()
        .is_some_and(|segment| segment == "v1" || segment == "v1beta")
    {
        let v1_models = external_api_endpoint_url(&normalized_base_url, "v1/models")?;
        if !urls.iter().any(|url| url == &v1_models) {
            urls.push(v1_models);
        }
        let v1beta_models = external_api_endpoint_url(&normalized_base_url, "v1beta/models")?;
        if !urls.iter().any(|url| url == &v1beta_models) {
            urls.push(v1beta_models);
        }
    }
    Ok(urls)
}

fn external_api_model_ids(value: &serde_json::Value) -> Vec<String> {
    let items = value
        .get("data")
        .or_else(|| value.get("models"))
        .and_then(serde_json::Value::as_array)
        .or_else(|| value.as_array());
    let mut seen = HashSet::new();
    items
        .into_iter()
        .flatten()
        .filter_map(|item| {
            item.as_str()
                .or_else(|| item.get("id").and_then(serde_json::Value::as_str))
                .or_else(|| item.get("name").and_then(serde_json::Value::as_str))
        })
        .map(str::trim)
        .map(|model| model.strip_prefix("models/").unwrap_or(model))
        .filter(|model| !model.is_empty() && !external_api_model_is_internal(model))
        .filter(|model| seen.insert(model.to_ascii_lowercase()))
        .map(str::to_string)
        .collect()
}

fn external_api_model_is_internal(model: &str) -> bool {
    model.trim().eq_ignore_ascii_case("codex-auto-review")
}

fn normalize_external_api_models(models: &mut Vec<String>) {
    let mut seen = HashSet::new();
    models.retain_mut(|model| {
        *model = model.trim().to_string();
        !model.is_empty()
            && !external_api_model_is_internal(model)
            && seen.insert(model.to_ascii_lowercase())
    });
}

fn external_api_catalog_is_native_gemini(value: &serde_json::Value) -> bool {
    value
        .get("models")
        .and_then(serde_json::Value::as_array)
        .is_some_and(|models| {
            models.iter().any(|model| {
                model
                    .get("name")
                    .and_then(serde_json::Value::as_str)
                    .is_some_and(|name| {
                        name.trim()
                            .to_ascii_lowercase()
                            .starts_with("models/gemini-")
                    })
            })
        })
}

fn external_api_model_is_conversational(model: &str) -> bool {
    let lower = model.to_ascii_lowercase();
    ![
        "embedding",
        "rerank",
        "moderation",
        "whisper",
        "tts",
        "dall-e",
        "image",
        "jimeng",
        "seedream",
        "seedance",
        "audio",
        "transcribe",
    ]
    .iter()
    .any(|marker| lower.contains(marker))
}

fn select_external_api_default_model(models: &[String]) -> Option<String> {
    if let Some(model) = models
        .iter()
        .find(|model| model.to_ascii_lowercase().contains("grok-4.5"))
    {
        return Some(model.clone());
    }
    models
        .iter()
        .find(|model| {
            !external_api_model_is_internal(model) && external_api_model_is_conversational(model)
        })
        .or_else(|| {
            models
                .iter()
                .find(|model| !external_api_model_is_internal(model))
        })
        .cloned()
}

fn external_api_model_family(model: &str) -> Option<&'static str> {
    let normalized = model.trim().to_ascii_lowercase();
    let model = normalized.rsplit('/').next().unwrap_or(normalized.as_str());
    if model == "cursor" || model.starts_with("cursor-") {
        Some("Cursor")
    } else if model == "grok" || model.starts_with("grok-") {
        Some("Grok")
    } else if model.contains("deepseek") {
        Some("DeepSeek")
    } else if model == "gemini" || model.starts_with("gemini-") {
        Some("Gemini")
    } else if model == "claude" || model.starts_with("claude-") {
        Some("Claude")
    } else if model == "glm"
        || model.starts_with("glm-")
        || model.contains("chatglm")
        || model.contains("zhipu")
    {
        Some("GLM")
    } else if model.contains("kimi") || model.contains("moonshot") {
        Some("Kimi")
    } else if model == "qwen"
        || model.contains("qwen")
        || model.contains("dashscope")
        || model.contains("bailian")
        || model.contains("tongyi")
    {
        Some("Qwen")
    } else if model.contains("jimeng") || model.contains("seedream") || model.contains("seedance") {
        Some("即梦")
    } else if model == "gpt" || model.starts_with("gpt-") {
        Some("GPT")
    } else {
        None
    }
}

fn external_api_models_are_family(models: &[String], family: &str) -> bool {
    models
        .iter()
        .any(|model| external_api_model_family(model) == Some(family))
}

fn external_api_models_are_grok(models: &[String]) -> bool {
    external_api_models_are_family(models, "Grok")
}

fn external_api_models_are_cursor(models: &[String]) -> bool {
    external_api_models_are_family(models, "Cursor")
}

fn external_api_models_are_claude_only(models: &[String]) -> bool {
    let conversational = models
        .iter()
        .filter(|model| external_api_model_is_conversational(model));
    let mut found = false;
    for model in conversational {
        found = true;
        if external_api_model_family(model) != Some("Claude") {
            return false;
        }
    }
    found
}

fn external_api_models_are_gemini(models: &[String]) -> bool {
    external_api_models_are_family(models, "Gemini")
}

fn detected_external_api_provider_name(models: &[String]) -> Option<&'static str> {
    [
        "Cursor", "Grok", "DeepSeek", "Gemini", "Claude", "GLM", "Kimi", "Qwen", "即梦", "GPT",
    ]
    .into_iter()
    .find(|family| external_api_models_are_family(models, family))
}

fn normalize_external_api_metadata(
    provider_name: &mut Option<String>,
    wire_api: &mut String,
    models: &[String],
) {
    *provider_name = detected_external_api_provider_name(models).map(str::to_string);
    if external_api_models_are_grok(models) {
        *wire_api = "responses".to_string();
    } else if !external_api_models_are_claude_only(models) && wire_api == "anthropic" {
        // Mixed catalogs can also contain Claude model names. Older builds
        // treated any Claude entry as a Claude-only service and cached /v1/messages.
        wire_api.clear();
    }
}

fn external_api_prefers_chat_completions(base_url: &str, models: &[String]) -> bool {
    let lower_url = base_url.to_ascii_lowercase();
    if lower_url.contains("/chat/completions") {
        return true;
    }
    if lower_url.contains("/responses") {
        return false;
    }
    let chat_markers = [
        "grok",
        "claude",
        "gemini",
        "deepseek",
        "qwen",
        "kimi",
        "moonshot",
        "glm",
        "mistral",
        "llama",
        "minimax",
        "command-r",
    ];
    if models
        .first()
        .map(|model| model.to_ascii_lowercase())
        .is_some_and(|model| chat_markers.iter().any(|marker| model.contains(marker)))
    {
        return true;
    }
    let conversational: Vec<String> = models
        .iter()
        .filter(|model| external_api_model_is_conversational(model))
        .map(|model| model.to_ascii_lowercase())
        .collect();
    !conversational.is_empty()
        && conversational
            .iter()
            .all(|model| chat_markers.iter().any(|marker| model.contains(marker)))
}

fn select_external_api_wire_api(
    supports_responses: bool,
    supports_chat: bool,
    supports_anthropic: bool,
    base_url: &str,
    models: &[String],
) -> &'static str {
    if external_api_models_are_grok(models) {
        return "responses";
    }
    if external_api_models_are_cursor(models) {
        return if supports_responses || !supports_chat {
            "responses"
        } else {
            "chat_completions"
        };
    }
    if external_api_models_are_claude_only(models) && supports_anthropic {
        return "anthropic";
    }
    let prefers_chat = external_api_prefers_chat_completions(base_url, models);
    match (supports_responses, supports_chat) {
        (true, false) => "responses",
        (false, true) => "chat_completions",
        (true, true) if prefers_chat => "chat_completions",
        (true, true) => "responses",
        (false, false) if prefers_chat => "chat_completions",
        (false, false) => "responses",
    }
}

fn external_api_probe_supported(status: reqwest::StatusCode, body: &str) -> bool {
    if status == reqwest::StatusCode::METHOD_NOT_ALLOWED
        || status == reqwest::StatusCode::UNAUTHORIZED
        || status == reqwest::StatusCode::FORBIDDEN
    {
        return false;
    }
    if status != reqwest::StatusCode::NOT_FOUND {
        return true;
    }
    let lower = body.to_ascii_lowercase();
    lower.contains("model") || lower.contains("required") || lower.contains("input")
}

async fn probe_external_api_endpoint(
    client: &reqwest::Client,
    url: Url,
    api_key: &str,
    anthropic_auth: bool,
) -> bool {
    let mut auth_modes = vec![anthropic_auth, !anthropic_auth];
    auth_modes.dedup();
    for use_anthropic_auth in auth_modes {
        let mut request = client
            .post(url.clone())
            .header(reqwest::header::ACCEPT, "application/json")
            .json(&serde_json::json!({}));
        request = if use_anthropic_auth {
            request
                .header("x-api-key", api_key)
                .header("anthropic-version", "2023-06-01")
        } else {
            request.bearer_auth(api_key)
        };
        let Ok(response) = request.send().await else {
            continue;
        };
        let status = response.status();
        let body = response.text().await.unwrap_or_default();
        if external_api_probe_supported(status, &body) {
            return true;
        }
    }
    false
}

async fn fetch_external_api_models(
    client: &reqwest::Client,
    url: Url,
    api_key: &str,
) -> Result<reqwest::Response, reqwest::Error> {
    let response = client
        .get(url.clone())
        .bearer_auth(api_key)
        .header(reqwest::header::ACCEPT, "application/json")
        .send()
        .await?;
    if response.status() != reqwest::StatusCode::UNAUTHORIZED
        && response.status() != reqwest::StatusCode::FORBIDDEN
    {
        return Ok(response);
    }
    client
        .get(url)
        .header("x-api-key", api_key)
        .header("anthropic-version", "2023-06-01")
        .header(reqwest::header::ACCEPT, "application/json")
        .send()
        .await
}

async fn discover_external_api_service(
    base_url: &str,
    api_key: &str,
) -> Result<CodexExternalApiServiceDiscovery, String> {
    let client = reqwest::Client::builder()
        .timeout(Duration::from_secs(15))
        .redirect(reqwest::redirect::Policy::limited(5))
        .user_agent("codex-account-manager-lite/proxy-discovery")
        .build()
        .map_err(|error| format!("创建代理 API 自动识别客户端失败: {}", error))?;

    let model_urls = external_api_model_catalog_urls(base_url)?;
    let mut discovered = None;
    let mut last_error = String::new();
    for models_url in model_urls {
        match fetch_external_api_models(&client, models_url.clone(), api_key).await {
            Ok(response) if response.status().is_success() => {
                let value = match response.json::<serde_json::Value>().await {
                    Ok(value) => value,
                    Err(error) => {
                        last_error = format!("代理 API /models 返回格式无效: {}", error);
                        continue;
                    }
                };
                let native_gemini = external_api_catalog_is_native_gemini(&value);
                let models = external_api_model_ids(&value);
                if !models.is_empty() {
                    discovered = Some((models_url, models, native_gemini));
                    break;
                }
                last_error = "代理 API /models 未返回模型".to_string();
            }
            Ok(response) => {
                last_error = format!("代理 API /models 返回 {}", response.status());
            }
            Err(error) => last_error = error.to_string(),
        }
    }
    let (models_url, mut models, native_gemini) = discovered.ok_or_else(|| {
        format!(
            "自动识别代理 API 模型失败：{}。请确认地址和 Key 可访问 /models。",
            if last_error.is_empty() {
                "未找到模型接口"
            } else {
                &last_error
            }
        )
    })?;
    let default_model = select_external_api_default_model(&models)
        .ok_or_else(|| "自动识别代理 API 模型失败：没有可用模型。".to_string())?;
    if let Some(index) = models.iter().position(|model| model == &default_model) {
        models.swap(0, index);
    }

    let endpoint_base = external_api_base_url_from_models_url(models_url);
    let runtime_base_url = endpoint_base.to_string().trim_end_matches('/').to_string();
    let wire_api = if native_gemini && external_api_models_are_gemini(&models) {
        "gemini"
    } else if external_api_models_are_grok(&models) {
        "responses"
    } else {
        let responses_url = external_api_endpoint_url(endpoint_base.as_str(), "responses")?;
        let chat_url = external_api_endpoint_url(endpoint_base.as_str(), "chat/completions")?;
        let anthropic_url = external_api_endpoint_url(endpoint_base.as_str(), "messages")?;
        let (supports_responses, supports_chat, supports_anthropic) = tokio::join!(
            probe_external_api_endpoint(&client, responses_url, api_key, false),
            probe_external_api_endpoint(&client, chat_url, api_key, false),
            probe_external_api_endpoint(&client, anthropic_url, api_key, true),
        );
        select_external_api_wire_api(
            supports_responses,
            supports_chat,
            supports_anthropic,
            base_url,
            &models,
        )
    };
    Ok(CodexExternalApiServiceDiscovery {
        runtime_base_url,
        wire_api: wire_api.to_string(),
        models,
        default_model,
        detected_at: now_unix_ms(),
    })
}

async fn auto_detect_external_api_service(
    mut resolved: CodexExternalApiServiceResolvedConfig,
) -> CodexExternalApiServiceResolvedConfig {
    match discover_external_api_service(&resolved.base_url, &resolved.api_key).await {
        Ok(discovery) => {
            if let Some(provider_name) = detected_external_api_provider_name(&discovery.models) {
                resolved.provider_name = Some(provider_name.to_string());
            }
            resolved.runtime_base_url = discovery.runtime_base_url;
            resolved.wire_api = discovery.wire_api;
            resolved.models = discovery.models;
            resolved.default_model = discovery.default_model;
            resolved.detected_at = discovery.detected_at;
        }
        Err(error) => {
            cockpit_core::modules::logger::log_warn(&format!(
                "自动识别代理 API 服务失败，保留原有 Responses 直连逻辑: {}",
                error
            ));
        }
    }
    resolved
}

fn external_api_service_has_model_mapping(config: &CodexExternalApiServiceResolvedConfig) -> bool {
    let default_model = config.default_model.trim();
    !default_model.is_empty()
        && matches!(
            config.wire_api.as_str(),
            "responses" | "chat_completions" | "anthropic" | "gemini"
        )
        && config
            .models
            .iter()
            .any(|model| model.eq_ignore_ascii_case(default_model))
}

fn update_external_api_service_store_discovery(
    store: &mut CodexExternalApiServiceStore,
    resolved: &CodexExternalApiServiceResolvedConfig,
) {
    store.provider_name = resolved.provider_name.clone();
    store.base_url = resolved.base_url.clone();
    store.runtime_base_url = resolved.runtime_base_url.clone();
    store.wire_api = resolved.wire_api.clone();
    store.models = resolved.models.clone();
    store.default_model = resolved.default_model.clone();
    store.detected_at = resolved.detected_at;

    if let Some(profile_id) = store.profile_id.as_deref() {
        if let Some(profile) = store
            .profiles
            .iter_mut()
            .find(|profile| profile.id == profile_id)
        {
            profile.provider_name = resolved.provider_name.clone();
            profile.base_url = resolved.base_url.clone();
            profile.runtime_base_url = resolved.runtime_base_url.clone();
            profile.wire_api = resolved.wire_api.clone();
            profile.models = resolved.models.clone();
            profile.default_model = resolved.default_model.clone();
            profile.detected_at = resolved.detected_at;
        }
    }
}

fn external_api_wire_api_uses_gateway(
    wire_api: &str,
    default_model: &str,
    models: &[String],
) -> bool {
    if default_model.trim().is_empty() || models.is_empty() {
        return false;
    }
    wire_api == "chat_completions"
        || wire_api == "anthropic"
        || wire_api == "gemini"
        || (wire_api == "responses"
            && (external_api_models_are_grok(models) || external_api_models_are_cursor(models)))
}

fn external_api_service_uses_gateway(config: &CodexExternalApiServiceResolvedConfig) -> bool {
    external_api_wire_api_uses_gateway(&config.wire_api, &config.default_model, &config.models)
}

async fn apply_external_api_service(
    config: &CodexExternalApiServiceResolvedConfig,
) -> Result<bool, String> {
    let runtime_base_url = if config.runtime_base_url.trim().is_empty() {
        config.base_url.clone()
    } else {
        normalize_external_api_service_base_url(&config.runtime_base_url)?
    };
    if external_api_service_uses_gateway(config) {
        codex_local_access::activate_external_provider_gateway_for_dir(
            &codex_account::get_codex_home(),
            config.provider_name.clone(),
            runtime_base_url,
            config.api_key.clone(),
            config.wire_api.clone(),
            config.models.clone(),
        )
        .await?;
        let mut index = codex_account::load_account_index();
        index.current_account_id = None;
        codex_account::save_account_index(&index)?;
        return Ok(true);
    }

    codex_account::activate_external_api_provider(
        config.api_key.clone(),
        runtime_base_url,
        Some(API_SERVICE_PROVIDER_DISPLAY_NAME.to_string()),
        &config.models,
        &config.default_model,
    )?;
    Ok(false)
}

fn sync_active_external_direct_model_catalog(
    codex_home: &Path,
    store: &CodexExternalApiServiceStore,
) -> Result<bool, String> {
    if !store.active
        || store.gateway_active
        || store.wire_api != "responses"
        || store.runtime_base_url.is_empty()
        || store.api_key.is_empty()
        || !store
            .models
            .iter()
            .any(|model| model == &store.default_model)
    {
        return Ok(false);
    }
    codex_account::sync_active_external_api_provider_model_catalog(
        codex_home,
        &store.api_key,
        &store.runtime_base_url,
        &store.models,
        &store.default_model,
    )
}

fn json_string_field(value: &serde_json::Value, keys: &[&str]) -> Option<String> {
    let object = value.as_object()?;
    for key in keys {
        let Some(raw) = object.get(*key) else {
            continue;
        };
        if let Some(text) = raw.as_str().map(str::trim).filter(|text| !text.is_empty()) {
            return Some(text.to_string());
        }
    }
    None
}

fn external_api_service_payload<'a>(value: &'a serde_json::Value) -> &'a serde_json::Value {
    let Some(object) = value.as_object() else {
        return value;
    };
    for key in [
        "proxyApiService",
        "apiService",
        "externalApiService",
        "data",
    ] {
        if let Some(child) = object.get(key).filter(|child| child.is_object()) {
            return child;
        }
    }
    value
}

fn validate_external_api_key(api_key: &str, base_url: &str) -> Result<(), String> {
    let trimmed = api_key.trim();
    if trimmed.is_empty() {
        return Err("请输入代理 API 服务的 API Key。".to_string());
    }
    if Url::parse(trimmed).is_ok() {
        return Err("API Key 看起来像 URL，请检查是否填反。".to_string());
    }
    if normalize_external_api_service_base_url(trimmed)
        .ok()
        .as_deref()
        == Some(base_url)
    {
        return Err("API Key 不能与 Base URL 相同。".to_string());
    }
    Ok(())
}

fn normalize_external_api_service_source(source: &str) -> String {
    if is_cloud_external_api_service_source(source) {
        EXTERNAL_API_SERVICE_SOURCE_CLOUD.to_string()
    } else {
        EXTERNAL_API_SERVICE_SOURCE_MANUAL.to_string()
    }
}

fn new_external_api_service_profile_id(index: usize) -> String {
    format!("proxy_api_{}_{}", now_unix_ms(), index)
}

fn external_api_service_profile_config_from_profile(
    profile: &CodexExternalApiServiceProfile,
    active_profile_id: Option<&str>,
    store_active: bool,
) -> CodexExternalApiServiceProfileConfig {
    let source = normalize_external_api_service_source(&profile.source);
    let manual = source == EXTERNAL_API_SERVICE_SOURCE_MANUAL;
    CodexExternalApiServiceProfileConfig {
        id: profile.id.clone(),
        name: profile.name.clone(),
        provider_name: profile.provider_name.clone(),
        base_url: if manual {
            profile.base_url.clone()
        } else {
            String::new()
        },
        api_key: if manual {
            Some(profile.api_key.clone())
        } else {
            None
        },
        has_api_key: !profile.api_key.trim().is_empty(),
        source,
        active: store_active && active_profile_id == Some(profile.id.as_str()),
        updated_at: profile.updated_at,
        last_used_at: profile.last_used_at,
        wire_api: (!profile.wire_api.trim().is_empty()).then(|| profile.wire_api.clone()),
        models: profile.models.clone(),
        default_model: (!profile.default_model.trim().is_empty())
            .then(|| profile.default_model.clone()),
        detected_at: (profile.detected_at > 0).then_some(profile.detected_at),
    }
}

fn normalize_external_api_service_profile(
    mut profile: CodexExternalApiServiceProfile,
    index: usize,
) -> Option<CodexExternalApiServiceProfile> {
    profile.source = normalize_external_api_service_source(&profile.source);
    if profile.source != EXTERNAL_API_SERVICE_SOURCE_MANUAL {
        return None;
    }
    let base_url = normalize_external_api_service_base_url(&profile.base_url).ok()?;
    let api_key = profile.api_key.trim().to_string();
    validate_external_api_key(&api_key, &base_url).ok()?;
    profile.base_url = base_url;
    profile.api_key = api_key;
    profile.name = profile.name.trim().chars().take(80).collect();
    profile.runtime_base_url =
        normalize_external_api_service_base_url(&profile.runtime_base_url).unwrap_or_default();
    if !matches!(
        profile.wire_api.as_str(),
        "responses" | "chat_completions" | "anthropic" | "gemini"
    ) {
        profile.wire_api.clear();
    }
    normalize_external_api_models(&mut profile.models);
    normalize_external_api_metadata(
        &mut profile.provider_name,
        &mut profile.wire_api,
        &profile.models,
    );
    if external_api_model_is_internal(&profile.default_model)
        || !profile
            .models
            .iter()
            .any(|model| model.eq_ignore_ascii_case(profile.default_model.trim()))
    {
        profile.default_model =
            select_external_api_default_model(&profile.models).unwrap_or_default();
    }
    if profile.id.trim().is_empty() {
        profile.id = new_external_api_service_profile_id(index);
    }
    if profile.updated_at <= 0 {
        profile.updated_at = now_unix_ms();
    }
    Some(profile)
}

fn upsert_external_api_service_profile(
    store: &mut CodexExternalApiServiceStore,
    profile_id: Option<String>,
    profile_name: Option<String>,
    provider_name: Option<String>,
    base_url: String,
    runtime_base_url: String,
    api_key: String,
    wire_api: String,
    models: Vec<String>,
    default_model: String,
    detected_at: i64,
    now: i64,
) -> String {
    let existing_index = profile_id
        .as_deref()
        .and_then(|id| store.profiles.iter().position(|profile| profile.id == id))
        .or_else(|| {
            store
                .profiles
                .iter()
                .position(|profile| profile.base_url == base_url && profile.api_key == api_key)
        });
    if let Some(index) = existing_index {
        let id = store.profiles[index].id.clone();
        let name = profile_name
            .as_deref()
            .map(str::trim)
            .filter(|value| !value.is_empty())
            .map(|value| value.chars().take(80).collect())
            .unwrap_or_else(|| store.profiles[index].name.clone());
        store.profiles[index] = CodexExternalApiServiceProfile {
            id: id.clone(),
            name,
            provider_name,
            base_url,
            runtime_base_url,
            api_key,
            source: EXTERNAL_API_SERVICE_SOURCE_MANUAL.to_string(),
            updated_at: now,
            last_used_at: Some(now),
            wire_api,
            models,
            default_model,
            detected_at,
        };
        return id;
    }

    let id =
        profile_id.unwrap_or_else(|| new_external_api_service_profile_id(store.profiles.len()));
    let name = profile_name
        .as_deref()
        .map(str::trim)
        .filter(|value| !value.is_empty())
        .map(|value| value.chars().take(80).collect())
        .unwrap_or_default();
    store.profiles.push(CodexExternalApiServiceProfile {
        id: id.clone(),
        name,
        provider_name,
        base_url,
        runtime_base_url,
        api_key,
        source: EXTERNAL_API_SERVICE_SOURCE_MANUAL.to_string(),
        updated_at: now,
        last_used_at: Some(now),
        wire_api,
        models,
        default_model,
        detected_at,
    });
    id
}

fn normalize_external_api_service_store(
    mut store: CodexExternalApiServiceStore,
) -> CodexExternalApiServiceStore {
    store.source = normalize_external_api_service_source(&store.source);
    if !matches!(
        store.wire_api.as_str(),
        "responses" | "chat_completions" | "anthropic" | "gemini"
    ) {
        store.wire_api.clear();
    }
    store.runtime_base_url =
        normalize_external_api_service_base_url(&store.runtime_base_url).unwrap_or_default();
    normalize_external_api_models(&mut store.models);
    store.profiles = store
        .profiles
        .into_iter()
        .enumerate()
        .filter_map(|(index, profile)| normalize_external_api_service_profile(profile, index))
        .collect();
    normalize_external_api_metadata(&mut store.provider_name, &mut store.wire_api, &store.models);
    if external_api_model_is_internal(&store.default_model)
        || !store
            .models
            .iter()
            .any(|model| model.eq_ignore_ascii_case(store.default_model.trim()))
    {
        store.default_model = select_external_api_default_model(&store.models).unwrap_or_default();
    }

    if store.source == EXTERNAL_API_SERVICE_SOURCE_MANUAL {
        if let Ok(base_url) = normalize_external_api_service_base_url(&store.base_url) {
            let api_key = store.api_key.trim().to_string();
            if validate_external_api_key(&api_key, &base_url).is_ok() {
                let now = if store.updated_at > 0 {
                    store.updated_at
                } else {
                    now_unix_ms()
                };
                let existing_profile_id = store.profile_id.clone();
                let profile_name = existing_profile_id.as_deref().and_then(|profile_id| {
                    store
                        .profiles
                        .iter()
                        .find(|profile| profile.id == profile_id)
                        .map(|profile| profile.name.clone())
                });
                let provider_name = store.provider_name.clone();
                let runtime_base_url = store.runtime_base_url.clone();
                let wire_api = store.wire_api.clone();
                let models = store.models.clone();
                let default_model = store.default_model.clone();
                let detected_at = store.detected_at;
                let profile_id = upsert_external_api_service_profile(
                    &mut store,
                    existing_profile_id,
                    profile_name,
                    provider_name,
                    base_url.clone(),
                    runtime_base_url,
                    api_key.clone(),
                    wire_api,
                    models,
                    default_model,
                    detected_at,
                    now,
                );
                store.profile_id = Some(profile_id);
                store.base_url = base_url;
                store.api_key = api_key;
                store.updated_at = now;
            }
        }
    } else {
        store.profile_id = None;
    }

    store
}

async fn fetch_default_external_api_service_config(
) -> Result<CodexExternalApiServiceResolvedConfig, String> {
    let entry_url = parse_cloud_import_url(DEFAULT_EXTERNAL_API_SERVICE_URL)?;
    let client = reqwest::Client::builder()
        .timeout(Duration::from_secs(20))
        .redirect(reqwest::redirect::Policy::limited(5))
        .user_agent("codex-account-manager-lite/api-service")
        .build()
        .map_err(|error| format!("创建云端代理 API 服务配置客户端失败: {}", error))?;
    let text = fetch_cloud_import_text(&client, &entry_url)
        .await
        .map_err(|error| format!("读取云端代理 API 服务配置失败: {}", error))?;
    let value: serde_json::Value = serde_json::from_str(&text)
        .map_err(|error| format!("云端代理 API 服务配置格式错误: {}", error))?;
    let payload = external_api_service_payload(&value);
    if payload
        .get("enabled")
        .and_then(serde_json::Value::as_bool)
        .is_some_and(|enabled| !enabled)
    {
        return Err("云端代理 API 服务未启用。".to_string());
    }
    let base_url = json_string_field(
        payload,
        &[
            "baseUrl",
            "apiBaseUrl",
            "base_url",
            "api_base_url",
            "url",
            "endpoint",
        ],
    )
    .ok_or_else(|| "云端代理 API 服务缺少 Base URL。".to_string())
    .and_then(|value| normalize_external_api_service_base_url(&value))?;
    let api_key = json_string_field(payload, &["apiKey", "api_key", "key", "token"])
        .ok_or_else(|| "云端代理 API 服务缺少 API Key。".to_string())?;
    validate_external_api_key(&api_key, &base_url)?;

    Ok(CodexExternalApiServiceResolvedConfig {
        profile_id: None,
        profile_name: None,
        provider_name: json_string_field(payload, &["providerName", "provider_name", "name"]),
        base_url: base_url.clone(),
        runtime_base_url: String::new(),
        api_key,
        source: EXTERNAL_API_SERVICE_SOURCE_CLOUD.to_string(),
        wire_api: String::new(),
        models: Vec::new(),
        default_model: String::new(),
        detected_at: 0,
    })
}

fn cached_cloud_external_api_service_config(
    existing: Option<&CodexExternalApiServiceStore>,
) -> Option<CodexExternalApiServiceResolvedConfig> {
    let store = existing?;
    if !is_cloud_external_api_service_source(&store.source) {
        return None;
    }
    let base_url = normalize_external_api_service_base_url(&store.base_url).ok()?;
    let api_key = store.api_key.trim().to_string();
    validate_external_api_key(&api_key, &base_url).ok()?;
    Some(CodexExternalApiServiceResolvedConfig {
        profile_id: None,
        profile_name: None,
        provider_name: store.provider_name.clone(),
        base_url,
        runtime_base_url: store.runtime_base_url.clone(),
        api_key,
        source: EXTERNAL_API_SERVICE_SOURCE_CLOUD.to_string(),
        wire_api: store.wire_api.clone(),
        models: store.models.clone(),
        default_model: store.default_model.clone(),
        detected_at: store.detected_at,
    })
}

async fn resolve_external_api_service_config(
    profile_id: Option<String>,
    profile_name: Option<String>,
    api_key: Option<String>,
    api_base_url: String,
    api_provider_name: Option<String>,
    refresh_cloud_default: bool,
    existing: Option<&CodexExternalApiServiceStore>,
) -> Result<CodexExternalApiServiceResolvedConfig, String> {
    let explicit_base_url = api_base_url.trim();
    let explicit_api_key = api_key
        .as_deref()
        .map(str::trim)
        .filter(|value| !value.is_empty());
    let explicit_provider_name = api_provider_name
        .as_deref()
        .map(str::trim)
        .filter(|value| !value.is_empty())
        .map(str::to_string);
    let explicit_profile_name = profile_name
        .as_deref()
        .map(str::trim)
        .filter(|value| !value.is_empty())
        .map(|value| value.chars().take(80).collect::<String>());
    let explicit_profile_id = profile_id
        .as_deref()
        .map(str::trim)
        .filter(|value| !value.is_empty());
    if let Some(profile_id) = explicit_profile_id {
        let store = existing.ok_or_else(|| "尚未保存代理 API 服务配置。".to_string())?;
        let profile = store
            .profiles
            .iter()
            .find(|profile| profile.id == profile_id)
            .ok_or_else(|| "保存的代理 API 服务配置不存在。".to_string())?;
        if !is_cloud_external_api_service_source(&profile.source) {
            let base_url = normalize_external_api_service_base_url(&profile.base_url)?;
            let api_key = profile.api_key.trim().to_string();
            validate_external_api_key(&api_key, &base_url)?;
            return Ok(CodexExternalApiServiceResolvedConfig {
                profile_id: Some(profile.id.clone()),
                profile_name: Some(profile.name.clone()),
                provider_name: profile.provider_name.clone(),
                base_url,
                runtime_base_url: profile.runtime_base_url.clone(),
                api_key,
                source: EXTERNAL_API_SERVICE_SOURCE_MANUAL.to_string(),
                wire_api: profile.wire_api.clone(),
                models: profile.models.clone(),
                default_model: profile.default_model.clone(),
                detected_at: profile.detected_at,
            });
        }
    }
    let default_request = explicit_base_url.is_empty() && explicit_api_key.is_none();
    let existing_is_cloud = existing
        .map(|store| is_cloud_external_api_service_source(&store.source))
        .unwrap_or(false);
    let cached_cloud_config = if default_request && !refresh_cloud_default {
        cached_cloud_external_api_service_config(existing)
    } else {
        None
    };
    let cloud_config = if default_request && cached_cloud_config.is_none() {
        Some(fetch_default_external_api_service_config().await?)
    } else {
        None
    };
    let default_config = cached_cloud_config.as_ref().or(cloud_config.as_ref());

    let base_url = if explicit_base_url.is_empty() {
        if default_request {
            default_config
                .map(|config| config.base_url.clone())
                .ok_or_else(|| "云端代理 API 服务缺少 Base URL。".to_string())?
        } else {
            existing
                .filter(|_| !existing_is_cloud)
                .map(|store| store.base_url.trim().to_string())
                .filter(|value| !value.is_empty())
                .ok_or_else(|| "代理 API 服务缺少 Base URL。".to_string())?
        }
    } else {
        normalize_external_api_service_base_url(explicit_base_url)?
    };

    let api_key = if let Some(value) = explicit_api_key {
        value.to_string()
    } else if default_request {
        default_config
            .map(|config| config.api_key.clone())
            .ok_or_else(|| "云端代理 API 服务缺少 API Key。".to_string())?
    } else {
        existing
            .filter(|_| !existing_is_cloud)
            .map(|store| store.api_key.trim().to_string())
            .filter(|value| !value.is_empty())
            .ok_or_else(|| "请输入代理 API 服务的 API Key。".to_string())?
    };
    validate_external_api_key(&api_key, &base_url)?;

    let provider_name = explicit_provider_name.or_else(|| {
        if default_request {
            default_config.and_then(|config| config.provider_name.clone())
        } else {
            existing
                .filter(|_| !existing_is_cloud)
                .and_then(|store| store.provider_name.clone())
        }
    });

    Ok(CodexExternalApiServiceResolvedConfig {
        profile_id: None,
        profile_name: explicit_profile_name,
        provider_name,
        base_url,
        runtime_base_url: String::new(),
        api_key,
        source: if default_request {
            default_config
                .map(|config| config.source.clone())
                .unwrap_or_else(|| EXTERNAL_API_SERVICE_SOURCE_CLOUD.to_string())
        } else {
            EXTERNAL_API_SERVICE_SOURCE_MANUAL.to_string()
        },
        wire_api: String::new(),
        models: Vec::new(),
        default_model: String::new(),
        detected_at: 0,
    })
}

fn external_api_service_config_from_store(
    store: &CodexExternalApiServiceStore,
) -> CodexExternalApiServiceConfig {
    let source = if is_cloud_external_api_service_source(&store.source) {
        EXTERNAL_API_SERVICE_SOURCE_CLOUD
    } else {
        EXTERNAL_API_SERVICE_SOURCE_MANUAL
    };
    let profiles = store
        .profiles
        .iter()
        .filter(|profile| !is_cloud_external_api_service_source(&profile.source))
        .map(|profile| {
            external_api_service_profile_config_from_profile(
                profile,
                store.profile_id.as_deref(),
                store.active,
            )
        })
        .collect();
    CodexExternalApiServiceConfig {
        profile_id: store.profile_id.clone(),
        provider_name: store.provider_name.clone(),
        base_url: if source == EXTERNAL_API_SERVICE_SOURCE_CLOUD {
            String::new()
        } else {
            store.base_url.clone()
        },
        has_api_key: !store.api_key.trim().is_empty(),
        source: source.to_string(),
        active: store.active,
        updated_at: store.updated_at,
        profiles,
        wire_api: (!store.wire_api.trim().is_empty()).then(|| store.wire_api.clone()),
        models: store.models.clone(),
        default_model: (!store.default_model.trim().is_empty())
            .then(|| store.default_model.clone()),
        detected_at: (store.detected_at > 0).then_some(store.detected_at),
    }
}

fn load_external_api_service_store() -> Result<Option<CodexExternalApiServiceStore>, String> {
    let path = external_api_service_config_path()?;
    let content = match fs::read_to_string(&path) {
        Ok(content) => content,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(None),
        Err(error) => return Err(format!("读取代理 API 服务配置失败: {}", error)),
    };
    if content.trim().is_empty() {
        return Ok(None);
    }
    serde_json::from_str::<CodexExternalApiServiceStore>(&content)
        .map(normalize_external_api_service_store)
        .map(Some)
        .map_err(|error| format!("解析代理 API 服务配置失败: {}", error))
}

fn save_external_api_service_store(
    store: &CodexExternalApiServiceStore,
) -> Result<CodexExternalApiServiceConfig, String> {
    let path = external_api_service_config_path()?;
    let content = serde_json::to_string_pretty(store)
        .map_err(|error| format!("序列化代理 API 服务配置失败: {}", error))?;
    cockpit_core::modules::atomic_write::write_string_atomic(&path, &content)
        .map_err(|error| format!("写入代理 API 服务配置失败: {}", error))?;
    Ok(external_api_service_config_from_store(store))
}

async fn refresh_cached_cloud_external_api_service_on_startup() {
    let existing = match load_external_api_service_store() {
        Ok(Some(store)) => store,
        Ok(None) => return,
        Err(error) => {
            cockpit_core::modules::logger::log_warn(&format!(
                "启动时读取代理 API 服务缓存失败: {}",
                error
            ));
            return;
        }
    };
    if !is_cloud_external_api_service_source(&existing.source) {
        if existing.active && existing.gateway_active {
            let mut resolved = CodexExternalApiServiceResolvedConfig {
                profile_id: existing.profile_id.clone(),
                profile_name: None,
                provider_name: existing.provider_name.clone(),
                base_url: existing.base_url.clone(),
                runtime_base_url: existing.runtime_base_url.clone(),
                api_key: existing.api_key.clone(),
                source: existing.source.clone(),
                wire_api: existing.wire_api.clone(),
                models: existing.models.clone(),
                default_model: existing.default_model.clone(),
                detected_at: existing.detected_at,
            };
            if resolved.runtime_base_url.trim().is_empty() {
                resolved = auto_detect_external_api_service(resolved).await;
            }
            if resolved.runtime_base_url.trim().is_empty() {
                cockpit_core::modules::logger::log_warn(
                    "启动时无法恢复代理 API 服务：尚未识别实际请求地址",
                );
                return;
            }
            if let Err(error) = apply_external_api_service(&resolved).await {
                cockpit_core::modules::logger::log_warn(&format!(
                    "启动时恢复代理 API 兼容网关失败: {}",
                    error
                ));
            }
        } else if let Err(error) =
            sync_active_external_direct_model_catalog(&codex_account::get_codex_home(), &existing)
        {
            cockpit_core::modules::logger::log_warn(&format!(
                "启动时同步代理 API 模型目录失败: {}",
                error
            ));
        }
        return;
    }

    let mut refreshed = match fetch_default_external_api_service_config().await {
        Ok(config) => config,
        Err(error) => {
            cockpit_core::modules::logger::log_warn(&format!(
                "启动时刷新云端代理 API 服务配置失败: {}",
                error
            ));
            let Some(cached) = cached_cloud_external_api_service_config(Some(&existing)) else {
                return;
            };
            cached
        }
    };
    if refreshed.base_url == existing.base_url && refreshed.api_key == existing.api_key {
        refreshed.wire_api = existing.wire_api.clone();
        refreshed.models = existing.models.clone();
        refreshed.default_model = existing.default_model.clone();
        refreshed.detected_at = existing.detected_at;
        refreshed.runtime_base_url = existing.runtime_base_url.clone();
    }
    let refreshed = auto_detect_external_api_service(refreshed).await;
    if !external_api_service_has_model_mapping(&refreshed)
        || refreshed.runtime_base_url.trim().is_empty()
    {
        return;
    }

    // Discovery can finish after the user has already switched lines.
    if !load_external_api_service_store()
        .ok()
        .flatten()
        .is_some_and(|latest| {
            latest.updated_at == existing.updated_at
                && latest.source == existing.source
                && latest.active == existing.active
                && latest.api_key == existing.api_key
                && latest.base_url == existing.base_url
        })
    {
        return;
    }

    let codex_home = codex_account::get_codex_home();
    let keep_direct_provider = if existing.active
        && !existing.gateway_active
        && !external_api_service_uses_gateway(&refreshed)
        && existing.runtime_base_url == refreshed.runtime_base_url
        && existing.api_key == refreshed.api_key
    {
        match codex_account::sync_active_external_api_provider_model_catalog(
            &codex_home,
            &refreshed.api_key,
            &refreshed.runtime_base_url,
            &refreshed.models,
            &refreshed.default_model,
        ) {
            Ok(synced) => synced,
            Err(error) => {
                cockpit_core::modules::logger::log_warn(&format!(
                    "启动时同步云端代理 API 模型目录失败: {}",
                    error
                ));
                return;
            }
        }
    } else {
        false
    };
    let gateway_active = if existing.active && !keep_direct_provider {
        if existing.gateway_active {
            codex_local_access::stop_provider_gateways_for_profile(&codex_home).await;
        } else if let Err(error) =
            codex_account::deactivate_external_api_provider(Some(existing.api_key.clone()))
        {
            cockpit_core::modules::logger::log_warn(&format!(
                "启动时清理旧云端代理 API 服务配置失败: {}",
                error
            ));
            return;
        }
        match apply_external_api_service(&refreshed).await {
            Ok(value) => value,
            Err(error) => {
                cockpit_core::modules::logger::log_warn(&format!(
                    "启动时应用云端代理 API 服务配置失败: {}",
                    error
                ));
                return;
            }
        }
    } else {
        false
    };

    let store = CodexExternalApiServiceStore {
        profile_id: None,
        provider_name: refreshed.provider_name.clone(),
        base_url: refreshed.base_url.clone(),
        runtime_base_url: refreshed.runtime_base_url.clone(),
        api_key: refreshed.api_key.clone(),
        source: EXTERNAL_API_SERVICE_SOURCE_CLOUD.to_string(),
        active: existing.active,
        updated_at: now_unix_ms(),
        profiles: existing.profiles.clone(),
        wire_api: refreshed.wire_api.clone(),
        models: refreshed.models.clone(),
        default_model: refreshed.default_model.clone(),
        detected_at: refreshed.detected_at,
        gateway_active,
    };
    if let Err(error) = save_external_api_service_store(&store) {
        cockpit_core::modules::logger::log_warn(&format!(
            "启动时保存云端代理 API 服务配置失败: {}",
            error
        ));
        return;
    }

    if !existing.active {
        return;
    }
    let previous_credential_type = current_codex_launch_credential_type();
    match codex_speed::apply_api_service_speed_to_official_state() {
        Ok(speed_config) => {
            if let Err(error) = codex_instance::update_default_app_speed(speed_config.speed) {
                cockpit_core::modules::logger::log_warn(&format!(
                    "启动时更新 Codex 默认实例代理 API 服务速度失败: {}",
                    error
                ));
            }
        }
        Err(error) => cockpit_core::modules::logger::log_warn(&format!(
            "启动时应用代理 API 服务速度失败: {}",
            error
        )),
    }
    if let Err(error) =
        codex_instance::update_default_settings(Some(None), None, Some(false), None, None)
    {
        cockpit_core::modules::logger::log_warn(&format!(
            "启动时清理 Codex 默认实例代理 API 服务绑定失败: {}",
            error
        ));
    }
    repair_codex_session_visibility_after_credential_type_change(
        "startup_refresh_external",
        previous_credential_type,
        Some(CodexLaunchCredentialType::Api),
    );
}

fn set_external_api_service_active(
    active: bool,
) -> Result<Option<CodexExternalApiServiceConfig>, String> {
    let Some(mut store) = load_external_api_service_store()? else {
        return Ok(None);
    };
    if store.active == active {
        return Ok(Some(external_api_service_config_from_store(&store)));
    }
    store.active = active;
    if !active {
        store.gateway_active = false;
    }
    store.updated_at = now_unix_ms();
    save_external_api_service_store(&store).map(Some)
}

fn mark_update_manual_close() {
    let marker_path = update_manual_close_marker_path();
    if let Some(parent) = marker_path.parent() {
        let _ = fs::create_dir_all(parent);
    }
    let _ = fs::write(marker_path, now_unix_ms().to_string());
}

fn validate_downloaded_update_path(path: &Path) -> Result<PathBuf, String> {
    let canonical = path
        .canonicalize()
        .map_err(|error| format!("安装包不存在或不可访问: {}", error))?;
    if !canonical.is_file() {
        return Err("安装包路径不是文件".to_string());
    }
    let update_dir = downloaded_update_dir()
        .canonicalize()
        .map_err(|error| format!("更新目录不可访问: {}", error))?;
    if !canonical.starts_with(&update_dir) {
        return Err("安装包路径不在更新下载目录内".to_string());
    }
    Ok(canonical)
}

#[cfg(target_os = "macos")]
fn current_macos_app_bundle() -> PathBuf {
    if let Ok(exe) = std::env::current_exe() {
        for ancestor in exe.ancestors() {
            if ancestor.extension().and_then(|value| value.to_str()) == Some("app") {
                if ancestor.starts_with("/Volumes") {
                    break;
                }
                return ancestor.to_path_buf();
            }
        }
    }
    PathBuf::from("/Applications/codex账号管理器.app")
}

#[cfg(target_os = "macos")]
fn spawn_macos_update_installer(package_path: &Path, kind: &str) -> Result<(), String> {
    if kind != "dmg" {
        return Err("macOS 更新只支持 .dmg 安装包".to_string());
    }
    let target_app = current_macos_app_bundle();
    let mount_dir = downloaded_update_dir().join(format!("mount-{}", std::process::id()));
    let script = r#"
set -u
DMG="$1"
TARGET_APP="$2"
MOUNT_DIR="$3"
sleep 0.8
rm -rf "$MOUNT_DIR"
mkdir -p "$MOUNT_DIR"
if ! hdiutil attach "$DMG" -nobrowse -readonly -mountpoint "$MOUNT_DIR"; then
  open "$DMG"
  exit 1
fi
APP_PATH="$(find "$MOUNT_DIR" -maxdepth 1 -name '*.app' -type d | head -n 1)"
if [ -z "$APP_PATH" ]; then
  hdiutil detach "$MOUNT_DIR" >/dev/null 2>&1 || true
  open "$DMG"
  exit 1
fi
TARGET_PARENT="$(dirname "$TARGET_APP")"
mkdir -p "$TARGET_PARENT"
BACKUP_APP="${TARGET_APP}.old"
rm -rf "$BACKUP_APP"
if [ -d "$TARGET_APP" ]; then
  mv "$TARGET_APP" "$BACKUP_APP" || true
fi
if ditto "$APP_PATH" "$TARGET_APP"; then
  xattr -dr com.apple.quarantine "$TARGET_APP" >/dev/null 2>&1 || true
  rm -rf "$BACKUP_APP"
  hdiutil detach "$MOUNT_DIR" >/dev/null 2>&1 || true
  open "$TARGET_APP"
else
  if [ -d "$BACKUP_APP" ] && [ ! -d "$TARGET_APP" ]; then
    mv "$BACKUP_APP" "$TARGET_APP" || true
  fi
  hdiutil detach "$MOUNT_DIR" >/dev/null 2>&1 || true
  open "$DMG"
  exit 1
fi
"#;
    Command::new("/bin/sh")
        .arg("-c")
        .arg(script)
        .arg("codex-lite-update")
        .arg(package_path)
        .arg(target_app)
        .arg(mount_dir)
        .spawn()
        .map_err(|error| format!("启动 macOS 更新安装失败: {}", error))?;
    Ok(())
}

#[cfg(target_os = "windows")]
fn spawn_windows_update_installer(package_path: &Path, kind: &str) -> Result<(), String> {
    if kind != "msi" && kind != "exe" {
        return Err("Windows 更新只支持 .msi 或 .exe 安装包".to_string());
    }
    let current_exe =
        std::env::current_exe().map_err(|error| format!("读取当前程序路径失败: {}", error))?;
    let script_path =
        downloaded_update_dir().join(format!("install-update-{}.ps1", std::process::id()));
    let suppress_relaunch_marker = update_manual_close_marker_path();
    let script_started_at = now_unix_ms();
    let script = r#"
param(
  [string]$PackagePath,
  [int]$TargetPid,
  [string]$ExePath,
  [string]$Kind,
  [string]$SuppressRelaunchMarker,
  [Int64]$ScriptStartedAt
)
$ErrorActionPreference = "Stop"
try {
  Wait-Process -Id $TargetPid -Timeout 90 -ErrorAction SilentlyContinue
} catch {}
if ($Kind -eq "msi") {
  $args = @("/i", "`"$PackagePath`"")
  $proc = Start-Process -FilePath "msiexec.exe" -ArgumentList $args -Wait -PassThru
  if ($proc.ExitCode -ne 0 -and $proc.ExitCode -ne 3010) {
    exit $proc.ExitCode
  }
} else {
  $proc = Start-Process -FilePath $PackagePath -Wait -PassThru
  if ($proc.ExitCode -ne 0) {
    exit $proc.ExitCode
  }
}
Start-Sleep -Seconds 1
$shouldRelaunch = $true
try {
  if (Test-Path -LiteralPath $SuppressRelaunchMarker) {
    $markerText = [string](Get-Content -LiteralPath $SuppressRelaunchMarker -Raw -ErrorAction SilentlyContinue)
    $manualCloseAt = [Int64]0
    if ([Int64]::TryParse($markerText.Trim(), [ref]$manualCloseAt) -and $manualCloseAt -ge $ScriptStartedAt) {
      $shouldRelaunch = $false
    }
  }
} catch {}
if ($shouldRelaunch -and (Test-Path -LiteralPath $ExePath)) {
  Start-Process -FilePath $ExePath
}
try {
  Remove-Item -LiteralPath $PSCommandPath -Force -ErrorAction SilentlyContinue
} catch {}
"#;
    fs::write(&script_path, script)
        .map_err(|error| format!("写入 Windows 更新脚本失败: {}", error))?;
    let mut command = Command::new("powershell.exe");
    command
        .arg("-NoProfile")
        .arg("-ExecutionPolicy")
        .arg("Bypass")
        .arg("-File")
        .arg(&script_path)
        .arg("-PackagePath")
        .arg(package_path)
        .arg("-TargetPid")
        .arg(std::process::id().to_string())
        .arg("-ExePath")
        .arg(current_exe)
        .arg("-Kind")
        .arg(kind)
        .arg("-SuppressRelaunchMarker")
        .arg(suppress_relaunch_marker)
        .arg("-ScriptStartedAt")
        .arg(script_started_at.to_string());
    use std::os::windows::process::CommandExt;
    command.creation_flags(0x08000000);
    command
        .spawn()
        .map_err(|error| format!("启动 Windows 更新安装失败: {}", error))?;
    Ok(())
}

#[cfg(target_os = "linux")]
fn spawn_linux_update_installer(package_path: &Path, kind: &str) -> Result<(), String> {
    if !matches!(kind, "appimage" | "deb" | "rpm") {
        return Err("Linux 更新只支持 .AppImage、.deb 或 .rpm 安装包".to_string());
    }
    let current_exe =
        std::env::current_exe().map_err(|error| format!("读取当前程序路径失败: {}", error))?;
    let appimage_path = std::env::var("APPIMAGE").unwrap_or_default();
    let script = r#"
set -u
PACKAGE="$1"
EXE_PATH="$2"
KIND="$3"
TARGET_PID="$4"
APPIMAGE_PATH="$5"
while kill -0 "$TARGET_PID" >/dev/null 2>&1; do
  sleep 0.2
done
case "$KIND" in
  appimage)
    if [ -n "$APPIMAGE_PATH" ]; then
      cp "$PACKAGE" "$APPIMAGE_PATH"
      chmod +x "$APPIMAGE_PATH"
      nohup "$APPIMAGE_PATH" >/dev/null 2>&1 &
    else
      chmod +x "$PACKAGE"
      nohup "$PACKAGE" >/dev/null 2>&1 &
    fi
    ;;
  deb)
    if command -v pkexec >/dev/null 2>&1; then
      pkexec sh -c 'dpkg -i "$1" || apt-get install -f -y' sh "$PACKAGE"
      nohup "$EXE_PATH" >/dev/null 2>&1 &
    elif command -v xdg-open >/dev/null 2>&1; then
      xdg-open "$PACKAGE" >/dev/null 2>&1 &
    else
      exit 1
    fi
    ;;
  rpm)
    if command -v pkexec >/dev/null 2>&1; then
      pkexec rpm -Uvh "$PACKAGE"
      nohup "$EXE_PATH" >/dev/null 2>&1 &
    elif command -v xdg-open >/dev/null 2>&1; then
      xdg-open "$PACKAGE" >/dev/null 2>&1 &
    else
      exit 1
    fi
    ;;
esac
"#;
    Command::new("/bin/sh")
        .arg("-c")
        .arg(script)
        .arg("codex-lite-update")
        .arg(package_path)
        .arg(current_exe)
        .arg(kind)
        .arg(std::process::id().to_string())
        .arg(appimage_path)
        .spawn()
        .map_err(|error| format!("启动 Linux 更新安装失败: {}", error))?;
    Ok(())
}

fn spawn_update_installer(package_path: &Path, kind: &str) -> Result<(), String> {
    #[cfg(target_os = "macos")]
    {
        return spawn_macos_update_installer(package_path, kind);
    }
    #[cfg(target_os = "windows")]
    {
        return spawn_windows_update_installer(package_path, kind);
    }
    #[cfg(target_os = "linux")]
    {
        return spawn_linux_update_installer(package_path, kind);
    }
    #[cfg(not(any(target_os = "macos", target_os = "windows", target_os = "linux")))]
    {
        let _ = (package_path, kind);
        Err("当前平台不支持自动安装更新".to_string())
    }
}

async fn fetch_cloud_import_text(client: &reqwest::Client, url: &Url) -> Result<String, String> {
    let response = client
        .get(url.clone())
        .header(
            reqwest::header::ACCEPT,
            "application/json,text/plain,text/html,*/*",
        )
        .send()
        .await
        .map_err(|error| format!("下载失败: {}", error))?;
    let status = response.status();
    if !status.is_success() {
        return Err(format!("下载失败: HTTP {}", status));
    }
    if let Some(length) = response.content_length() {
        if length > MAX_CLOUD_IMPORT_FILE_BYTES as u64 {
            return Err(format!(
                "文件过大: {:.1} MB",
                length as f64 / 1024.0 / 1024.0
            ));
        }
    }
    let bytes = response
        .bytes()
        .await
        .map_err(|error| format!("读取响应失败: {}", error))?;
    if bytes.len() > MAX_CLOUD_IMPORT_FILE_BYTES {
        return Err(format!(
            "文件过大: {:.1} MB",
            bytes.len() as f64 / 1024.0 / 1024.0
        ));
    }
    String::from_utf8(bytes.to_vec()).map_err(|_| "响应不是 UTF-8 文本".to_string())
}

async fn download_cloud_import_documents(
) -> Result<(Vec<CloudImportDocument>, Vec<CodexCloudImportFailure>), String> {
    let entry = CLOUD_IMPORT_URL.trim();
    if entry.is_empty() {
        return Err("云端导入地址未配置".to_string());
    }
    let entry_url = parse_cloud_import_url(entry)?;
    let client = reqwest::Client::builder()
        .timeout(Duration::from_secs(30))
        .redirect(reqwest::redirect::Policy::limited(5))
        .user_agent("codex-account-manager-lite/cloud-import")
        .build()
        .map_err(|error| format!("创建云端下载客户端失败: {}", error))?;

    let entry_text = fetch_cloud_import_text(&client, &entry_url)
        .await
        .map_err(|error| format!("云端入口下载失败: {}", error))?;

    let urls = manifest_urls_from_text(&entry_url, &entry_text)?;
    let Some(urls) = urls else {
        return Ok((
            vec![CloudImportDocument {
                content: entry_text,
            }],
            Vec::new(),
        ));
    };

    let mut documents = Vec::new();
    let mut failed = Vec::new();
    let mut total_bytes = 0usize;
    for url in urls.iter() {
        match fetch_cloud_import_text(&client, url).await {
            Ok(content) => {
                total_bytes = total_bytes.saturating_add(content.len());
                if total_bytes > MAX_CLOUD_IMPORT_TOTAL_BYTES {
                    failed.push(CodexCloudImportFailure {
                        error: format!(
                            "云端导入总大小超过 {:.0} MB",
                            MAX_CLOUD_IMPORT_TOTAL_BYTES as f64 / 1024.0 / 1024.0
                        ),
                    });
                    break;
                }
                documents.push(CloudImportDocument { content });
            }
            Err(error) => failed.push(CodexCloudImportFailure {
                error: format!("云端内容下载失败: {}", error),
            }),
        }
    }
    Ok((documents, failed))
}

async fn refresh_imported_accounts(accounts: Vec<CodexAccount>) -> Vec<CodexAccount> {
    const MAX_IMPORT_REFRESH_CONCURRENT: usize = 3;

    let mut result = vec![None; accounts.len()];
    let semaphore = Arc::new(tokio::sync::Semaphore::new(MAX_IMPORT_REFRESH_CONCURRENT));
    let mut tasks = tokio::task::JoinSet::new();

    for (index, account) in accounts.into_iter().enumerate() {
        if account.is_api_key_auth() {
            result[index] = Some(account);
            continue;
        }

        let semaphore = semaphore.clone();
        tasks.spawn(async move {
            let account_id = account.id.clone();
            let email = account.email.clone();
            let _permit = semaphore.acquire_owned().await.map_err(|error| {
                cockpit_core::modules::logger::log_warn(&format!(
                    "Codex Lite 导入后刷新配额获取并发许可失败: account_id={}, error={}",
                    account_id, error
                ));
            });

            if let Err(error) = codex_quota::refresh_account_quota(&account_id).await {
                cockpit_core::modules::logger::log_warn(&format!(
                    "Codex Lite 导入后刷新配额失败: account_id={}, email={}, error={}",
                    account_id, email, error
                ));
            }

            (
                index,
                codex_account::load_account(&account_id).unwrap_or(account),
            )
        });
    }

    while let Some(joined) = tasks.join_next().await {
        match joined {
            Ok((index, account)) => result[index] = Some(account),
            Err(error) => cockpit_core::modules::logger::log_warn(&format!(
                "Codex Lite 导入后刷新配额任务失败: {}",
                error
            )),
        }
    }

    result.into_iter().flatten().collect()
}

fn mark_cloud_imported_accounts(mut accounts: Vec<CodexAccount>) -> Vec<CodexAccount> {
    for account in accounts.iter_mut() {
        account.token_source_mode = CLOUD_IMPORT_TOKEN_SOURCE_MODE.to_string();
        if let Err(error) = codex_account::save_account(account) {
            cockpit_core::modules::logger::log_warn(&format!(
                "Codex Lite 云端导入账号来源标记保存失败: account_id={}, error={}",
                account.id, error
            ));
        }
    }
    accounts
}

fn refresh_cloud_imported_accounts_in_background(app: AppHandle, accounts: Vec<CodexAccount>) {
    if accounts.is_empty() {
        return;
    }

    tauri::async_runtime::spawn(async move {
        let refreshed = mark_cloud_imported_accounts(refresh_imported_accounts(accounts).await);
        if !refreshed.is_empty() {
            let _ = app.emit("codex:cloud-import-accounts-refreshed", refreshed);
        }
    });
}

#[tauri::command]
fn list_codex_accounts() -> Vec<CodexAccount> {
    codex_account::list_accounts()
}

#[tauri::command]
fn get_current_codex_account() -> Option<CodexAccount> {
    codex_account::get_current_account()
}

fn repair_codex_session_visibility_after_api_service_switch(reason: &str) {
    match codex_session_visibility::repair_session_visibility_auto_across_instances(
        codex_session_visibility::CodexSessionVisibilityAutoRepairMode::Current,
    ) {
        Ok(summary) => cockpit_core::modules::logger::log_info(&format!(
            "Codex Lite API 服务切换后已修复会话可见性: reason={}, {}",
            reason, summary.message
        )),
        Err(error) => cockpit_core::modules::logger::log_warn(&format!(
            "Codex Lite API 服务切换后修复会话可见性失败: reason={}, error={}",
            reason, error
        )),
    }
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum CodexLaunchCredentialType {
    Account,
    Api,
}

fn codex_account_launch_credential_type(account: &CodexAccount) -> CodexLaunchCredentialType {
    if account.is_api_key_auth() {
        CodexLaunchCredentialType::Api
    } else {
        CodexLaunchCredentialType::Account
    }
}

fn current_codex_launch_credential_type() -> Option<CodexLaunchCredentialType> {
    if let Some(account) = codex_account::get_current_account() {
        return Some(codex_account_launch_credential_type(&account));
    }

    if load_external_api_service_store()
        .ok()
        .flatten()
        .map(|store| store.active)
        .unwrap_or(false)
    {
        return Some(CodexLaunchCredentialType::Api);
    }

    let default_bind_account_id = codex_instance::load_default_settings()
        .ok()
        .and_then(|settings| resolve_default_account_id(&settings));
    let Some(bind_account_id) = default_bind_account_id else {
        return None;
    };

    if codex_instance::is_api_service_bind_account_id(&bind_account_id)
        || codex_instance::parse_provider_gateway_bind_account_id(&bind_account_id).is_some()
    {
        return Some(CodexLaunchCredentialType::Api);
    }

    codex_account::load_account(&bind_account_id)
        .as_ref()
        .map(codex_account_launch_credential_type)
}

fn should_repair_session_visibility_after_credential_type_change(
    previous: Option<CodexLaunchCredentialType>,
    next: Option<CodexLaunchCredentialType>,
) -> bool {
    match (previous, next) {
        (Some(previous), Some(next)) => {
            previous != next
                || previous == CodexLaunchCredentialType::Api
                || next == CodexLaunchCredentialType::Api
        }
        (Some(CodexLaunchCredentialType::Api), None)
        | (None, Some(CodexLaunchCredentialType::Api)) => true,
        _ => false,
    }
}

fn repair_codex_session_visibility_after_credential_type_change(
    reason: &str,
    previous: Option<CodexLaunchCredentialType>,
    next: Option<CodexLaunchCredentialType>,
) {
    if should_repair_session_visibility_after_credential_type_change(previous, next) {
        repair_codex_session_visibility_after_api_service_switch(reason);
    }
}

async fn disable_local_access_for_switch(reason: &str) -> Result<(), String> {
    match codex_local_access::set_local_access_enabled(false).await {
        Ok(_) => Ok(()),
        Err(error) if error.contains("尚未创建") => Ok(()),
        Err(error) => Err(format!("{}失败: {}", reason, error)),
    }
}

async fn stop_codex_runtime_before_account_commit(
    default_dir: std::path::PathBuf,
    launch_mode: InstanceLaunchMode,
) -> Result<(), String> {
    if launch_mode != InstanceLaunchMode::Cli {
        process::close_codex_instances(&[default_dir.to_string_lossy().to_string()], 20)?;
    }
    codex_local_access::stop_provider_gateways_for_profile(&default_dir).await;
    let _ = codex_instance::update_default_pid(None)?;
    Ok(())
}

#[tauri::command]
fn get_codex_config_toml_path() -> String {
    codex_account::get_codex_home()
        .join("config.toml")
        .to_string_lossy()
        .to_string()
}

#[tauri::command]
fn get_codex_auth_json_path() -> String {
    codex_account::get_auth_json_path()
        .to_string_lossy()
        .to_string()
}

fn resolve_default_account_id(
    settings: &cockpit_core::models::DefaultInstanceSettings,
) -> Option<String> {
    if settings.follow_local_account {
        codex_account::get_current_account().map(|account| account.id)
    } else {
        settings.bind_account_id.clone()
    }
}

async fn ensure_provider_gateway_for_bind_account(
    profile_dir: &std::path::Path,
    bind_account_id: Option<&str>,
) -> Result<(), String> {
    let Some(bind_account_id) = bind_account_id else {
        codex_local_access::stop_provider_gateways_for_profile(profile_dir).await;
        return Ok(());
    };

    if codex_instance::is_api_service_bind_account_id(bind_account_id) {
        codex_local_access::stop_provider_gateways_for_profile(profile_dir).await;
        return Ok(());
    }

    let Some(provider_gateway_account_id) =
        codex_instance::parse_provider_gateway_bind_account_id(bind_account_id)
    else {
        let Some(account) = codex_account::load_account(bind_account_id) else {
            codex_local_access::stop_provider_gateways_for_profile(profile_dir).await;
            return Ok(());
        };

        if codex_local_access::account_requires_provider_gateway(&account) {
            codex_local_access::stop_provider_gateways_for_profile(profile_dir).await;
            return codex_local_access::ensure_provider_gateway_for_dir(
                profile_dir,
                bind_account_id,
            )
            .await;
        }

        if codex_local_access::account_requires_bound_oauth_local_gateway(&account) {
            codex_local_access::stop_provider_gateways_for_profile(profile_dir).await;
            return codex_local_access::ensure_bound_oauth_local_gateway_for_dir(
                profile_dir,
                bind_account_id,
            )
            .await;
        }

        codex_local_access::stop_provider_gateways_for_profile(profile_dir).await;
        return Ok(());
    };

    codex_local_access::stop_provider_gateways_for_profile(profile_dir).await;
    codex_local_access::ensure_provider_gateway_for_dir(profile_dir, &provider_gateway_account_id)
        .await
}

#[tauri::command]
async fn switch_codex_account(account_id: String) -> Result<CodexAccount, String> {
    let default_dir = codex_instance::get_default_codex_home()?;
    let default_settings = codex_instance::load_default_settings()?;
    if default_settings.launch_mode != InstanceLaunchMode::Cli {
        process::ensure_codex_launch_path_configured()?;
    }

    let previous_credential_type = current_codex_launch_credential_type();
    if load_external_api_service_store()?
        .as_ref()
        .is_some_and(|store| store.active && store.gateway_active)
    {
        codex_local_access::deactivate_external_provider_gateway_for_dir(
            &codex_account::get_codex_home(),
        )
        .await?;
    }
    disable_local_access_for_switch("切换单账号前停用 API 服务").await?;
    let stop_dir = default_dir.clone();
    let launch_mode = default_settings.launch_mode.clone();
    let account = codex_account::switch_account_managed_with_before_commit(
        &account_id,
        move || async move {
            stop_codex_runtime_before_account_commit(stop_dir, launch_mode).await
        },
    )
    .await?;
    codex_speed::write_official_app_speed(account.app_speed.clone())?;
    let _ = set_external_api_service_active(false);
    if let Err(error) = codex_instance::update_default_settings(
        Some(Some(account.id.clone())),
        None,
        Some(false),
        None,
        None,
    ) {
        cockpit_core::modules::logger::log_warn(&format!(
            "切换单账号后更新 Codex 默认实例绑定账号失败: {}",
            error
        ));
    }
    if let Err(error) = codex_instance::update_default_app_speed(account.app_speed.clone()) {
        cockpit_core::modules::logger::log_warn(&format!(
            "切换单账号后更新 Codex 默认实例速度失败: {}",
            error
        ));
    }
    repair_codex_session_visibility_after_credential_type_change(
        "switch_account",
        previous_credential_type,
        Some(codex_account_launch_credential_type(&account)),
    );
    sync_codex_media_mcp_registration_with_log("switch_account");

    if default_settings.launch_mode != InstanceLaunchMode::Cli {
        let extra_args = process::parse_extra_args(&default_settings.extra_args);
        let pid = process::start_codex_default_fast_after_close(&extra_args)?;
        codex_model_injector::inject_for_codex_home_later(default_dir);
        let _ = codex_instance::update_default_pid(Some(pid))?;
    }

    Ok(account)
}

#[tauri::command]
async fn restart_codex_default_app() -> Result<u32, String> {
    let default_dir = codex_instance::get_default_codex_home()?;
    let default_settings = codex_instance::load_default_settings()?;
    let default_bind_account_id = resolve_default_account_id(&default_settings);
    let external_service = load_external_api_service_store()?.filter(|store| store.active);

    if default_settings.launch_mode != InstanceLaunchMode::Cli {
        process::ensure_codex_launch_path_configured()?;
    }

    process::close_codex_instances(&[default_dir.to_string_lossy().to_string()], 20)?;
    codex_local_access::stop_provider_gateways_for_profile(&default_dir).await;
    let _ = codex_instance::update_default_pid(None)?;
    codex_speed::write_app_speed_for_dir(&default_dir, default_settings.app_speed.clone())?;

    if default_bind_account_id.is_none() && external_service.is_none() {
        codex_local_access::cleanup_provider_gateway_profile_model_overrides(&default_dir)?;
    }
    if let Some(store) =
        external_service.filter(|store| store.gateway_active || default_bind_account_id.is_none())
    {
        if store.gateway_active {
            apply_external_api_service(&CodexExternalApiServiceResolvedConfig {
                profile_id: store.profile_id,
                profile_name: None,
                provider_name: store.provider_name,
                base_url: store.base_url,
                runtime_base_url: store.runtime_base_url,
                api_key: store.api_key,
                source: store.source,
                wire_api: store.wire_api,
                models: store.models,
                default_model: store.default_model,
                detected_at: store.detected_at,
            })
            .await?;
        } else {
            sync_active_external_direct_model_catalog(&default_dir, &store)?;
        }
    } else {
        ensure_provider_gateway_for_bind_account(&default_dir, default_bind_account_id.as_deref())
            .await?;
    }
    codex_local_access::sync_media_mcp_registration_for_dir(
        &default_dir,
        &external_api_service_config_path()?,
    )?;
    codex_config_format::sanitize_codex_config_toml_file(&default_dir.join("config.toml"))?;

    if default_settings.launch_mode == InstanceLaunchMode::Cli {
        let _ = codex_instance::update_default_pid(None)?;
        return Ok(0);
    }

    let extra_args = process::parse_extra_args(&default_settings.extra_args);
    let pid = process::start_codex_default_fast_after_close(&extra_args)?;
    codex_model_injector::inject_for_codex_home_later(default_dir);
    let _ = codex_instance::update_default_pid(Some(pid))?;
    Ok(pid)
}

#[tauri::command]
async fn delete_codex_account(account_id: String) -> Result<(), String> {
    let account_ids = vec![account_id];
    codex_account::remove_account(&account_ids[0])?;
    codex_local_access::remove_deleted_accounts_from_local_access_pool(&account_ids).await?;
    Ok(())
}

#[tauri::command]
async fn delete_codex_accounts(account_ids: Vec<String>) -> Result<(), String> {
    codex_account::remove_accounts(&account_ids)?;
    codex_local_access::remove_deleted_accounts_from_local_access_pool(&account_ids).await?;
    Ok(())
}

#[tauri::command]
async fn import_codex_from_local() -> Result<CodexAccount, String> {
    let account = codex_account::import_from_local()?;
    let mut accounts = refresh_imported_accounts(vec![account]).await;
    accounts
        .pop()
        .ok_or_else(|| "账号导入后无法读取".to_string())
}

#[tauri::command]
async fn import_codex_from_json(json_content: String) -> Result<Vec<CodexAccount>, String> {
    let accounts = codex_account::import_from_json(&json_content).await?;
    Ok(refresh_imported_accounts(accounts).await)
}

#[tauri::command]
async fn import_codex_from_files(
    file_paths: Vec<String>,
) -> Result<codex_account::CodexFileImportResult, String> {
    let result = codex_account::import_from_files(file_paths).await?;
    Ok(codex_account::CodexFileImportResult {
        imported: refresh_imported_accounts(result.imported).await,
        failed: result.failed,
    })
}

#[tauri::command]
async fn preview_codex_cloud_import() -> Result<codex_account::CodexBatchImportPreview, String> {
    let (documents, download_failures) = download_cloud_import_documents().await?;
    if documents.is_empty() {
        let error = download_failures
            .first()
            .map(|failure| failure.error.clone())
            .unwrap_or_else(|| "云端没有可识别的账号内容".to_string());
        return Err(error);
    }
    let contents = documents
        .into_iter()
        .map(|document| ("云端账号".to_string(), document.content))
        .collect();
    codex_account::start_codex_batch_import_from_contents(contents, false).await
}

#[tauri::command]
async fn confirm_codex_cloud_import(
    app: AppHandle,
    session_id: String,
    item_ids: Vec<String>,
) -> Result<CodexCloudImportResult, String> {
    if item_ids.is_empty() {
        return Err("没有选择要导入的云端账号".to_string());
    }
    let result = codex_account::confirm_codex_batch_import(&session_id, &item_ids)?;
    let imported = mark_cloud_imported_accounts(result.imported);
    refresh_cloud_imported_accounts_in_background(app.clone(), imported.clone());
    Ok(CodexCloudImportResult {
        imported,
        failed: result
            .failed
            .into_iter()
            .map(|failure| CodexCloudImportFailure {
                error: failure.error,
            })
            .collect(),
    })
}

#[tauri::command]
fn cancel_codex_cloud_import(session_id: String) -> Result<(), String> {
    codex_account::cancel_codex_batch_import(&session_id)
}

#[tauri::command]
fn export_codex_accounts(account_ids: Vec<String>) -> Result<String, String> {
    if account_ids.is_empty() {
        return Err("没有选择要导出的账号".to_string());
    }
    codex_account::export_accounts(&account_ids)
}

#[tauri::command]
fn save_codex_export_file(file_path: String, content: String) -> Result<(), String> {
    if file_path.trim().is_empty() {
        return Err("保存路径为空".to_string());
    }
    fs::write(&file_path, content).map_err(|error| format!("保存导出文件失败: {}", error))
}

#[tauri::command]
fn save_codex_export_files(
    directory_path: String,
    files: Vec<ExportFilePayload>,
) -> Result<(), String> {
    if directory_path.trim().is_empty() {
        return Err("保存目录为空".to_string());
    }
    if files.is_empty() {
        return Err("没有可保存的导出文件".to_string());
    }

    let directory = Path::new(&directory_path);
    for file in files {
        if file.file_name.trim().is_empty() {
            return Err("导出文件名为空".to_string());
        }
        let file_name = Path::new(&file.file_name)
            .file_name()
            .ok_or_else(|| "导出文件名无效".to_string())?;
        let target = directory.join(file_name);
        fs::write(&target, file.content).map_err(|error| format!("保存导出文件失败: {}", error))?;
    }

    Ok(())
}

#[tauri::command]
async fn check_server_update(current_version: String) -> Result<CodexServerUpdateInfo, String> {
    let update_url = parse_cloud_import_url(SERVER_UPDATE_URL)?;
    let client = reqwest::Client::builder()
        .timeout(Duration::from_secs(20))
        .redirect(reqwest::redirect::Policy::limited(5))
        .user_agent("codex-account-manager-lite/update-check")
        .build()
        .map_err(|error| format!("创建更新检查客户端失败: {}", error))?;
    let text = fetch_cloud_import_text(&client, &update_url)
        .await
        .map_err(|error| format!("服务器更新检查失败: {}", error))?;
    let manifest: ServerUpdateManifest = serde_json::from_str(&text)
        .map_err(|error| format!("服务器更新清单格式错误: {}", error))?;
    let latest_version = manifest
        .latest_version
        .or(manifest.version)
        .unwrap_or_default()
        .trim()
        .trim_start_matches('v')
        .to_string();
    let files = manifest
        .files
        .unwrap_or_default()
        .into_iter()
        .filter_map(|file| normalize_update_file(&update_url, file).ok())
        .collect::<Vec<_>>();
    let download = select_update_file(&files);
    let has_update = !latest_version.is_empty()
        && is_version_newer(&latest_version, &current_version)
        && download.is_some();

    Ok(CodexServerUpdateInfo {
        current_version,
        latest_version,
        has_update,
        notes: manifest.notes,
        download,
        files,
    })
}

#[tauri::command]
async fn download_server_update(url: String, file_name: String) -> Result<String, String> {
    let url = parse_cloud_import_url(&url)?;
    let client = reqwest::Client::builder()
        .timeout(Duration::from_secs(600))
        .redirect(reqwest::redirect::Policy::limited(5))
        .user_agent("codex-account-manager-lite/update-download")
        .build()
        .map_err(|error| format!("创建更新下载客户端失败: {}", error))?;
    let response = client
        .get(url)
        .send()
        .await
        .map_err(|error| format!("下载安装包失败: {}", error))?;
    let status = response.status();
    if !status.is_success() {
        return Err(format!("下载安装包失败: HTTP {}", status));
    }
    if let Some(length) = response.content_length() {
        if length > MAX_SERVER_UPDATE_PACKAGE_BYTES as u64 {
            return Err(format!(
                "安装包过大: {:.1} MB",
                length as f64 / 1024.0 / 1024.0
            ));
        }
    }
    let bytes = response
        .bytes()
        .await
        .map_err(|error| format!("读取安装包失败: {}", error))?;
    if bytes.len() > MAX_SERVER_UPDATE_PACKAGE_BYTES {
        return Err(format!(
            "安装包过大: {:.1} MB",
            bytes.len() as f64 / 1024.0 / 1024.0
        ));
    }

    let update_dir = downloaded_update_dir();
    fs::create_dir_all(&update_dir).map_err(|error| format!("创建更新目录失败: {}", error))?;
    let file_name = safe_update_file_name(&file_name);
    let target = update_dir.join(file_name);
    fs::write(&target, bytes).map_err(|error| format!("保存安装包失败: {}", error))?;
    Ok(target.to_string_lossy().to_string())
}

#[tauri::command]
async fn install_server_update(
    app: AppHandle,
    package_path: String,
    kind: Option<String>,
) -> Result<(), String> {
    let package_path = validate_downloaded_update_path(Path::new(&package_path))?;
    let detected_kind = kind
        .as_deref()
        .and_then(update_file_kind)
        .or_else(|| update_file_kind(&package_path.to_string_lossy()))
        .ok_or_else(|| "无法识别安装包格式".to_string())?;
    let _ = fs::remove_file(update_manual_close_marker_path());
    spawn_update_installer(&package_path, &detected_kind)?;
    app.exit(0);
    Ok(())
}

#[tauri::command]
async fn refresh_codex_quota(account_id: String) -> Result<CodexQuota, String> {
    codex_quota::refresh_account_quota(&account_id).await
}

#[tauri::command]
async fn refresh_all_codex_quotas() -> Result<i32, String> {
    let results = codex_quota::refresh_all_quotas().await?;
    Ok(results.iter().filter(|(_, result)| result.is_ok()).count() as i32)
}

#[tauri::command]
async fn refresh_codex_subscription_info(account_id: String) -> Result<CodexAccount, String> {
    codex_quota::refresh_account_subscription_info(&account_id, true).await
}

#[tauri::command]
async fn refresh_codex_account_profile(account_id: String) -> Result<CodexAccount, String> {
    codex_account::refresh_account_profile(&account_id).await
}

#[tauri::command]
fn add_codex_account_with_token(
    id_token: String,
    access_token: String,
    refresh_token: Option<String>,
) -> Result<CodexAccount, String> {
    let account = codex_account::upsert_account(CodexTokens {
        id_token,
        access_token,
        refresh_token,
    })?;
    codex_account::load_account(&account.id).ok_or_else(|| "账号保存后无法读取".to_string())
}

#[tauri::command]
fn add_codex_account_with_api_key(
    api_key: String,
    api_base_url: Option<String>,
    api_provider_mode: Option<CodexApiProviderMode>,
    api_provider_id: Option<String>,
    api_provider_name: Option<String>,
    api_model_catalog: Option<Vec<String>>,
    api_supports_vision: Option<bool>,
    api_model_vision_support: Option<HashMap<String, bool>>,
    api_vision_routing_model: Option<String>,
    account_name: Option<String>,
    api_wire_api: Option<String>,
) -> Result<CodexAccount, String> {
    let account = codex_account::upsert_api_key_account(
        api_key,
        api_base_url,
        api_provider_mode,
        api_provider_id,
        api_provider_name,
        api_model_catalog.unwrap_or_default(),
        api_wire_api,
        api_supports_vision.unwrap_or(false),
        api_model_vision_support.unwrap_or_default(),
        api_vision_routing_model,
        account_name,
    )?;
    codex_account::load_account(&account.id).ok_or_else(|| "账号保存后无法读取".to_string())
}

#[tauri::command]
fn update_codex_account_name(account_id: String, name: String) -> Result<CodexAccount, String> {
    codex_account::update_account_name(&account_id, name)
}

#[tauri::command]
fn update_codex_account_tags(
    account_id: String,
    tags: Vec<String>,
) -> Result<CodexAccount, String> {
    codex_account::update_account_tags(&account_id, tags)
}

#[tauri::command]
fn update_codex_account_note(account_id: String, note: String) -> Result<CodexAccount, String> {
    codex_account::update_account_note(
        &account_id,
        codex_account::CodexAccountNoteUpdate {
            note: Some(note),
            ..Default::default()
        },
    )
}

#[tauri::command]
fn get_codex_api_service_app_speed_config() -> Result<CodexAppSpeedConfig, String> {
    codex_speed::get_api_service_app_speed_config()
}

#[tauri::command]
fn save_codex_api_service_app_speed(speed: CodexAppSpeed) -> Result<CodexAppSpeedConfig, String> {
    let saved = codex_speed::save_api_service_app_speed(speed.clone())?;
    let external_active = load_external_api_service_store()
        .ok()
        .flatten()
        .map(|store| store.active)
        .unwrap_or(false);
    if let Ok(settings) = codex_instance::load_default_settings() {
        if external_active
            || settings.bind_account_id.as_deref()
                == Some(codex_instance::CODEX_API_SERVICE_BIND_ACCOUNT_ID)
        {
            let _ = codex_instance::update_default_app_speed(speed);
        }
    }
    codex_local_access::trigger_gateway_reload_in_background("保存 API 服务速度配置");
    Ok(saved)
}

#[tauri::command]
fn update_codex_account_app_speed(
    account_id: String,
    speed: CodexAppSpeed,
) -> Result<CodexAccount, String> {
    let account = codex_account::update_account_app_speed(&account_id, speed)?;
    let account_speed = account.app_speed.clone();
    let current_account_id = codex_account::load_account_index().current_account_id;
    let provider_gateway_bind_account_id =
        codex_instance::provider_gateway_bind_account_id(&account_id);
    let default_bind_account_id = codex_instance::load_default_settings()
        .ok()
        .and_then(|settings| settings.bind_account_id);
    let default_bind_matches_provider_gateway = provider_gateway_bind_account_id
        .as_deref()
        .map(|bind_account_id| default_bind_account_id.as_deref() == Some(bind_account_id))
        .unwrap_or(false);

    if current_account_id.as_deref() == Some(account_id.as_str())
        || default_bind_account_id.as_deref() == Some(account_id.as_str())
        || default_bind_matches_provider_gateway
    {
        codex_speed::write_official_app_speed(account_speed.clone())?;
        let _ = codex_instance::update_default_app_speed(account_speed.clone());
        if default_bind_matches_provider_gateway {
            if let Ok(default_dir) = codex_instance::get_default_codex_home() {
                codex_local_access::reload_provider_gateway_for_profile_in_background(
                    default_dir,
                    account_id.clone(),
                    "更新默认 provider gateway 账号速度配置",
                );
            }
        }
    }

    let bound_instances =
        codex_instance::update_bound_instances_app_speed(&account_id, account_speed.clone())?;
    for instance in bound_instances {
        codex_speed::write_app_speed_for_dir(
            Path::new(&instance.user_data_dir),
            account_speed.clone(),
        )?;
    }

    if let Some(provider_gateway_bind_account_id) = provider_gateway_bind_account_id.as_deref() {
        let provider_gateway_bound_instances = codex_instance::update_bound_instances_app_speed(
            provider_gateway_bind_account_id,
            account_speed.clone(),
        )?;
        for instance in provider_gateway_bound_instances {
            codex_speed::write_app_speed_for_dir(
                Path::new(&instance.user_data_dir),
                account_speed.clone(),
            )?;
            codex_local_access::reload_provider_gateway_for_profile_in_background(
                PathBuf::from(instance.user_data_dir),
                account_id.clone(),
                "更新 provider gateway 账号速度配置",
            );
        }
    }

    Ok(account)
}

#[tauri::command]
fn update_codex_api_key_credentials(
    account_id: String,
    api_key: String,
    api_base_url: Option<String>,
    api_provider_mode: Option<CodexApiProviderMode>,
    api_provider_id: Option<String>,
    api_provider_name: Option<String>,
    api_model_catalog: Option<Vec<String>>,
    api_supports_vision: Option<bool>,
    api_model_vision_support: Option<HashMap<String, bool>>,
    api_vision_routing_model: Option<String>,
    api_wire_api: Option<String>,
) -> Result<CodexAccount, String> {
    codex_account::update_api_key_credentials(
        &account_id,
        api_key,
        api_base_url,
        api_provider_mode,
        api_provider_id,
        api_provider_name,
        api_model_catalog.unwrap_or_default(),
        api_wire_api,
        api_supports_vision.unwrap_or(false),
        api_model_vision_support.unwrap_or_default(),
        api_vision_routing_model,
    )
}

#[tauri::command]
async fn codex_oauth_login_start(
    app_handle: AppHandle,
) -> Result<codex_oauth::CodexOAuthLoginStartResponse, String> {
    codex_oauth::start_oauth_login(app_handle).await
}

#[tauri::command]
async fn codex_oauth_login_completed(
    login_id: String,
    reauth_account_id: Option<String>,
) -> Result<CodexAccount, String> {
    let tokens = codex_oauth::complete_oauth_login(&login_id).await?;
    let account = if let Some(account_id) = reauth_account_id
        .as_deref()
        .map(str::trim)
        .filter(|value| !value.is_empty())
    {
        codex_account::upsert_account_for_reauth(tokens, account_id)?
    } else {
        codex_account::upsert_account(tokens)?
    };

    if let Err(error) = codex_quota::refresh_account_quota(&account.id).await {
        cockpit_core::modules::logger::log_warn(&format!(
            "Codex Lite OAuth 后刷新配额失败: account_id={}, error={}",
            account.id, error
        ));
    }

    codex_account::load_account(&account.id).ok_or_else(|| "账号保存后无法读取".to_string())
}

#[tauri::command]
fn codex_oauth_login_cancel(login_id: Option<String>) -> Result<(), String> {
    codex_oauth::cancel_oauth_flow_for(login_id.as_deref())
}

#[tauri::command]
fn codex_oauth_submit_callback_url(
    app_handle: AppHandle,
    login_id: String,
    callback_url: String,
) -> Result<(), String> {
    codex_oauth::submit_callback_url(&login_id, &callback_url)?;
    let payload = serde_json::json!({ "loginId": login_id });
    app_handle
        .emit("codex-oauth-login-completed", payload)
        .map_err(|error| format!("发送 OAuth 完成事件失败: {}", error))
}

#[tauri::command]
async fn codex_local_access_get_state() -> Result<CodexLocalAccessState, String> {
    codex_local_access::get_local_access_state().await
}

#[tauri::command]
async fn codex_local_access_get_state_light() -> Result<CodexLocalAccessState, String> {
    codex_local_access::get_local_access_state_light().await
}

#[tauri::command]
async fn codex_local_access_save_accounts(
    account_ids: Vec<String>,
    restrict_free_accounts: bool,
) -> Result<CodexLocalAccessState, String> {
    codex_local_access::save_local_access_accounts(account_ids, restrict_free_accounts).await
}

#[tauri::command]
async fn codex_local_access_remove_account(
    account_id: String,
) -> Result<CodexLocalAccessState, String> {
    codex_local_access::remove_local_access_account(&account_id).await
}

#[tauri::command]
async fn codex_local_access_rotate_api_key() -> Result<CodexLocalAccessState, String> {
    codex_local_access::rotate_local_access_api_key().await
}

#[tauri::command]
async fn codex_local_access_update_port(port: u16) -> Result<CodexLocalAccessState, String> {
    codex_local_access::update_local_access_port(port).await
}

#[tauri::command]
async fn codex_local_access_update_client_base_url_host(
    client_base_url_host: CodexLocalAccessClientBaseUrlHost,
) -> Result<CodexLocalAccessState, String> {
    codex_local_access::update_local_access_client_base_url_host(client_base_url_host).await
}

#[tauri::command]
async fn get_codex_external_api_service_config(
) -> Result<Option<CodexExternalApiServiceConfig>, String> {
    let Some(mut store) = load_external_api_service_store()? else {
        return Ok(None);
    };
    let resolved = CodexExternalApiServiceResolvedConfig {
        profile_id: store.profile_id.clone(),
        profile_name: None,
        provider_name: store.provider_name.clone(),
        base_url: store.base_url.clone(),
        runtime_base_url: store.runtime_base_url.clone(),
        api_key: store.api_key.clone(),
        source: store.source.clone(),
        wire_api: store.wire_api.clone(),
        models: store.models.clone(),
        default_model: store.default_model.clone(),
        detected_at: store.detected_at,
    };
    if (!external_api_service_has_model_mapping(&resolved)
        || resolved.runtime_base_url.trim().is_empty())
        && validate_external_api_key(&resolved.api_key, &resolved.base_url).is_ok()
    {
        let detected = auto_detect_external_api_service(resolved).await;
        if external_api_service_has_model_mapping(&detected) {
            if let Some(latest) = load_external_api_service_store()? {
                if latest.updated_at == store.updated_at
                    && latest.profile_id == store.profile_id
                    && latest.base_url == store.base_url
                    && latest.api_key == store.api_key
                {
                    store = latest;
                    update_external_api_service_store_discovery(&mut store, &detected);
                    sync_active_external_direct_model_catalog(
                        &codex_account::get_codex_home(),
                        &store,
                    )?;
                    return save_external_api_service_store(&store).map(Some);
                }
                return Ok(Some(external_api_service_config_from_store(&latest)));
            }
            return Ok(None);
        }
    }
    Ok(Some(external_api_service_config_from_store(&store)))
}

#[tauri::command]
async fn activate_codex_external_api_service(
    profile_id: Option<String>,
    profile_name: Option<String>,
    api_key: Option<String>,
    api_base_url: String,
    api_provider_name: Option<String>,
    refresh_cloud_default: Option<bool>,
) -> Result<CodexExternalApiServiceActivationResult, String> {
    let previous_credential_type = current_codex_launch_credential_type();
    let existing = load_external_api_service_store()?;
    let resolved = resolve_external_api_service_config(
        profile_id,
        profile_name,
        api_key,
        api_base_url,
        api_provider_name,
        refresh_cloud_default.unwrap_or(false),
        existing.as_ref(),
    )
    .await?;
    let resolved = auto_detect_external_api_service(resolved).await;
    if !external_api_service_has_model_mapping(&resolved)
        || resolved.runtime_base_url.trim().is_empty()
    {
        return Err(
            "未能识别代理 API 的具体模型或实际请求地址，未保存或切换。请确认 Base URL、API Key 和模型接口可用。"
                .to_string(),
        );
    }

    let codex_home = codex_account::get_codex_home();
    if existing.as_ref().is_some_and(|store| store.gateway_active) {
        codex_local_access::deactivate_external_provider_gateway_for_dir(&codex_home).await?;
    } else {
        codex_local_access::stop_provider_gateways_for_profile(&codex_home).await;
        if let Some(store) = existing.as_ref().filter(|store| store.active) {
            codex_account::deactivate_external_api_provider(Some(store.api_key.clone()))?;
        }
    }
    disable_local_access_for_switch("切换代理 API 服务前停用本地 API 服务").await?;
    let gateway_active = apply_external_api_service(&resolved).await?;
    let speed_config = codex_speed::apply_api_service_speed_to_official_state()?;
    if let Err(error) = codex_instance::update_default_app_speed(speed_config.speed.clone()) {
        cockpit_core::modules::logger::log_warn(&format!(
            "更新 Codex 默认实例代理 API 服务速度失败: {}",
            error
        ));
    }
    if let Err(error) =
        codex_instance::update_default_settings(Some(None), None, Some(false), None, None)
    {
        cockpit_core::modules::logger::log_warn(&format!(
            "清理 Codex 默认实例 API 服务绑定失败: {}",
            error
        ));
    }

    let now = now_unix_ms();
    let mut store = existing.unwrap_or(CodexExternalApiServiceStore {
        profile_id: None,
        provider_name: None,
        base_url: String::new(),
        runtime_base_url: String::new(),
        api_key: String::new(),
        source: EXTERNAL_API_SERVICE_SOURCE_MANUAL.to_string(),
        active: false,
        updated_at: now,
        profiles: Vec::new(),
        wire_api: String::new(),
        models: Vec::new(),
        default_model: String::new(),
        detected_at: 0,
        gateway_active: false,
    });
    store.provider_name = resolved.provider_name.clone();
    store.base_url = resolved.base_url.clone();
    store.runtime_base_url = resolved.runtime_base_url.clone();
    store.api_key = resolved.api_key.clone();
    store.source = resolved.source.clone();
    store.active = true;
    store.updated_at = now;
    store.wire_api = resolved.wire_api.clone();
    store.models = resolved.models.clone();
    store.default_model = resolved.default_model.clone();
    store.detected_at = resolved.detected_at;
    store.gateway_active = gateway_active;
    store.profile_id = if is_cloud_external_api_service_source(&resolved.source) {
        None
    } else {
        Some(upsert_external_api_service_profile(
            &mut store,
            resolved.profile_id.clone(),
            resolved.profile_name,
            resolved.provider_name,
            resolved.base_url,
            resolved.runtime_base_url,
            resolved.api_key,
            resolved.wire_api,
            resolved.models,
            resolved.default_model,
            resolved.detected_at,
            now,
        ))
    };
    let config = save_external_api_service_store(&store)?;
    sync_codex_media_mcp_registration_with_log("activate_external");
    repair_codex_session_visibility_after_credential_type_change(
        "activate_external",
        previous_credential_type,
        Some(CodexLaunchCredentialType::Api),
    );
    let state = codex_local_access::get_local_access_state_light().await?;
    Ok(CodexExternalApiServiceActivationResult { config, state })
}

#[tauri::command]
async fn delete_codex_external_api_service_profile(
    profile_id: String,
) -> Result<CodexExternalApiServiceActivationResult, String> {
    let previous_credential_type = current_codex_launch_credential_type();
    let profile_id = profile_id.trim().to_string();
    if profile_id.is_empty() {
        return Err("请选择要删除的代理 API 服务配置。".to_string());
    }
    let mut store = load_external_api_service_store()?
        .ok_or_else(|| "尚未保存代理 API 服务配置。".to_string())?;
    let index = store
        .profiles
        .iter()
        .position(|profile| profile.id == profile_id)
        .ok_or_else(|| "保存的代理 API 服务配置不存在。".to_string())?;
    let removed = store.profiles.remove(index);
    let removed_active = store.active && store.profile_id.as_deref() == Some(profile_id.as_str());

    if removed_active {
        let codex_home = codex_account::get_codex_home();
        if store.gateway_active {
            codex_local_access::deactivate_external_provider_gateway_for_dir(&codex_home).await?;
        } else {
            codex_local_access::stop_provider_gateways_for_profile(&codex_home).await;
        }
        codex_account::deactivate_external_api_provider(Some(removed.api_key.clone()))?;
        if let Err(error) =
            codex_instance::update_default_settings(Some(None), None, Some(false), None, None)
        {
            cockpit_core::modules::logger::log_warn(&format!(
                "删除当前代理 API 服务配置后清理 Codex 默认实例绑定失败: {}",
                error
            ));
        }
    }

    if store.profile_id.as_deref() == Some(profile_id.as_str()) {
        store.profile_id = None;
        store.provider_name = None;
        store.base_url = String::new();
        store.api_key = String::new();
        store.source = EXTERNAL_API_SERVICE_SOURCE_MANUAL.to_string();
        store.active = false;
        store.wire_api.clear();
        store.models.clear();
        store.default_model.clear();
        store.detected_at = 0;
        store.gateway_active = false;
    }
    store.updated_at = now_unix_ms();

    let config = save_external_api_service_store(&store)?;
    sync_codex_media_mcp_registration_with_log("delete_external_profile");
    if removed_active {
        repair_codex_session_visibility_after_credential_type_change(
            "delete_external_profile",
            previous_credential_type,
            None,
        );
    }
    let state = codex_local_access::get_local_access_state_light().await?;
    Ok(CodexExternalApiServiceActivationResult { config, state })
}

#[tauri::command]
async fn deactivate_codex_external_api_service(
) -> Result<CodexExternalApiServiceActivationResult, String> {
    let previous_credential_type = current_codex_launch_credential_type();
    let existing = load_external_api_service_store()?
        .ok_or_else(|| "尚未保存代理 API 服务配置。".to_string())?;
    let codex_home = codex_account::get_codex_home();
    if existing.gateway_active {
        codex_local_access::deactivate_external_provider_gateway_for_dir(&codex_home).await?;
    } else {
        codex_local_access::stop_provider_gateways_for_profile(&codex_home).await;
    }
    codex_account::deactivate_external_api_provider(Some(existing.api_key.clone()))?;
    let config = set_external_api_service_active(false)?
        .ok_or_else(|| "尚未保存代理 API 服务配置。".to_string())?;
    sync_codex_media_mcp_registration_with_log("deactivate_external");

    if let Err(error) =
        codex_instance::update_default_settings(Some(None), None, Some(false), None, None)
    {
        cockpit_core::modules::logger::log_warn(&format!(
            "清理 Codex 默认实例代理 API 服务绑定失败: {}",
            error
        ));
    }

    repair_codex_session_visibility_after_credential_type_change(
        "deactivate_external",
        previous_credential_type,
        None,
    );

    let state = codex_local_access::get_local_access_state_light().await?;
    Ok(CodexExternalApiServiceActivationResult { config, state })
}

#[tauri::command]
async fn codex_local_access_set_enabled(enabled: bool) -> Result<CodexLocalAccessState, String> {
    let previous_credential_type = current_codex_launch_credential_type();
    let state = codex_local_access::set_local_access_enabled(enabled).await?;
    repair_codex_session_visibility_after_credential_type_change(
        if enabled {
            "set_enabled"
        } else {
            "set_disabled"
        },
        previous_credential_type,
        enabled.then_some(CodexLaunchCredentialType::Api),
    );
    sync_codex_media_mcp_registration_with_log(if enabled {
        "enable_local_access"
    } else {
        "disable_local_access"
    });
    Ok(state)
}

#[tauri::command]
async fn codex_local_access_kill_port() -> Result<CodexLocalAccessPortCleanupResult, String> {
    codex_local_access::kill_local_access_port_processes().await
}

#[tauri::command]
async fn codex_local_access_activate() -> Result<CodexLocalAccessState, String> {
    let previous_credential_type = current_codex_launch_credential_type();
    let codex_home = codex_account::get_codex_home();
    if let Some(external) = load_external_api_service_store()?.filter(|store| store.active) {
        if external.gateway_active {
            codex_local_access::deactivate_external_provider_gateway_for_dir(&codex_home).await?;
        } else {
            codex_local_access::stop_provider_gateways_for_profile(&codex_home).await;
        }
        codex_account::deactivate_external_api_provider(Some(external.api_key))?;
    }
    let state = codex_local_access::activate_local_access_for_dir(&codex_home).await?;

    let api_service_speed = codex_speed::get_api_service_app_speed_config()?.speed;
    codex_speed::write_official_app_speed(api_service_speed.clone())?;
    let _ = set_external_api_service_active(false);

    let mut index = codex_account::load_account_index();
    index.current_account_id = None;
    codex_account::save_account_index(&index)?;

    if let Err(error) = codex_instance::update_default_settings(
        Some(Some(
            codex_instance::CODEX_API_SERVICE_BIND_ACCOUNT_ID.to_string(),
        )),
        None,
        Some(false),
        None,
        None,
    ) {
        cockpit_core::modules::logger::log_warn(&format!(
            "更新 Codex 默认实例为 API 服务模式失败: {}",
            error
        ));
    }
    if let Err(error) = codex_instance::update_default_app_speed(api_service_speed) {
        cockpit_core::modules::logger::log_warn(&format!(
            "更新 Codex 默认实例 API 服务速度失败: {}",
            error
        ));
    }

    repair_codex_session_visibility_after_credential_type_change(
        "activate",
        previous_credential_type,
        Some(CodexLaunchCredentialType::Api),
    );
    sync_codex_media_mcp_registration_with_log("activate_local_access");

    Ok(state)
}

#[cfg(test)]
mod tests {
    use super::{
        detected_external_api_provider_name, external_api_base_url_from_models_url,
        external_api_catalog_is_native_gemini, external_api_model_catalog_urls,
        external_api_model_ids, external_api_prefers_chat_completions,
        external_api_wire_api_uses_gateway, normalize_external_api_metadata,
        select_external_api_default_model, select_external_api_wire_api,
        should_repair_session_visibility_after_credential_type_change, CodexLaunchCredentialType,
    };
    use serde_json::json;

    #[test]
    fn proxy_discovery_uses_detected_v1_base_url() {
        let model_urls = external_api_model_catalog_urls("https://example.com").unwrap();
        assert_eq!(model_urls.len(), 3);
        assert_eq!(model_urls[0].as_str(), "https://example.com/models");
        assert_eq!(model_urls[1].as_str(), "https://example.com/v1/models");
        assert_eq!(model_urls[2].as_str(), "https://example.com/v1beta/models");

        let v1_model_urls = external_api_model_catalog_urls("https://example.com/v1").unwrap();
        assert_eq!(v1_model_urls.len(), 1);
        assert_eq!(v1_model_urls[0].as_str(), "https://example.com/v1/models");

        let v1beta_model_urls =
            external_api_model_catalog_urls("https://example.com/v1beta").unwrap();
        assert_eq!(v1beta_model_urls.len(), 1);
        assert_eq!(
            v1beta_model_urls[0].as_str(),
            "https://example.com/v1beta/models"
        );

        let models_url = reqwest::Url::parse("https://example.com/v1/models").unwrap();
        assert_eq!(
            external_api_base_url_from_models_url(models_url).as_str(),
            "https://example.com/v1"
        );
    }

    #[test]
    fn proxy_discovery_reads_openai_compatible_model_catalog() {
        let models = external_api_model_ids(&json!({
            "data": [
                { "id": "grok-4" },
                { "id": "grok-4.5" },
                { "id": "grok-4.5" }
            ]
        }));
        assert_eq!(models, vec!["grok-4", "grok-4.5"]);
    }

    #[test]
    fn proxy_discovery_filters_internal_models_and_selects_visible_default() {
        let models = external_api_model_ids(&json!({
            "data": [
                { "id": "codex-auto-review" },
                { "id": "gpt-5.6-sol" },
                { "id": "gpt-5.6-terra" }
            ]
        }));
        assert_eq!(models, vec!["gpt-5.6-sol", "gpt-5.6-terra"]);
        assert_eq!(
            select_external_api_default_model(&models).as_deref(),
            Some("gpt-5.6-sol")
        );
        assert_eq!(detected_external_api_provider_name(&models), Some("GPT"));
    }

    #[test]
    fn proxy_discovery_reads_native_gemini_catalog() {
        let catalog = json!({
            "models": [
                { "name": "models/gemini-2.5-pro" },
                { "name": "models/gemini-2.5-flash" }
            ]
        });
        assert!(external_api_catalog_is_native_gemini(&catalog));
        assert_eq!(
            external_api_model_ids(&catalog),
            vec!["gemini-2.5-pro", "gemini-2.5-flash"]
        );
        let models = external_api_model_ids(&catalog);
        assert_eq!(detected_external_api_provider_name(&models), Some("Gemini"));
        assert!(external_api_wire_api_uses_gateway(
            "gemini",
            "gemini-2.5-pro",
            &models
        ));
    }

    #[test]
    fn proxy_discovery_selects_grok_4_5_as_mapping_target() {
        let models = vec!["grok-4".to_string(), "grok-4.5".to_string()];
        let mut provider_name = Some("grok".to_string());
        let mut wire_api = "chat_completions".to_string();
        normalize_external_api_metadata(&mut provider_name, &mut wire_api, &models);
        assert_eq!(provider_name.as_deref(), Some("Grok"));
        assert_eq!(wire_api, "responses");
        assert_eq!(
            select_external_api_default_model(&models).as_deref(),
            Some("grok-4.5")
        );
        assert!(external_api_prefers_chat_completions(
            "http://127.0.0.1:3000/v1",
            &models
        ));
        assert_eq!(detected_external_api_provider_name(&models), Some("Grok"));
        assert_eq!(
            select_external_api_wire_api(true, true, false, "http://127.0.0.1:3000/v1", &models),
            "responses"
        );
        assert_eq!(
            select_external_api_wire_api(false, true, false, "http://127.0.0.1:3000/v1", &models),
            "responses"
        );
        assert_eq!(
            select_external_api_wire_api(false, false, false, "http://127.0.0.1:3000/v1", &models),
            "responses"
        );
        assert!(external_api_wire_api_uses_gateway(
            "responses",
            "grok-4.5",
            &models
        ));
    }

    #[test]
    fn proxy_discovery_keeps_gpt_on_responses_path() {
        let models = vec!["gpt-5.6-terra".to_string(), "gpt-5.6-sol".to_string()];
        assert!(!external_api_prefers_chat_completions(
            "https://example.com/v1",
            &models
        ));
        assert_eq!(detected_external_api_provider_name(&models), Some("GPT"));
        assert_eq!(
            select_external_api_wire_api(true, true, false, "https://example.com/v1", &models),
            "responses"
        );
        assert!(!external_api_wire_api_uses_gateway(
            "responses",
            "gpt-5.6-sol",
            &models
        ));
    }

    #[test]
    fn cursor_responses_service_uses_provider_gateway_for_model_mapping() {
        let models = vec![
            "cursor-grok-4.5-high".to_string(),
            "claude-sonnet-5-max".to_string(),
        ];
        assert!(external_api_wire_api_uses_gateway(
            "responses",
            "cursor-grok-4.5-high",
            &models
        ));
    }

    #[test]
    fn proxy_discovery_recognizes_supported_provider_families() {
        for (model, family) in [
            ("cursor-grok-4.5-high", "Cursor"),
            ("deepseek-chat", "DeepSeek"),
            ("gemini-2.5-pro", "Gemini"),
            ("models/gemini-2.5-flash", "Gemini"),
            ("claude-sonnet-4-6", "Claude"),
            ("glm-5", "GLM"),
            ("kimi-k2.5", "Kimi"),
            ("qwen3-coder-plus", "Qwen"),
            ("doubao-seedream-4-0", "即梦"),
        ] {
            assert_eq!(
                detected_external_api_provider_name(&[model.to_string()]),
                Some(family)
            );
        }
    }

    #[test]
    fn proxy_discovery_prefers_anthropic_messages_for_claude() {
        let models = vec!["claude-sonnet-4-6".to_string()];
        assert_eq!(
            select_external_api_wire_api(true, true, true, "https://api.anthropic.com/v1", &models),
            "anthropic"
        );
        assert!(external_api_wire_api_uses_gateway(
            "anthropic",
            "claude-sonnet-4-6",
            &models
        ));
    }

    #[test]
    fn proxy_discovery_keeps_mixed_cursor_catalog_off_anthropic_messages() {
        let models = vec![
            "cursor-grok-4.5-high".to_string(),
            "claude-sonnet-5-max".to_string(),
            "gemini-3.1-pro".to_string(),
            "gpt-5.6-sol-max".to_string(),
        ];
        assert_eq!(detected_external_api_provider_name(&models), Some("Cursor"));
        assert_eq!(
            select_external_api_wire_api(true, true, true, "https://example.com", &models),
            "responses"
        );
        assert_eq!(
            select_external_api_wire_api(false, true, true, "https://example.com", &models),
            "chat_completions"
        );
        assert_eq!(
            select_external_api_wire_api(false, false, true, "https://example.com", &models),
            "responses"
        );

        let mut provider_name = Some("Claude".to_string());
        let mut wire_api = "anthropic".to_string();
        normalize_external_api_metadata(&mut provider_name, &mut wire_api, &models);
        assert_eq!(provider_name.as_deref(), Some("Cursor"));
        assert!(wire_api.is_empty());
    }

    #[test]
    fn api_to_api_switch_still_repairs_session_visibility() {
        assert!(
            should_repair_session_visibility_after_credential_type_change(
                Some(CodexLaunchCredentialType::Api),
                Some(CodexLaunchCredentialType::Api),
            )
        );
        assert!(
            should_repair_session_visibility_after_credential_type_change(
                Some(CodexLaunchCredentialType::Api),
                None,
            )
        );
        assert!(
            !should_repair_session_visibility_after_credential_type_change(
                Some(CodexLaunchCredentialType::Account),
                Some(CodexLaunchCredentialType::Account),
            )
        );
    }
}

pub fn run() {
    configure_lite_data_dir();

    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_opener::init())
        .on_window_event(|window, event| {
            if window.label() == "main" {
                if let tauri::WindowEvent::CloseRequested { .. } = event {
                    mark_update_manual_close();
                }
            }
        })
        .setup(|app| {
            let handle = app.handle().clone();
            codex_oauth::restore_pending_oauth_listener(handle);
            sync_codex_media_mcp_registration_with_log("app_startup");
            tauri::async_runtime::spawn(async {
                codex_local_access::restore_local_access_gateway().await;
                refresh_cached_cloud_external_api_service_on_startup().await;
            });
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            list_codex_accounts,
            get_current_codex_account,
            get_codex_config_toml_path,
            get_codex_auth_json_path,
            switch_codex_account,
            restart_codex_default_app,
            delete_codex_account,
            delete_codex_accounts,
            import_codex_from_local,
            import_codex_from_json,
            import_codex_from_files,
            preview_codex_cloud_import,
            confirm_codex_cloud_import,
            cancel_codex_cloud_import,
            export_codex_accounts,
            save_codex_export_file,
            save_codex_export_files,
            check_server_update,
            download_server_update,
            install_server_update,
            refresh_codex_quota,
            refresh_all_codex_quotas,
            refresh_codex_subscription_info,
            refresh_codex_account_profile,
            add_codex_account_with_token,
            add_codex_account_with_api_key,
            update_codex_account_name,
            update_codex_account_tags,
            update_codex_account_note,
            update_codex_account_app_speed,
            update_codex_api_key_credentials,
            get_codex_api_service_app_speed_config,
            save_codex_api_service_app_speed,
            codex_oauth_login_start,
            codex_oauth_login_completed,
            codex_oauth_login_cancel,
            codex_oauth_submit_callback_url,
            codex_local_access_get_state,
            codex_local_access_get_state_light,
            codex_local_access_save_accounts,
            codex_local_access_remove_account,
            codex_local_access_rotate_api_key,
            codex_local_access_update_port,
            codex_local_access_update_client_base_url_host,
            get_codex_external_api_service_config,
            activate_codex_external_api_service,
            delete_codex_external_api_service_profile,
            deactivate_codex_external_api_service,
            codex_local_access_set_enabled,
            codex_local_access_kill_port,
            codex_local_access_activate,
        ])
        .run(tauri::generate_context!())
        .expect("error while running codex账号管理器");
}
