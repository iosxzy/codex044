use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::time::Duration;

fn go_target_from_rust_target(target: &str) -> Option<(&'static str, &'static str)> {
    let goos = if target.contains("windows") {
        "windows"
    } else if target.contains("apple-darwin") {
        "darwin"
    } else if target.contains("linux") {
        "linux"
    } else {
        return None;
    };

    let goarch = if target.starts_with("x86_64") {
        "amd64"
    } else if target.starts_with("aarch64") {
        "arm64"
    } else {
        return None;
    };

    Some((goos, goarch))
}

fn env_flag_is_enabled(name: &str) -> bool {
    std::env::var(name)
        .ok()
        .as_deref()
        .is_some_and(|value| matches!(value, "1" | "true" | "TRUE" | "yes" | "YES"))
}

fn go_executable_name() -> &'static str {
    if cfg!(target_os = "windows") {
        "go.exe"
    } else {
        "go"
    }
}

fn command_path_available(path: &Path) -> bool {
    Command::new(path)
        .arg("version")
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .status()
        .is_ok()
}

fn collect_go_toolcache_candidates(root: &Path, candidates: &mut Vec<PathBuf>) {
    let Ok(versions) = std::fs::read_dir(root) else {
        return;
    };
    for version in versions.flatten() {
        let version_path = version.path();
        if !version_path.is_dir() {
            continue;
        }
        let Ok(arches) = std::fs::read_dir(&version_path) else {
            continue;
        };
        for arch in arches.flatten() {
            let candidate = arch.path().join("bin").join(go_executable_name());
            candidates.push(candidate);
        }
    }
}

fn go_executable_candidates() -> Vec<PathBuf> {
    let mut candidates = Vec::new();

    if let Ok(go) = std::env::var("GO") {
        if !go.trim().is_empty() {
            candidates.push(PathBuf::from(go));
        }
    }

    if let Some(paths) = std::env::var_os("PATH") {
        candidates
            .extend(std::env::split_paths(&paths).map(|path| path.join(go_executable_name())));
    }

    if let Ok(goroot) = std::env::var("GOROOT") {
        if !goroot.trim().is_empty() {
            candidates.push(PathBuf::from(goroot).join("bin").join(go_executable_name()));
        }
    }

    if let Ok(toolcache) = std::env::var("RUNNER_TOOL_CACHE") {
        collect_go_toolcache_candidates(&PathBuf::from(toolcache).join("go"), &mut candidates);
    }
    collect_go_toolcache_candidates(Path::new("/opt/hostedtoolcache/go"), &mut candidates);
    collect_go_toolcache_candidates(
        Path::new("/Users/runner/hostedtoolcache/go"),
        &mut candidates,
    );

    candidates.push(PathBuf::from("/usr/local/go/bin/go"));
    candidates.push(PathBuf::from("/opt/homebrew/bin/go"));
    candidates.push(PathBuf::from("/usr/bin/go"));

    #[cfg(target_os = "windows")]
    {
        candidates.push(PathBuf::from(r"C:\hostedtoolcache\windows\go").join(go_executable_name()));
        collect_go_toolcache_candidates(
            Path::new(r"C:\hostedtoolcache\windows\go"),
            &mut candidates,
        );
        candidates.push(PathBuf::from(r"C:\Program Files\Go\bin\go.exe"));
    }

    candidates
}

fn find_go_executable() -> Option<PathBuf> {
    go_executable_candidates()
        .into_iter()
        .find(|candidate| command_path_available(candidate))
}

fn should_reuse_existing_sidecar(output: &Path) -> bool {
    output.exists()
        && (env_flag_is_enabled("COCKPIT_SKIP_CLIPROXY_BUILD") || find_go_executable().is_none())
}

fn require_sidecar_file(path: &Path, label: &str) {
    if !path.is_file() {
        panic!(
            "missing cockpit-cliproxy {label}: {}. Make sure codex-account-manager-lite/sidecars/cockpit-cliproxy is included in the repository source.",
            path.display()
        );
    }
}

fn validate_sidecar_source(sidecar_dir: &Path) {
    require_sidecar_file(&sidecar_dir.join("main.go"), "entrypoint");
    require_sidecar_file(&sidecar_dir.join("go.mod"), "go.mod");
    require_sidecar_file(&sidecar_dir.join("go.sum"), "go.sum");
    require_sidecar_file(
        &sidecar_dir.join("cdk/CLIProxyAPI/internal/registry/models/codex_client_models.json"),
        "Codex client model templates",
    );
}

fn emit_sidecar_rerun_inputs(path: &Path) {
    if path.file_name().and_then(|name| name.to_str()) == Some("bin") {
        return;
    }

    let Ok(metadata) = std::fs::metadata(path) else {
        return;
    };

    if metadata.is_dir() {
        let Ok(entries) = std::fs::read_dir(path) else {
            return;
        };
        for entry in entries.flatten() {
            emit_sidecar_rerun_inputs(&entry.path());
        }
        return;
    }

    let should_track = matches!(
        path.file_name().and_then(|name| name.to_str()),
        Some("go.mod") | Some("go.sum")
    ) || path.extension().and_then(|extension| extension.to_str()) == Some("go");

    if should_track {
        println!("cargo:rerun-if-changed={}", path.display());
    }
}

fn build_go_sidecar(
    sidecar_dir: &Path,
    output_dir: &Path,
    rust_target: &str,
    goos: &str,
    goarch: &str,
) -> PathBuf {
    let extension = if goos == "windows" { ".exe" } else { "" };
    let output = output_dir.join(format!("cockpit-cliproxy-{rust_target}{extension}"));
    if should_reuse_existing_sidecar(&output) {
        return output;
    }
    let go = find_go_executable().unwrap_or_else(|| {
        panic!(
            "failed to find Go for cockpit-cliproxy. Install Go and make sure `go` is available on PATH, or set GO to the go executable path."
        )
    });

    for attempt in 1..=3 {
        let status = Command::new(&go)
            .current_dir(sidecar_dir)
            .env("GOOS", goos)
            .env("GOARCH", goarch)
            .env("CGO_ENABLED", "0")
            .arg("build")
            .arg("-trimpath")
            .arg("-ldflags")
            .arg("-s -w")
            .arg("-o")
            .arg(&output)
            .arg(".")
            .status()
            .unwrap_or_else(|error| {
                panic!(
                    "failed to start go build for cockpit-cliproxy with {}: {error}. Install Go and make sure `go` is available on PATH, or set GO to the go executable path.",
                    go.display()
                )
            });

        if status.success() {
            return output;
        }
        if attempt < 3 {
            let delay = Duration::from_secs(attempt * 10);
            println!(
                "cargo:warning=go build for cockpit-cliproxy failed (attempt {attempt}/3); retrying in {} seconds",
                delay.as_secs()
            );
            std::thread::sleep(delay);
        }
    }
    panic!("go build for cockpit-cliproxy failed after 3 attempts");
}

fn build_macos_universal_sidecar(sidecar_dir: &Path, output_dir: &Path) {
    let output = output_dir.join("cockpit-cliproxy-universal-apple-darwin");
    if should_reuse_existing_sidecar(&output) {
        return;
    }

    let x86_64_output = build_go_sidecar(
        sidecar_dir,
        output_dir,
        "x86_64-apple-darwin",
        "darwin",
        "amd64",
    );
    let aarch64_output = build_go_sidecar(
        sidecar_dir,
        output_dir,
        "aarch64-apple-darwin",
        "darwin",
        "arm64",
    );

    let status = Command::new("lipo")
        .arg("-create")
        .arg(&x86_64_output)
        .arg(&aarch64_output)
        .arg("-output")
        .arg(&output)
        .status()
        .expect("failed to start lipo for cockpit-cliproxy universal sidecar");

    if !status.success() {
        panic!("lipo for cockpit-cliproxy universal sidecar failed");
    }
}

fn build_cockpit_cliproxy_sidecar() {
    let manifest_dir =
        PathBuf::from(std::env::var("CARGO_MANIFEST_DIR").expect("CARGO_MANIFEST_DIR is required"));
    let target = std::env::var("TARGET").expect("TARGET is required");
    println!("cargo:rustc-env=COCKPIT_RUST_TARGET={target}");

    let sidecar_dir = manifest_dir.join("../sidecars/cockpit-cliproxy");
    let output_dir = sidecar_dir.join("bin");

    validate_sidecar_source(&sidecar_dir);
    println!("cargo:rerun-if-env-changed=COCKPIT_SKIP_CLIPROXY_BUILD");
    emit_sidecar_rerun_inputs(&sidecar_dir);
    std::fs::create_dir_all(&output_dir).expect("failed to create cockpit-cliproxy bin dir");

    if cfg!(target_os = "macos") && target == "universal-apple-darwin" {
        build_macos_universal_sidecar(&sidecar_dir, &output_dir);
        return;
    }

    let Some((goos, goarch)) = go_target_from_rust_target(&target) else {
        panic!("unsupported sidecar build target: {target}");
    };
    build_go_sidecar(&sidecar_dir, &output_dir, &target, goos, goarch);
    if cfg!(target_os = "macos") && target.contains("apple-darwin") {
        build_macos_universal_sidecar(&sidecar_dir, &output_dir);
    }
}

fn main() {
    println!("cargo:rerun-if-changed=build.rs");
    build_cockpit_cliproxy_sidecar();
    tauri_build::build();
}
